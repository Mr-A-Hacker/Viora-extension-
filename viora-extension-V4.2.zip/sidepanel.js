const SYSTEM_PROMPT = `You are Viora V4, an efficient browser automation AI with adaptive intelligence and security awareness.

## V4 EFFICIENCY UPGRADES
You now have these new capabilities:
1. **UNDO** — Every action is reversible. After any click/fill/check/select, the user can undo it.
2. **SECURITY BOUNDARIES** — You automatically detect sensitive fields (password, credit card, SSN, banking) and pause before interacting with them.
3. **ADAPTIVE PATIENCE** — Your engine learns page load speeds and adjusts wait times dynamically. No more guessing.
4. **MICRO-CORRECTIONS** — Common typos in emails/URLs are auto-fixed. Wrong click targets are corrected automatically.
5. **USER PATTERN LEARNING** — The system learns from your past choices to prioritize what you prefer.
6. **SPEED** — Actions use adaptive timing: fast on fast pages, patient on slow pages.

## HOW YOU UNDERSTAND PAGES
You receive:
1. A SCREENSHOT — you see EVERYTHING on screen visually
2. PAGE CONTEXT — structured data about every element, position, visibility, labels, relationships
3. PAGE STRUCTURE — sections, forms, navigation, modals, headings hierarchy
4. PAGE TYPE — what kind of page this is (survey, checkout, login, search, etc.)
5. VIEWPORT STATE — scroll position, what's visible, page dimensions

## YOUR 100+ STRATEGY ENGINE
Every action is backed by a combinatorial engine that tries 130+ strategy combinations automatically:
- **40+ finders**: CSS selectors, XPath, text-exact, text-includes, text-fuzzy, leaf-node text, visible-nth, ARIA-label, label-for, placeholder, title, alt, name, id, data-testid, class, ng-click, vue-click, hint-based navigation
- **20+ clickers**: pointer events, mouse events, touch events, React synthetic, Vue events, Angular events, native click, focus+enter, double-click, mousedown-only, pointerdown-only, hover-pause, dispatch-on-parent
- **5 timings**: fast (50ms), normal (100ms), slow (200ms), human (80ms+random), random
- **6 adaptations**: scroll into view, smooth scroll, force-reveal hidden, wait-for-stable, highlight, no-prep

If one strategy fails, the engine falls through to the next. Your job is to provide good targets.

## CORE RULES

### Rule 1: Batch ALL actions on the same page
When multiple questions/buttons/fields are visible on ONE page, do them ALL without screenshot between them. Only screenshot after page navigation.

GOOD:
{"type":"action_plan","steps":[
  {"type":"screenshot","description":"See page"},
  {"type":"click","selector":"#Q2","text":"Option A","description":"Q2"},
  {"type":"fill","selector":"textarea","value":"Essay","description":"Q3 essay"},
  {"type":"click","selector":"#Next","text":"Next","description":"Next page"},
  {"type":"screenshot","description":"See next page"}
]}

BAD (do NOT do this — no screenshots between same-page clicks):
{"type":"action_plan","steps":[
  {"type":"screenshot"},{"type":"click","description":"Q2"},
  {"type":"screenshot"},{"type":"fill","description":"Q3"},
  {"type":"screenshot"},{"type":"click","description":"Next"}
]}

### Rule 2: Every step gets both selector AND text
All click/fill/check/select steps MUST include both for redundancy. If selector fails, text is the fallback.

### Rule 3: Each step should have a clear, human-readable description
Use descriptions like "Clicked Submit button", "Filled email field", "Selected option B". This powers the undo UI.

## COMPLETE ACTION CATALOG — ALL WAYS TO INTERACT

Below is EVERY action type. Use the one that fits your goal.

### screenshot
See the page. Always start with this.
{"type":"screenshot","description":"See current page"}
Returns: a fresh image of the tab.

### analyze
Get structured data about every element.
{"type":"analyze","description":"Analyze page structure"}
Returns: JSON with forms, buttons, inputs, links, headings, pageType, structure, modals, viewport.

### click — click any element by selector or text
Two locating methods (use both for redundancy):
1. selector: CSS selector (#id, .class, [attr=val], tag, etc.)
2. text: visible text content of the element
The engine then tries 40+ finders × 20+ clickers to hit it.
{"type":"click","selector":"#SubmitButton","text":"Submit","description":"Click submit button"}
{"type":"click","selector":"input[value='Option 1']","text":"Option 1","description":"Select radio option"}
{"type":"click","selector":"a[href*='checkout']","text":"Proceed to Checkout","description":"Go to checkout"}
{"type":"click","selector":"label[for='agree']","text":"I agree to terms","description":"Accept terms"}
{"type":"click","selector":"[aria-label='Close']","text":"Close","description":"Close modal"}
{"type":"click","selector":"button[type='submit']","text":"Login","description":"Log in"}
For survey radio buttons: {"type":"click","selector":"#QID2-4","text":"Very satisfied","description":"Q2: select answer"}
For matrix cells: {"type":"click","selector":"#QID4_1-5","text":"Strongly agree","description":"Q4 Row1"}

### click_at — click at exact pixel coordinates on screen
Ultimate fallback when no selector works. Uses (x,y) from the screenshot.
{"type":"click_at","x":450,"y":320,"description":"Click at coordinates on screen"}
The engine walks up from the pixel to find the nearest clickable element (button, link, input, etc.).

### fill — type or paste text into any input/textarea
For SHORT text (<80 chars): types character by character with human-like delays
For LONG text (>80 chars): pastes instantly (essays, code, long answers)
Scrolls to the element first, clicks it, then fills.
{"type":"fill","selector":"input[name='email']","value":"user@example.com","description":"Enter email"}
{"type":"fill","selector":"#password","value":"mypassword","description":"Enter password"}
{"type":"fill","selector":"textarea[name='essay']","value":"Long essay answer here...","description":"Write essay"}
{"type":"fill","selector":"[name='search']","value":"search query","description":"Search box"}
{"type":"fill","selector":"input[type='tel']","value":"555-1234","description":"Phone number"}
{"type":"fill","selector":"[contenteditable='true']","value":"Custom content","description":"Rich text field"}

### clear — clear all text from an input
{"type":"clear","selector":"#search","description":"Clear search field"}
Uses native value setter + input/change events.

### select — pick an option from a dropdown/select element
{"type":"select","selector":"#country","value":"US","description":"Select country"}
{"type":"select","selector":"select[name='month']","value":"January","description":"Select month"}
{"type":"select","selector":"[role='combobox']","value":"Option 2","description":"Select from combo"}
Sets the value property and dispatches change event.

### check — check or uncheck a checkbox/switch/toggle
Use checked:true (default) or checked:false to uncheck.
{"type":"check","selector":"#agreeCheckbox","text":"I agree","description":"Check agree box"}
{"type":"check","selector":"[role='switch']","text":"Notifications","description":"Toggle notifications ON"}
{"type":"check","selector":"#newsletter","text":"Subscribe","description":"Subscribe to newsletter"}
{"type":"check","selector":"#option2","text":"Option 2","description":"Uncheck option","checked":false}
Scrolls, highlights, clicks, then sets checked state programmatically.

### scroll — scroll the page or a specific element into view
Four modes:
1. toBottom: scroll all the way down
2. toTop: scroll to top
3. selector: scroll to a specific element
4. y: scroll by a specific pixel amount
{"type":"scroll","toBottom":true,"description":"Scroll to bottom of page"}
{"type":"scroll","toTop":true,"description":"Scroll to top"}
{"type":"scroll","selector":"#footer","description":"Scroll to footer"}
{"type":"scroll","y":400,"description":"Scroll down 400px"}
{"type":"scroll","selector":"#question10","description":"Scroll to question 10"}
Use scroll before fill/click when the element is below the viewport.

### extract — read text content from the page or a specific element
{"type":"extract","selector":".results","description":"Extract search results"}
{"type":"extract","description":"Extract all page text"}
Returns text content (up to 20000 chars).

### extract_links — get all links on the page
{"type":"extract_links","selector":"nav a","description":"Get navigation links"}
{"type":"extract_links","description":"Get all page links"}
Returns [{text, href}] array.

### extract_table — get table data as structured JSON
{"type":"extract_table","selector":"#pricing","description":"Extract pricing table"}
Finds the table, reads headers (th) and rows (td), returns {headers, rows}.

### wait_for — wait for an element to appear on the page
Use before clicking dynamically loaded content.
{"type":"wait_for","selector":".loading-complete","description":"Wait for loading","timeout":8000}
{"type":"wait_for","selector":"#results","description":"Wait for results to appear"}
Polls with MutationObserver until element is visible. Default timeout 10s.

### hover — move the purple cursor over an element and trigger mouseover
The purple cursor animates to the element's position. Triggers pointerover, mouseover, pointermove, mousemove events.
{"type":"hover","selector":".tooltip-trigger","text":"More info","description":"Hover to see tooltip"}
{"type":"hover","selector":"#menu-item","description":"Hover to open dropdown"}
{"type":"hover","x":300,"y":200,"description":"Hover at coordinates"}
Holds for 600ms so hover effects/tooltips appear.

### press_key — simulate a keyboard key press
Sends keydown → keypress → keyup on the focused element or document.
{"type":"press_key","key":"Enter","description":"Press Enter"}
{"type":"press_key","key":"Tab","description":"Tab to next field"}
{"type":"press_key","key":"Escape","description":"Close modal with Escape"}
{"type":"press_key","key":"ArrowDown","description":"Arrow down in dropdown"}
{"type":"press_key","key":"a","ctrl":true,"description":"Ctrl+A select all"}
{"type":"press_key","key":"c","ctrl":true,"description":"Ctrl+C copy"}
{"type":"press_key","key":"v","ctrl":true,"description":"Ctrl+V paste"}
{"type":"press_key","key":"Delete","description":"Delete selected"}
{"type":"press_key","key":"Home","description":"Go to beginning"}
{"type":"press_key","key":"End","description":"Go to end"}
Optional: ctrl, shift, alt, meta as boolean modifiers.

### get_page_info — get URL, title, page text, and all interactive elements
{"type":"get_page_info","description":"Get full page info"}
Returns title, url, text (first 15000 chars), and all interactive elements.

### navigate — go to a different URL (handled at sidepanel level)
{"type":"navigate","url":"https://example.com","description":"Go to example.com"}

### undo — undo the last action
Reverts the last click/fill/check/select. Each action is automatically tracked.
{"type":"undo","description":"Undo last action"}

## SURVEY HANDLING — ALL QUESTION TYPES
- Radio (MCQ): {"type":"click","selector":"#QID2-1","text":"Option","description":"Q2 select"}
- Checkbox (multi): {"type":"check","selector":"#QID3_1","text":"Option","description":"Q3 check"}
- Matrix/Grid: {"type":"click","selector":"#QID4_1-5","text":"Agree","description":"Q4 Row1"}
- Dropdown: {"type":"select","selector":"#QID5","value":"Option","description":"Q5 choose"}
- Essay/Textarea: {"type":"fill","selector":"textarea[name='Q6']","value":"Answer","description":"Q6 essay"}
- Short answer: {"type":"fill","selector":"input[name='Q7']","value":"Answer","description":"Q7 short"}
- Likert scale: {"type":"click","selector":"#QID8-5","text":"5 - Very","description":"Q8 rate"}
- Ranking: {"type":"click","selector":"#QID9_1","text":"Rank 1","description":"Q9 rank"}
- Next/Submit: {"type":"click","selector":"#NextButton","text":"Next","description":"Next page"}
- Open-ended: {"type":"fill","selector":"textarea[name='Q10']","value":"Feedback","description":"Q10 open"}
- Numeric: {"type":"fill","selector":"input[name='Q11']","value":"42","description":"Q11 number"}
- Date/Time: {"type":"fill","selector":"input[name='Q12']","value":"2025-01-15","description":"Q12 date"}
- File upload: SKIP — note "Requires manual file upload"
Answer ALL visible questions per page, then click Next. Batch the whole page.

## ASSIGNMENT HANDLING — ALL QUESTION TYPES
- Essay: fill textarea with complete answer (long text pasted instantly)
- Multiple choice: click radio
- True/False: click radio {"type":"click","text":"True","description":"Q select True"}
- Fill-in-blank: {"type":"fill","selector":"input","value":"answer","description":"Fill blank"}
- Matching: {"type":"select","selector":"select[name='match1']","value":"Answer B","description":"Match 1"}
- Short answer: fill input
- Code: fill textarea with code (pasted instantly since >80 chars)
- Math: fill input with equation like "x = 5"
- Ordering: click each item in correct order, or use select
- Upload: SKIP — note "Requires manual upload"

## PAGE TYPE STRATEGIES
- survey: answer all question types, batch per page, Next to advance
- login: fill username/email, fill password, click login/sign-in
- checkout: fill shipping, fill billing, select payment, review, place order
- search-results: read results, click links, extract data
- form-filling: fill all visible fields, submit
- ecommerce: browse products, add to cart, checkout
- settings: toggle switches, select options, save/apply
- registration: fill required(*), accept terms, submit
- dashboard: read data, click menu items, navigate sections
- article: read content, scroll through, click related links
- content-page: scroll and read, click navigation links
- navigation: click menu items to explore

## OTHER RULES
- Start every task with one screenshot (and optionally analyze) to see the page
- After every page navigation, take a screenshot
- Watch for open modals/dialogs — close them before continuing
- For long pages, scroll before filling or clicking out-of-view elements
- After task completion, verify with one final screenshot
- The 130+ strategy engine never gives up — it tries everything
- You can now use the "undo" action type to revert any step`;

let apiKey = '';
let model = 'google/gemini-2.0-flash-exp';
let conversationHistory = [];
let pendingScreenshot = null;
let activeTask = null;
let stopRequested = false;
let abortController = null;
let autoScreenshot = true;
let stepScreenshots = true;
let fastMode = false;
let autoConfirmSensitive = false;
let targetTabId = null;
let targetTabTitle = '';
let targetTabFavicon = '';
let consecutiveErrors = 0;

// V4: User Intent Prediction & Tracking
const userPatterns = {
  fieldChoices: {},    // field name -> { value: count }
  workflowSteps: [],   // [ { intent, action, timestamp } ]
  commonWorkflows: {}, // workflow pattern -> count
  preferences: {       // learned preferences
    preferredEmail: '',
    preferredModel: '',
    autoConfirm: false,
    fastMode: false
  }
};

function trackUserAction(step, result) {
  const key = `${step.type}:${step.description || step.selector || ''}`;
  const value = step.value || step.text || step.selector || '';
  
  if (!userPatterns.fieldChoices[key]) userPatterns.fieldChoices[key] = {};
  if (value) {
    userPatterns.fieldChoices[key][value] = (userPatterns.fieldChoices[key][value] || 0) + 1;
  }
  
  userPatterns.workflowSteps.push({
    intent: step.description || step.type,
    action: key,
    value: value,
    timestamp: Date.now(),
    success: result?.success
  });
  
  // Keep last 200 steps
  if (userPatterns.workflowSteps.length > 200) userPatterns.workflowSteps.shift();
}

function getLearnedPreference(intent) {
  const choices = userPatterns.fieldChoices[intent];
  if (!choices) return null;
  
  // Return the most frequent choice
  const entries = Object.entries(choices);
  entries.sort((a, b) => b[1] - a[1]);
  return entries[0][0];
}

function suggestNextSteps(currentPageType) {
  // Analyze past workflows for similar page types
  const relevant = userPatterns.workflowSteps.filter(s => 
    s.intent && s.intent.toLowerCase().includes(currentPageType?.toLowerCase() || '')
  );
  
  if (relevant.length < 3) return null;
  
  // Find most common sequences
  const sequences = {};
  for (let i = 0; i < relevant.length - 1; i++) {
    const seq = `${relevant[i].action} → ${relevant[i+1].action}`;
    sequences[seq] = (sequences[seq] || 0) + 1;
  }
  
  const sorted = Object.entries(sequences).sort((a, b) => b[1] - a[1]);
  return sorted.slice(0, 3).map(([seq]) => seq);
}

// V4: Undo state
let lastExecutedStep = null;
let lastExecutedTaskId = null;

const messagesEl = document.getElementById('messages');
const chatInput = document.getElementById('chatInput');
const sendBtn = document.getElementById('sendBtn');
const stopInputBtn = document.getElementById('stopInputBtn');
const welcomeEl = document.getElementById('welcome');
const typingIndicator = document.getElementById('typingIndicator');
const typingText = document.getElementById('typingText');
const screenshotBar = document.getElementById('screenshotBar');
const screenshotPreview = document.getElementById('screenshotPreview');
const noKeyNotice = document.getElementById('noKeyNotice');
const modeBadge = document.getElementById('modeBadge');
const tabPicker = document.getElementById('tabPicker');
const tabPickerList = document.getElementById('tabPickerList');
const tabPickerSearch = document.getElementById('tabPickerSearch');
const tabBadge = document.getElementById('tabBadge');
const tabBadgeFavicon = document.getElementById('tabBadgeFavicon');
const tabBadgeTitle = document.getElementById('tabBadgeTitle');
const tabBadgeClear = document.getElementById('tabBadgeClear');

async function init() {
  const stored = await chrome.storage.local.get(['apiKey','model','autoScreenshot','stepScreenshots','fastMode','autoConfirmSensitive']);
  apiKey = stored.apiKey || '';
  model = stored.model || 'google/gemini-2.0-flash-exp';
  autoScreenshot = stored.autoScreenshot !== false;
  stepScreenshots = stored.stepScreenshots !== false;
  fastMode = stored.fastMode === true;
  autoConfirmSensitive = stored.autoConfirmSensitive === true;
  if (!apiKey) noKeyNotice.style.display = 'block';
  setupEventListeners();
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.apiKey) { apiKey = changes.apiKey.newValue || ''; noKeyNotice.style.display = apiKey ? 'none' : 'block'; }
  if (changes.model) model = changes.model.newValue || 'google/gemini-2.0-flash-exp';
  if (changes.autoScreenshot) autoScreenshot = changes.autoScreenshot.newValue !== false;
  if (changes.stepScreenshots) stepScreenshots = changes.stepScreenshots.newValue !== false;
  if (changes.fastMode) fastMode = changes.fastMode.newValue === true;
  if (changes.autoConfirmSensitive) autoConfirmSensitive = changes.autoConfirmSensitive.newValue === true;
});

function setupEventListeners() {
  sendBtn.addEventListener('click', handleSend);
  chatInput.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }});
  chatInput.addEventListener('input', () => {
    chatInput.style.height = 'auto';
    chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
    sendBtn.disabled = chatInput.value.trim() === '';
  });
  document.querySelectorAll('.quick-chip').forEach(c => c.addEventListener('click', () => {
    chatInput.value = c.dataset.prompt;
    chatInput.dispatchEvent(new Event('input'));
    handleSend();
  }));
  document.getElementById('screenshotBtn').addEventListener('click', captureAndAttach);
  document.getElementById('attachScreenBtn').addEventListener('click', captureAndAttach);
  document.getElementById('removeScreenshot').addEventListener('click', () => {
    pendingScreenshot = null; screenshotBar.style.display = 'none';
    document.getElementById('attachScreenBtn').classList.remove('active');
  });
  document.getElementById('clearBtn').addEventListener('click', clearConversation);
  chatInput.addEventListener('input', handleAtMention);
  chatInput.addEventListener('keydown', e => {
    if (tabPicker.style.display === 'none') return;
    const items = tabPickerList.querySelectorAll('.tab-picker-item');
    const sel = tabPickerList.querySelector('.tab-picker-item.selected');
    let idx = [...items].indexOf(sel);
    if (e.key === 'ArrowDown') { e.preventDefault(); selectPickerItem(items, Math.min(idx+1, items.length-1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); selectPickerItem(items, Math.max(idx-1, 0)); }
    else if (e.key === 'Enter' && sel) { e.preventDefault(); sel.click(); }
    else if (e.key === 'Escape') { closeTabPicker(); }
  });
  tabPickerSearch.addEventListener('input', () => renderTabPickerItems(tabPickerSearch.value));
  stopInputBtn.addEventListener('click', () => {
    if (abortController) { abortController.abort(); abortController = null; }
    stopRequested = true; activeTask = null; hideTyping();
  });
  tabBadgeClear.addEventListener('click', () => {
    targetTabId = null; targetTabTitle = ''; targetTabFavicon = '';
    tabBadge.style.display = 'none';
  });
  document.addEventListener('click', e => {
    if (!tabPicker.contains(e.target) && e.target !== chatInput) closeTabPicker();
  });
}

let _allTabs = [];

function handleAtMention(e) {
  const val = chatInput.value;
  const cursor = chatInput.selectionStart;
  const before = val.slice(0, cursor);
  const atIdx = before.lastIndexOf('@');
  if (atIdx !== -1 && !before.slice(atIdx + 1).includes(' ')) openTabPicker(before.slice(atIdx + 1));
  else closeTabPicker();
}

function openTabPicker(query) {
  chrome.runtime.sendMessage({ type: 'LIST_TABS' }, res => {
    if (!res?.tabs) return;
    _allTabs = res.tabs.filter(t => t.url && !t.url.startsWith('chrome://') && !t.url.startsWith('chrome-extension://'));
    tabPickerSearch.value = query;
    renderTabPickerItems(query);
    tabPicker.style.display = 'flex';
    tabPickerSearch.focus();
  });
}

function renderTabPickerItems(query) {
  const q = (query||'').toLowerCase();
  const filtered = _allTabs.filter(t => !q || t.title?.toLowerCase().includes(q) || t.url?.toLowerCase().includes(q)).slice(0, 10);
  tabPickerList.innerHTML = filtered.length ? '' : '<div style="padding:12px;font-size:12px;color:var(--text-3);text-align:center">No tabs found</div>';
  filtered.forEach((tab, i) => {
    const item = document.createElement('div');
    item.className = 'tab-picker-item' + (i === 0 ? ' selected' : '');
    const domain = (() => { try { return new URL(tab.url).hostname.replace('www.', ''); } catch(_) { return tab.url; }})();
    item.innerHTML = `<div class="tab-picker-favicon-wrap">${tab.favIconUrl ? `<img src="${tab.favIconUrl}" width="16" height="16" onerror="this.parentElement.innerHTML='<div class=tab-favicon-placeholder></div>'">` : '<div class="tab-favicon-placeholder"></div>'}</div><div class="tab-picker-item-text"><div class="tab-picker-item-title">${escapeHtml(tab.title||'Untitled')}</div><div class="tab-picker-item-url">${escapeHtml(domain)}</div></div>`;
    item.addEventListener('click', () => pickTab(tab));
    tabPickerList.appendChild(item);
  });
}

function selectPickerItem(items, idx) {
  items.forEach((el, i) => el.classList.toggle('selected', i === idx));
}

function pickTab(tab) {
  targetTabId = tab.id; targetTabTitle = tab.title || tab.url; targetTabFavicon = tab.favIconUrl || '';
  const val = chatInput.value;
  const cursor = chatInput.selectionStart;
  const before = val.slice(0, cursor);
  const atIdx = before.lastIndexOf('@');
  if (atIdx !== -1) {
    chatInput.value = val.slice(0, atIdx) + val.slice(cursor);
    chatInput.selectionStart = chatInput.selectionEnd = atIdx;
  }
  tabBadgeTitle.textContent = targetTabTitle.length > 40 ? targetTabTitle.slice(0,40) + '…' : targetTabTitle;
  tabBadgeFavicon.src = targetTabFavicon; tabBadgeFavicon.style.display = targetTabFavicon ? '' : 'none';
  tabBadge.style.display = 'flex'; closeTabPicker(); chatInput.focus();
}

function closeTabPicker() { tabPicker.style.display = 'none'; }

async function captureCurrentTab() {
  try {
    const res = await new Promise(resolve => chrome.runtime.sendMessage({ type: 'CAPTURE_SCREENSHOT', tabId: targetTabId }, resolve));
    if (res?.screenshot) return res.screenshot;
    return null;
  } catch(_) { return null; }
}

async function getEnhancedPageContext() {
  try {
    const tabInfo = await new Promise(resolve => chrome.runtime.sendMessage({ type: 'GET_TAB_INFO', tabId: targetTabId }, resolve));
    if (!tabInfo?.url || tabInfo.url.startsWith('chrome://')) return null;

    const enhanced = await new Promise(resolve => chrome.runtime.sendMessage({ type: 'GET_ENHANCED_CONTENT', tabId: targetTabId }, resolve));
    if (!enhanced) return null;

    let ctx = `[URL]: ${tabInfo.url}\n[Title]: ${enhanced.title || ''}\n`;

    if (enhanced.pageType) {
      const pt = enhanced.pageType;
      ctx += `[Page Type]: ${pt.primary}${pt.secondary?.length ? ' ('+pt.secondary.join(', ')+')' : ''}\n`;
    }

    if (enhanced.state) {
      const s = enhanced.state;
      ctx += `[Viewport]: ${s.viewport.width}x${s.viewport.height}, scrolled ${s.percentScrolled}%${s.atBottom ? ' (at bottom)' : ''}\n`;
    }

    if (enhanced.structure?.modals?.length > 0) {
      ctx += `[Open Modals/Dialogs]:\n`;
      enhanced.structure.modals.forEach(m => {
        const btns = m.buttons || [];
        const btnText = typeof btns[0] === 'string' ? btns.join(', ') : btns.map(b => b.text||b.id).filter(Boolean).join(', ');
        ctx += `  ${m.tag} "${m.heading||'no heading'}" buttons: ${btnText||'none'}\n`;
      });
    }

    if (enhanced.analysis?.headings?.length > 0) {
      ctx += `[Page Headings]:\n`;
      enhanced.analysis.headings.forEach(h => {
        ctx += `  ${h.level}: "${h.text}"\n`;
      });
    }

    if (enhanced.structure?.nav) {
      ctx += `[Navigation]: ${enhanced.structure.nav.items?.length||0} items\n`;
    }

    if (enhanced.structure?.sections?.length > 0) {
      ctx += `[Sections]: ${enhanced.structure.sections.length}\n`;
      enhanced.structure.sections.slice(0, 5).forEach(s => {
        ctx += `  ${s.tag} "${s.headings?.[0]?.text||'?'}" (${s.elementCounts.buttons} btns, ${s.elementCounts.inputs} inputs)\n`;
      });
    }

    if (enhanced.forms?.length > 0) {
      ctx += `[Forms Detail]:\n`;
      enhanced.forms.forEach(f => {
        ctx += `  Form${f.id?' #'+f.id:''} method=${f.method} ${f.fields.length} fields, ${f.submitButtons.length} submit buttons\n`;
        f.fields.forEach(field => {
          if (field.type === 'fieldset') {
            ctx += `    Fieldset "${field.legend||''}": ${field.fields.length} fields\n`;
            field.fields.forEach(sf => {
              ctx += `      ${sf.type} name="${sf.name}" label="${sf.label||sf.ariaLabel||''}" ${sf.required?'*required':''}\n`;
            });
          } else {
            ctx += `    ${field.type} name="${field.name}" label="${field.label||field.ariaLabel||''}" ${field.required?'*required':''} placeholder="${field.placeholder||''}"\n`;
          }
        });
        f.submitButtons.forEach(b => {
          ctx += `    Submit: "${b.text}"${b.id?' #'+b.id:''}\n`;
        });
      });
    }

    if (enhanced.interactiveElements?.length > 0) {
      const buttons = enhanced.interactiveElements.filter(e =>
        ['BUTTON','A','INPUT'].includes(e.tag) || ['button','link'].includes(e.role)
      ).filter(e => e.text||e.ariaLabel).slice(0, 50);
      const inputs = enhanced.interactiveElements.filter(e =>
        ['INPUT','SELECT','TEXTAREA'].includes(e.tag) || ['combobox','listbox'].includes(e.role)
      ).slice(0, 30);
      const checkables = enhanced.interactiveElements.filter(e =>
        ['checkbox','radio'].includes(e.type) || ['checkbox','radio','switch'].includes(e.role)
      ).slice(0, 30);

      if (buttons.length) {
        ctx += `[Buttons/Links] (visible ${buttons.filter(b=>b.visible).length}/${buttons.length}):\n`;
        buttons.forEach(b => {
          const flags = [];
          if (!b.visible) flags.push('hidden');
          if (b.disabled) flags.push('disabled');
          ctx += `  ${b.tag}${b.id?'#'+b.id:''} "${b.text||b.ariaLabel}" rect:${b.rect}${flags.length?' ['+flags.join(',')+']':''}\n`;
        });
      }
      if (inputs.length) {
        ctx += `[Inputs] (visible ${inputs.filter(i=>i.visible).length}/${inputs.length}):\n`;
        inputs.forEach(i => {
          ctx += `  ${i.tag} name="${i.name}" type="${i.type}" label="${i.label||i.ariaLabel||i.placeholder}" ${i.visible?'':'⚠️hidden'}${i.disabled?' 🚫disabled':''}\n`;
        });
      }
      if (checkables.length) {
        ctx += `[Checkboxes/Radios/Switches] (visible ${checkables.filter(c=>c.visible).length}/${checkables.length}):\n`;
        checkables.forEach(c => {
          ctx += `  ${c.tag}${c.id?'#'+c.id:''} "${c.text||c.ariaLabel||c.label}" type=${c.type} ${c.checked?'✓checked':'○unchecked'} section:"${c.section}"\n`;
        });
      }

      const inViewport = enhanced.interactiveElements.filter(e => e.inViewport).length;
      ctx += `\n[Element Summary]: ${enhanced.interactiveElements.length} total interactive elements (${inViewport} in viewport)`;
    }

    return ctx;
  } catch(_) { return null; }
}

async function handleSend() {
  const text = chatInput.value.trim();
  if (!text) return;
  if (!apiKey) { noKeyNotice.style.display = 'block'; return; }

  chatInput.value = ''; chatInput.style.height = 'auto'; sendBtn.disabled = true;
  hideWelcome();

  if (autoScreenshot && !pendingScreenshot) pendingScreenshot = await captureCurrentTab();
  if (!pendingScreenshot && !autoScreenshot && /what.*(on|see|screen|page|tab)|look at|this page|click|automate|go to|navigate|fill|search|find|help|do this|finish|survey|complete/i.test(text)) {
    pendingScreenshot = await captureCurrentTab();
  }

  addUserMessage(text, pendingScreenshot);
  const pageContext = await getEnhancedPageContext();

  let userContent;
  if (pendingScreenshot) {
    userContent = [
      { type: 'image_url', image_url: { url: pendingScreenshot } },
      { type: 'text', text: `[User request]: ${text}\n\n${pageContext||''}\n\nCRITICAL: Study the page structure above carefully. Produce a COMPLETE action plan with ALL steps for the ENTIRE page, batched together. Do NOT put screenshot+analyze between steps that are on the same page. Only screenshot again after navigating (e.g., clicking Next/Submit).` }
    ];
  } else {
    userContent = pageContext ? `${text}\n\n${pageContext}` : text;
  }

  conversationHistory.push({ role: 'user', content: userContent });
  const screenshot = pendingScreenshot;
  pendingScreenshot = null; screenshotBar.style.display = 'none';
  document.getElementById('attachScreenBtn').classList.remove('active');

  showTyping('Analyzing page and planning all steps…');
  consecutiveErrors = 0;

  try {
    const response = await callAI(conversationHistory);
    hideTyping();
    const { plan, visibleText } = extractActionPlan(response);
    if (plan) {
      conversationHistory.push({ role: 'assistant', content: response });
      if (visibleText) addAssistantMessage(visibleText);
      renderTaskCard(plan);
      setBadge('actions');
      const taskId = document.querySelector('.task-card:last-child')?.id;
      if (taskId) setTimeout(() => startTask(taskId, plan), 150);
      return;
    }
    conversationHistory.push({ role: 'assistant', content: response });
    addAssistantMessage(response);
    setBadge('chat');
  } catch (err) {
    hideTyping();
    if (err.name === 'AbortError') return;
    addAssistantMessage(`⚠️ ${err.message}\n\nCheck your API key.`);
  }
}

async function callAI(history) {
  abortController = new AbortController();
  
  // Prepend V4 settings as context
  const settingsContext = `[Current V4 Settings]\n- Fast Mode: ${fastMode ? 'ON (minimal delays)' : 'OFF (balanced speed/reliability)'}\n- Auto Confirm Sensitive: ${autoConfirmSensitive ? 'ON' : 'OFF (will ask you)'}\n- Auto Screenshot: ${autoScreenshot ? 'ON' : 'OFF'}\n- Step Screenshots: ${stepScreenshots ? 'ON' : 'OFF'}\n\n`;

  const messages = [
    { role: 'system', content: SYSTEM_PROMPT + '\n\n' + settingsContext },
    ...history
  ];

  const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    signal: abortController.signal,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
      'HTTP-Referer': 'https://viora-extension.local',
      'X-Title': 'Viora Browser Assistant'
    },
    body: JSON.stringify({
      model,
      messages,
      max_tokens: 4000,
      temperature: 0.1
    })
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `HTTP ${response.status}`);
  }
  const data = await response.json();
  return data.choices?.[0]?.message?.content || '';
}

function renderTaskCard(plan) {
  const taskId = 'task-' + Date.now();
  const n = plan.steps?.length || 0;
  const card = document.createElement('div');
  card.className = 'task-card';
  card.id = taskId;
  card.innerHTML = `
    <div class="task-card-header">
      <div class="task-icon">${plan.emoji||'⚡'}</div>
      <div class="task-meta">
        <div class="task-title">${escapeHtml(plan.title||'Task')}</div>
        <div class="task-subtitle">${n} step${n!==1?'s':''} · 100+ strategies ready</div>
      </div>
    </div>
    <div class="task-progress"><div class="task-progress-bar" id="${taskId}-progress"></div></div>
    <div class="task-steps" id="${taskId}-steps">${(plan.steps||[]).map((s,i) => `<div class="task-step" id="${taskId}-step-${i}"><div class="step-status pending" id="${taskId}-status-${i}">${stepStatusIcon('pending')}</div><div class="step-info"><div class="step-desc">${escapeHtml(s.description||s.type)}</div><div class="step-detail">${stepDetailText(s)}</div></div></div>`).join('')}</div>
    <div class="task-card-footer" id="${taskId}-footer">
      <button class="btn-run" id="${taskId}-runBtn" onclick="startTask('${taskId}',${JSON.stringify(plan).replace(/'/g,'&#39;')})"><svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg> Run Task</button>
      <button class="btn-discard" onclick="discardTask('${taskId}')">Discard</button>
    </div>`;
  messagesEl.appendChild(card);
  scrollToBottom();
}

function stepDetailText(s) {
  if (s.type === 'click') return `📍 ${s.description || ''} ${s.selector||''} ${s.text?`"${s.text}"`:''}`.trim();
  if (s.type === 'fill') return `✏️ ${s.description || ''} ${s.selector||''} → "${(s.value||'').slice(0,50)}${s.value?.length > 50 ? '…' : ''}"`.trim();
  if (s.type === 'click_at') return `📍 ${s.description || ''} at (${s.x},${s.y})`;
  if (s.type === 'check') return `☑️ ${s.description || ''} ${s.checked !== false ? 'check' : 'uncheck'} ${s.selector||''}`;
  if (s.type === 'select') return `📋 ${s.description || ''} → "${s.value}"`;
  if (s.type === 'scroll') return `📜 ${s.description || ''}`;
  if (s.type === 'navigate') return `🔗 ${s.description || ''} ${s.url||''}`;
  if (s.type === 'wait_for') return `⏳ ${s.description || ''} ${s.selector||''}`;
  if (s.type === 'extract') return `📄 ${s.description || ''}`;
  if (s.type === 'press_key') return `⌨️ ${s.description || ''} ${s.key||''}`;
  if (s.type === 'hover') return `🖱️ ${s.description || ''}`;
  if (s.type === 'analyze') return `🔍 ${s.description || ''}`;
  if (s.type === 'screenshot') return `📸 ${s.description || ''}`;
  return s.description || s.selector || s.url || s.type || '';
}

function stepStatusIcon(s) { return s==='pending'?'○':s==='running'?'↻':s==='done'?'✓':s==='error'?'✕':'—'; }

async function startTask(taskId, plan) {
  if (activeTask) return;
  activeTask = taskId; stopRequested = false; consecutiveErrors = 0;

  const footer = document.getElementById(`${taskId}-footer`);
  footer.innerHTML = `<button class="btn-stop" onclick="requestStop()"><svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><rect x="4" y="4" width="16" height="16"/></svg> Stop</button>`;

  const steps = plan.steps || [];
  let completed = 0, lastError = null;

  // V4: Show action preview before starting
  const previewCard = document.getElementById(taskId);
  if (previewCard) previewCard.style.opacity = '1';

  for (let i = 0; i < steps.length; i++) {
    if (stopRequested) break;
    const step = steps[i];
    setStepStatus(taskId, i, 'running');
    showTyping(`${step.description||'Step '+(i+1)}…`);

    try {
      const result = await executeStep(step);
      setStepStatus(taskId, i, 'done');
      consecutiveErrors = 0;

      // V4: Track user action for learning
      trackUserAction(step, result);

      // V4: Store last executed step for undo
      lastExecutedStep = { taskId, stepIndex: i, step, result };
      lastExecutedTaskId = taskId;

      // V4: Add undo button to completed steps
      if (step.type !== 'screenshot' && step.type !== 'analyze' && step.type !== 'navigate') {
        addUndoButtonToStep(taskId, i);
      }

      const isPageChange = step.type === 'navigate' || (step.type === 'click' && (step.text||'').match(/next|submit|continue|proceed|save|done|finish|ok/i));
      const isScreenshot = step.type === 'screenshot';

      if (isScreenshot && result?.screenshot) {
        appendScreenshotToStep(taskId, i, result.screenshot);
        conversationHistory.push({
          role: 'user',
          content: [
            { type: 'image_url', image_url: { url: result.screenshot } },
            { type: 'text', text: `[Page after step ${i+1}: "${step.description||step.type}" — See this page once. Understand the structure. Continue the plan efficiently, batching all actions on this page.]` }
          ]
        });
      }

      if (step.type === 'analyze' && result?.data) {
        const d = typeof result.data === 'string' ? result.data.slice(0,2000) : JSON.stringify(result.data).slice(0,2000);
        appendDataToStep(taskId, i, d);
      }

      if (!isScreenshot && !isPageChange && stepScreenshots) {
        const snap = await captureCurrentTab();
        if (snap) appendScreenshotToStep(taskId, i, snap);
      }

      if (isPageChange && stepScreenshots) {
        const snap = await captureCurrentTab();
        if (snap) {
          appendScreenshotToStep(taskId, i, snap);
          if (i + 1 < steps.length) {
            const nextIsScreenshot = steps[i+1].type === 'screenshot';
            const nextIsAnalyze = steps[i+1].type === 'analyze';
            if (!nextIsScreenshot && !nextIsAnalyze) {
              conversationHistory.push({
                role: 'user',
                content: [
                  { type: 'image_url', image_url: { url: snap } },
                  { type: 'text', text: `[Navigated to new page after step ${i+1}. Page structure may have changed. Continue with remaining steps efficiently.]` }
                ]
              });
            }
          }
        }
      }

      if (result?.data && !['analyze','screenshot'].includes(step.type)) {
        appendDataToStep(taskId, i, result.data);
      }

      if (result?.strategy) {
        conversationHistory.push({
          role: 'user',
          content: `[Step ${i+1} strategy]: Used "${result.strategy}" found by ${result.foundBy} in ${result.elapsed}ms`
        });
      }

      completed++;
      updateProgress(taskId, (completed/steps.length)*100);
      await delay(Math.max(50, step.type === 'screenshot' ? 200 : 80));

    } catch (err) {
      consecutiveErrors++;
      setStepStatus(taskId, i, 'error');
      appendErrorToStep(taskId, i, err.message);
      lastError = err;
      showTyping(`Error: ${err.message}. Retrying…`);

      const recovery = await attemptRecovery(step);
      if (recovery) {
        setStepStatus(taskId, i, 'done');
        consecutiveErrors = 0;
        completed++;
        updateProgress(taskId, (completed/steps.length)*100);
        continue;
      }

      for (let j = i+1; j < steps.length; j++) setStepStatus(taskId, j, 'skipped');
      break;
    }
  }

  hideTyping(); activeTask = null;
  const stopped = stopRequested; stopRequested = false;
  const banner = document.createElement('div');

  if (stopped) {
    banner.className = 'task-failed-banner'; banner.innerHTML = '⏹ Stopped by user';
  } else if (lastError) {
    banner.className = 'task-failed-banner'; banner.innerHTML = `⚠️ Stopped: ${escapeHtml(lastError.message)}`;
    await summarizeAndContinue(plan, steps, completed, lastError.message);
  } else {
    banner.className = 'task-complete-banner'; banner.innerHTML = `✓ Complete — ${completed}/${steps.length} steps`;
    await summarizeAndContinue(plan, steps, completed, null);
  }

  footer.innerHTML = '';
  const card = document.getElementById(taskId);
  if (card) card.appendChild(banner);
  setBadge('chat');
  scrollToBottom();
}

// V4: Undo button for each step
function addUndoButtonToStep(taskId, index) {
  const stepEl = document.getElementById(`${taskId}-step-${index}`);
  if (!stepEl) return;
  
  const undoBtn = document.createElement('button');
  undoBtn.className = 'step-undo-btn';
  undoBtn.innerHTML = '↩ Undo';
  undoBtn.title = 'Undo this action';
  undoBtn.onclick = async (e) => {
    e.stopPropagation();
    undoBtn.disabled = true;
    undoBtn.textContent = '↺ Undoing…';
    try {
      const result = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ type: 'DOM_ACTION', action: { type: 'undo', description: 'Undo last action' }, tabId: targetTabId }, res => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else if (res?.success === false) reject(new Error(res.error||'Undo failed'));
          else resolve(res);
        });
      });
      undoBtn.textContent = '✓ Undone';
      undoBtn.className = 'step-undo-btn undone';
      addAssistantMessage(`↩ Undid: ${result.message || 'last action'}`);
    } catch(err) {
      undoBtn.textContent = '✕ Failed';
      undoBtn.className = 'step-undo-btn error';
      addAssistantMessage(`⚠️ Undo failed: ${err.message}`);
    }
    setTimeout(() => { undoBtn.remove(); }, 2000);
  };
  stepEl.querySelector('.step-info')?.appendChild(undoBtn);
}

// V4: Security confirmation handler
function handleSecurityConfirm(fieldCategory, step) {
  return new Promise((resolve) => {
    const msg = document.createElement('div');
    msg.className = 'security-confirm';
    msg.innerHTML = `
      <div class="security-icon">🔒</div>
      <div class="security-text">
        <strong>Sensitive Field Detected</strong>
        <span>Viora wants to fill a <strong>${fieldCategory}</strong> field: "${step.description || step.selector || ''}"</span>
      </div>
      <div class="security-buttons">
        <button class="btn-allow" id="secAllow">Allow</button>
        <button class="btn-deny" id="secDeny">Skip</button>
      </div>
    `;
    messagesEl.appendChild(msg);
    scrollToBottom();
    
    document.getElementById('secAllow').onclick = () => { msg.remove(); resolve(true); };
    document.getElementById('secDeny').onclick = () => { msg.remove(); resolve(false); };
  });
}

async function attemptRecovery(step) {
  if (consecutiveErrors > 2) return null;
  await delay(800);
  const snap = await captureCurrentTab();
  if (!snap) return null;
  try {
    const result = await executeStep(step);
    return { screenshot: snap, result };
  } catch(e) {
    if (step.text) {
      const coordStep = { type: 'click_at', x: 0, y: 0, description: `Fallback: ${step.text}` };
      try { await executeStep(coordStep); return { screenshot: snap }; } catch(_) {}
    }
    return null;
  }
}

async function summarizeAndContinue(plan, steps, completed, error) {
  const summary = error ? `Task failed at step ${completed+1}: ${error}` : `Task completed: ${completed}/${steps.length} steps done`;
  let ctx = `[Result]: ${summary}\n[Goal]: ${plan.title}\nLook at the screenshot. Is the goal fully done? If more pages/steps remain, produce an efficient action_plan with batched steps. If done, just say so.`;

  const snap = await captureCurrentTab();
  if (snap) {
    conversationHistory.push({
      role: 'user',
      content: [
        { type: 'image_url', image_url: { url: snap } },
        { type: 'text', text: `${ctx}\n\n${await getEnhancedPageContext()||''}` }
      ]
    });
  } else {
    conversationHistory.push({ role: 'user', content: ctx });
  }

  showTyping("Checking results…");
  try {
    const reply = await callAI(conversationHistory);
    hideTyping();
    conversationHistory.push({ role: 'assistant', content: reply });
    const { plan: nextPlan, visibleText } = extractActionPlan(reply);
    if (nextPlan) {
      if (visibleText) addAssistantMessage(visibleText);
      renderTaskCard(nextPlan);
      setBadge('actions');
      const tid = document.querySelector('.task-card:last-child')?.id;
      if (tid) setTimeout(() => startTask(tid, nextPlan), 200);
      return;
    }
    addAssistantMessage(reply);
  } catch(err) {
    hideTyping();
    if (err.name !== 'AbortError') console.warn(err);
  }
}

function requestStop() { stopRequested = true; }

function discardTask(taskId) {
  const card = document.getElementById(taskId);
  if (card) { card.style.opacity = '0'; card.style.transform = 'scale(0.97)'; card.style.transition = 'all 0.2s'; setTimeout(() => card.remove(), 200); }
  setBadge('chat');
}

async function executeStep(step) {
  if (step.type === 'screenshot') return { success: true, screenshot: await captureCurrentTab() };
  if (step.type === 'navigate') {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'NAVIGATE', url: step.url, tabId: targetTabId }, res => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else if (res?.error) reject(new Error(res.error));
        else resolve(res);
      });
    });
  }
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: 'DOM_ACTION', action: step, tabId: targetTabId }, res => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else if (res?.success === false) reject(new Error(res.error||'Action failed'));
      else resolve(res||{success:true});
    });
  });
}

function setStepStatus(taskId, index, status) {
  const el = document.getElementById(`${taskId}-status-${index}`);
  if (el) { el.className = `step-status ${status}`; el.textContent = stepStatusIcon(status); }
}

function updateProgress(taskId, percent) {
  const bar = document.getElementById(`${taskId}-progress`);
  if (bar) bar.style.width = percent + '%';
}

function appendScreenshotToStep(taskId, index, dataUrl) {
  const el = document.getElementById(`${taskId}-steps`);
  const img = document.createElement('img');
  img.src = dataUrl; img.className = 'step-screenshot'; el.appendChild(img);
}

function appendDataToStep(taskId, index, data) {
  const el = document.getElementById(`${taskId}-steps`);
  const d = document.createElement('div');
  d.className = 'data-preview';
  d.textContent = (data||'').slice(0,600) + ((data||'').length > 600 ? '…' : '');
  el.appendChild(d);
}

function appendErrorToStep(taskId, index, message) {
  const stepEl = document.getElementById(`${taskId}-step-${index}`);
  if (!stepEl) return;
  const errEl = document.createElement('div');
  errEl.className = 'step-error'; errEl.textContent = message;
  stepEl.querySelector('.step-info').appendChild(errEl);
}

async function captureAndAttach() {
  const shot = await captureCurrentTab();
  if (shot) { pendingScreenshot = shot; screenshotPreview.src = shot; screenshotBar.style.display = 'flex'; document.getElementById('attachScreenBtn').classList.add('active'); }
}

function addUserMessage(text, screenshot) {
  hideWelcome();
  const div = document.createElement('div'); div.className = 'message user';
  let html = `<div class="msg-label">You</div><div class="msg-bubble">${escapeHtml(text)}</div>`;
  if (screenshot) html += `<img src="${screenshot}" class="msg-screenshot" />`;
  div.innerHTML = html; messagesEl.appendChild(div); scrollToBottom();
}

function addAssistantMessage(text) {
  const { visibleText } = extractActionPlan(text);
  const cleaned = (visibleText||text).trim();
  if (!cleaned) return;
  const div = document.createElement('div'); div.className = 'message assistant';
  div.innerHTML = `<div class="msg-label">Viora</div><div class="msg-bubble">${formatMarkdown(cleaned)}</div>`;
  messagesEl.appendChild(div); scrollToBottom();
}

function formatMarkdown(text) {
  return text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/```[\s\S]*?```/g,'').replace(/`([^`]+)`/g,'<code>$1</code>')
    .replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/\*(.+?)\*/g,'<em>$1</em>')
    .replace(/^### (.+)$/gm,'<strong>$1</strong>').replace(/^## (.+)$/gm,'<strong>$1</strong>')
    .replace(/^# (.+)$/gm,'<strong>$1</strong>').replace(/^\- (.+)$/gm,'• $1')
    .replace(/\n\n/g,'</p><p>').replace(/\n/g,'<br>');
}

function extractActionPlan(response) {
  const t = response.trim();
  if (t.startsWith('{"type":"action_plan"') || t.startsWith('{ "type": "action_plan"')) {
    try { const p = JSON.parse(t); if (p?.type === 'action_plan') return { plan: p, visibleText: '' }; } catch(_) {}
  }
  let i = 0;
  while (i < response.length) {
    const brace = response.indexOf('{', i);
    if (brace === -1) break;
    let depth = 0, j = brace;
    while (j < response.length) {
      if (response[j] === '{') depth++;
      else if (response[j] === '}') { depth--; if (depth === 0) break; }
      j++;
    }
    if (depth === 0) {
      try { const p = JSON.parse(response.slice(brace, j+1)); if (p?.type === 'action_plan') return { plan: p, visibleText: (response.slice(0,brace)+response.slice(j+1)).trim() }; } catch(_) {}
    }
    i = brace + 1;
  }
  return { plan: null, visibleText: response };
}

function escapeHtml(str) { return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
function hideWelcome() { if (welcomeEl) welcomeEl.style.display = 'none'; }

function showTyping(msg = 'Thinking…') {
  typingText.textContent = msg; typingIndicator.style.display = 'flex';
  sendBtn.style.display = 'none'; stopInputBtn.style.display = 'flex'; scrollToBottom();
}

function hideTyping() {
  typingIndicator.style.display = 'none'; stopInputBtn.style.display = 'none';
  sendBtn.style.display = ''; sendBtn.disabled = chatInput.value.trim() === '';
}

function scrollToBottom() { messagesEl.scrollTop = messagesEl.scrollHeight; }
function setBadge(mode) { modeBadge.textContent = mode === 'actions' ? 'Actions' : 'Chat'; modeBadge.className = 'mode-badge' + (mode === 'actions' ? ' actions' : ''); }

function clearConversation() {
  conversationHistory = []; consecutiveErrors = 0; messagesEl.innerHTML = '';
  const w = document.createElement('div'); w.id = 'welcome'; w.className = 'welcome';
  w.innerHTML = `<div class="welcome-icon"><svg width="40" height="40" viewBox="0 0 40 40" fill="none"><circle cx="20" cy="20" r="19" fill="url(#wGrad2)"/><polyline points="10,15 20,27 30,15" stroke="white" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/><circle cx="20" cy="11" r="3" fill="#34d399"/><defs><linearGradient id="wGrad2" x1="0" y1="0" x2="40" y2="40"><stop offset="0%" stop-color="#6366f1"/><stop offset="100%" stop-color="#8b5cf6"/></linearGradient></defs></svg></div><h2>Hi, I'm Viora V4</h2><p>Adaptive automation with undo, security awareness, and speed intelligence. Just tell me what to do.</p>`;
  messagesEl.appendChild(w); setBadge('chat');
}

function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

window.startTask = startTask; window.discardTask = discardTask; window.requestStop = requestStop;
init();
