// Viora Content Script
// Injected into pages to perform DOM automation

// Prevent duplicate listener registration
if (!window.__vioraLoaded) {
  window.__vioraLoaded = true;

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'DOM_ACTION') {
      handleDomAction(message.action)
        .then(sendResponse)
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true;
    }

    if (message.type === 'GET_PAGE_CONTENT') {
      sendResponse({
        success: true,
        title: document.title,
        url: window.location.href,
        text: document.body.innerText.slice(0, 10000),
        html: document.body.innerHTML.slice(0, 5000)
      });
      return true;
    }

    if (message.type === 'PING') {
      sendResponse({ alive: true });
      return true;
    }
  });
}

// ─── Visual highlight overlay ──────────────────────────────────────────────
function highlightElement(el) {
  el.style.outline = '2px solid #818cf8';
  el.style.outlineOffset = '2px';
  el.style.transition = 'outline 0.2s';
  setTimeout(() => {
    el.style.outline = '';
    el.style.outlineOffset = '';
  }, 1500);
}

// ─── Main action dispatcher ───────────────────────────────────────────────
async function handleDomAction(action) {
  await delay(100);

  switch (action.type) {

    case 'click': {
      let el = findElement(action);
      if (!el) throw new Error(`Element not found: ${action.selector || action.text || action.description}`);

      // If it's a label, resolve to the actual input it controls
      if (el.tagName === 'LABEL') {
        const forId = el.getAttribute('for') || el.htmlFor;
        const input = forId
          ? document.getElementById(forId)
          : el.querySelector('input[type="radio"], input[type="checkbox"], input');
        if (input) el = input;
      }

      scrollToElement(el);
      await delay(300);
      highlightElement(el);

      // Get element centre for realistic pointer coordinates
      const rect = el.getBoundingClientRect();
      const cx = Math.round(rect.left + rect.width / 2);
      const cy = Math.round(rect.top + rect.height / 2);
      const ptrOpts = { bubbles: true, cancelable: true, clientX: cx, clientY: cy, pointerId: 1, isPrimary: true };
      const msOpts  = { bubbles: true, cancelable: true, clientX: cx, clientY: cy };

      // Full pointer + mouse event sequence (covers React, Angular, Vue, Qualtrics, etc.)
      el.dispatchEvent(new PointerEvent('pointerover',  { ...ptrOpts, bubbles: true }));
      el.dispatchEvent(new MouseEvent ('mouseover',     msOpts));
      el.dispatchEvent(new PointerEvent('pointermove',  ptrOpts));
      el.dispatchEvent(new MouseEvent ('mousemove',     msOpts));
      el.dispatchEvent(new PointerEvent('pointerdown',  ptrOpts));
      el.dispatchEvent(new MouseEvent ('mousedown',     msOpts));
      el.focus();
      await delay(30);
      el.dispatchEvent(new PointerEvent('pointerup',    ptrOpts));
      el.dispatchEvent(new MouseEvent ('mouseup',       msOpts));
      el.dispatchEvent(new MouseEvent ('click',         msOpts));
      el.click();

      // For radio buttons and checkboxes — explicitly set state + fire change
      if (el.type === 'radio') {
        el.checked = true;
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new Event('input',  { bubbles: true }));
      } else if (el.type === 'checkbox') {
        const next = action.checked !== undefined ? action.checked : !el.checked;
        el.checked = next;
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new Event('input',  { bubbles: true }));
      }

      // Trigger React synthetic event system if present
      const fiberKey = Object.keys(el).find(k => k.startsWith('__reactFiber') || k.startsWith('__reactInternalInstance'));
      if (fiberKey) {
        const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
        if (nativeInputValueSetter && el.value !== undefined) {
          nativeInputValueSetter.call(el, el.value);
        }
        el.dispatchEvent(new Event('input', { bubbles: true }));
      }

      await delay(250);
      return { success: true, message: `Clicked: ${action.description || action.selector || action.text}` };
    }

    case 'fill': {
      const el = findElement(action);
      if (!el) throw new Error(`Input field not found: ${action.selector || action.description}`);
      scrollToElement(el);
      await delay(200);
      highlightElement(el);
      el.focus();

      // Use React's native value setter if present (bypasses controlled-input guard)
      const proto = el.tagName === 'TEXTAREA'
        ? window.HTMLTextAreaElement.prototype
        : window.HTMLInputElement.prototype;
      const nativeSetter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;

      const setValue = (v) => {
        if (nativeSetter) nativeSetter.call(el, v);
        else el.value = v;
      };

      // Clear
      setValue('');
      el.dispatchEvent(new Event('input',  { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));

      // Type character by character
      for (const char of String(action.value)) {
        setValue(el.value + char);
        el.dispatchEvent(new Event('input',  { bubbles: true }));
        await delay(18);
      }

      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new Event('blur',   { bubbles: true }));
      return { success: true, message: `Filled "${action.description || action.selector}" with value` };
    }

    case 'clear': {
      const el = findElement(action);
      if (!el) throw new Error(`Element not found: ${action.selector}`);
      el.value = '';
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return { success: true, message: 'Cleared field' };
    }

    case 'select': {
      const el = findElement(action);
      if (!el) throw new Error(`Select element not found: ${action.selector}`);
      scrollToElement(el);
      el.focus();
      el.value = action.value;
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return { success: true, message: `Selected option: ${action.value}` };
    }

    case 'check': {
      let el = findElement(action);
      if (!el) throw new Error(`Checkbox not found: ${action.selector}`);
      if (el.tagName === 'LABEL') {
        const forId = el.getAttribute('for') || el.htmlFor;
        const input = forId ? document.getElementById(forId) : el.querySelector('input');
        if (input) el = input;
      }
      const shouldCheck = action.checked !== false;
      scrollToElement(el);
      highlightElement(el);
      if (el.checked !== shouldCheck) {
        el.checked = shouldCheck;
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new Event('input',  { bubbles: true }));
        el.click();
      }
      return { success: true, message: `${shouldCheck ? 'Checked' : 'Unchecked'}: ${action.description}` };
    }

    case 'scroll': {
      if (action.selector) {
        const el = document.querySelector(action.selector);
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } else if (action.toBottom) {
        window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
      } else if (action.toTop) {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        window.scrollBy({ top: action.y || 400, behavior: 'smooth' });
      }
      await delay(500);
      return { success: true, message: 'Scrolled' };
    }

    case 'extract': {
      let data = '';
      if (action.selector) {
        const els = [...document.querySelectorAll(action.selector)];
        if (els.length === 0) throw new Error(`No elements matched: ${action.selector}`);
        data = els.map(el => el.innerText || el.textContent || el.value).join('\n---\n');
      } else {
        data = document.body.innerText;
      }
      return { success: true, data: data.slice(0, 8000), message: `Extracted data from page` };
    }

    case 'extract_links': {
      const baseUrl = window.location.origin;
      const links = [...document.querySelectorAll(action.selector || 'a[href]')]
        .map(a => ({ text: a.textContent.trim(), href: a.href }))
        .filter(l => l.href && l.text)
        .slice(0, 50);
      return { success: true, data: JSON.stringify(links, null, 2), message: 'Extracted links' };
    }

    case 'extract_table': {
      const table = findElement(action) || document.querySelector('table');
      if (!table) throw new Error('No table found');
      const rows = [...table.querySelectorAll('tr')].map(row =>
        [...row.querySelectorAll('th, td')].map(cell => cell.innerText.trim())
      );
      return { success: true, data: JSON.stringify(rows, null, 2), message: 'Extracted table' };
    }

    case 'wait_for': {
      const found = await waitForElement(action.selector, action.timeout || 5000);
      if (!found) throw new Error(`Timed out waiting for: ${action.selector}`);
      return { success: true, message: `Element appeared: ${action.selector}` };
    }

    case 'click_at': {
      // Convert screenshot coordinates → viewport coordinates.
      // Screenshots are captured at device pixel ratio, so we divide by DPR.
      const dpr = window.devicePixelRatio || 1;
      const vx  = action.x / dpr;
      const vy  = action.y / dpr;

      // elementFromPoint only sees what's in the viewport — scroll to bring y into view first
      const pageY = vy + window.scrollY;
      if (pageY > window.scrollY + window.innerHeight || pageY < window.scrollY) {
        window.scrollTo({ top: Math.max(0, pageY - window.innerHeight / 2), behavior: 'instant' });
        await delay(300);
      }

      let el = document.elementFromPoint(vx, vy);

      // If coords land on body/html or miss entirely, try without DPR scaling
      if (!el || el === document.body || el === document.documentElement) {
        el = document.elementFromPoint(action.x, action.y);
      }

      if (!el || el === document.body || el === document.documentElement) {
        throw new Error(`No element found at (${action.x}, ${action.y})`);
      }

      // Walk up the DOM to find the nearest clickable ancestor
      let target = el;
      while (target && target !== document.body) {
        const tag = target.tagName;
        if (
          tag === 'BUTTON' || tag === 'A' || tag === 'INPUT' || tag === 'LABEL' ||
          target.getAttribute('role') === 'button' ||
          target.getAttribute('role') === 'link' ||
          target.onclick != null ||
          target.getAttribute('onclick')
        ) break;
        target = target.parentElement;
      }
      el = (target && target !== document.body) ? target : el;

      scrollToElement(el);
      await delay(200);
      highlightElement(el);

      const rect    = el.getBoundingClientRect();
      const cx      = Math.round(rect.left + rect.width  / 2);
      const cy      = Math.round(rect.top  + rect.height / 2);
      const ptrOpts = { bubbles: true, cancelable: true, clientX: cx, clientY: cy, pointerId: 1, isPrimary: true };
      const msOpts  = { bubbles: true, cancelable: true, clientX: cx, clientY: cy };

      el.dispatchEvent(new PointerEvent('pointerover', { ...ptrOpts, bubbles: true }));
      el.dispatchEvent(new MouseEvent ('mouseover',    msOpts));
      el.dispatchEvent(new PointerEvent('pointerdown', ptrOpts));
      el.dispatchEvent(new MouseEvent ('mousedown',    msOpts));
      el.focus();
      await delay(30);
      el.dispatchEvent(new PointerEvent('pointerup',   ptrOpts));
      el.dispatchEvent(new MouseEvent ('mouseup',      msOpts));
      el.dispatchEvent(new MouseEvent ('click',        msOpts));
      el.click();

      await delay(250);
      return { success: true, message: `Clicked at (${action.x}, ${action.y}): ${el.tagName} "${(el.textContent || '').trim().slice(0, 40)}"` };
    }

    case 'hover': {
      const el = findElement(action);
      if (!el) throw new Error(`Element not found: ${action.selector}`);
      scrollToElement(el);
      el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
      el.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true }));
      await delay(300);
      return { success: true, message: 'Hovered over element' };
    }

    case 'press_key': {
      const el = action.selector ? findElement(action) : document.activeElement;
      const target = el || document.body;
      const keyData = { key: action.key, keyCode: action.keyCode || 0, bubbles: true, cancelable: true };
      target.dispatchEvent(new KeyboardEvent('keydown', keyData));
      target.dispatchEvent(new KeyboardEvent('keyup', keyData));
      return { success: true, message: `Pressed key: ${action.key}` };
    }

    case 'get_text': {
      const el = findElement(action);
      if (!el) throw new Error(`Element not found: ${action.selector}`);
      return { success: true, data: el.innerText || el.textContent || el.value, message: 'Got text' };
    }

    case 'get_page_info': {
      return {
        success: true,
        title: document.title,
        url: window.location.href,
        text: document.body.innerText.slice(0, 5000)
      };
    }

    default:
      throw new Error(`Unknown action type: ${action.type}`);
  }
}

// ─── Element finder ────────────────────────────────────────────────────────
function findElement(action) {
  // Try CSS selector first
  if (action.selector) {
    try {
      const el = document.querySelector(action.selector);
      if (el) return el;
    } catch (_) {}

    // If the selector was "tag[attr=...]", the AI may have got the tag wrong.
    // Strip the tag prefix and retry — e.g. "div[id='NextButton']" → "[id='NextButton']"
    try {
      const stripped = action.selector.replace(/^[a-zA-Z]+(\[)/, '$1');
      if (stripped !== action.selector) {
        const el = document.querySelector(stripped);
        if (el) return el;
      }
    } catch (_) {}

    // Also try turning attribute selector into a plain #id selector
    try {
      const idMatch = action.selector.match(/\[id=['"]?([^'"=\]]+)['"]?\]/);
      if (idMatch) {
        const el = document.getElementById(idMatch[1]);
        if (el) return el;
      }
    } catch (_) {}
  }

  // Find by visible text content
  if (action.text) {
    const query = action.text.toLowerCase().trim();
    const candidates = [
      ...document.querySelectorAll('button, a, [role="button"], input[type="submit"], input[type="button"], label')
    ];
    for (const el of candidates) {
      const text = (el.textContent || el.value || el.placeholder || el.ariaLabel || '').toLowerCase().trim();
      if (text.includes(query) || query.includes(text)) return el;
    }
    // Wider search — leaf nodes with exact text match
    const all = document.querySelectorAll('*');
    for (const el of all) {
      if (el.children.length === 0) {
        const text = el.textContent.trim().toLowerCase();
        if (text === query) return el;
      }
    }
  }

  // Find by placeholder
  if (action.placeholder) {
    const el = document.querySelector(`[placeholder*="${action.placeholder}"]`);
    if (el) return el;
  }

  // Find by aria-label
  if (action.ariaLabel) {
    const el = document.querySelector(`[aria-label*="${action.ariaLabel}"]`);
    if (el) return el;
  }

  // Find by name attribute
  if (action.name) {
    const el = document.querySelector(`[name="${action.name}"]`);
    if (el) return el;
  }

  // Find by id
  if (action.id) {
    const el = document.getElementById(action.id);
    if (el) return el;
  }

  // ── Smart fallback: common Next / Submit / navigation button patterns ──
  // Runs when description or selector text hints at a navigation button.
  const hint = (
    (action.description || '') + ' ' +
    (action.selector   || '') + ' ' +
    (action.text       || '')
  ).toLowerCase();

  if (/next|submit|continue|proceed|forward|done|finish|ok\b/.test(hint)) {
    // 1. ID-based patterns used by major survey platforms
    const idPatterns = ['NextButton', 'next-button', 'nextButton', 'submitButton',
                        'submit-button', 'continueButton', 'btnNext', 'btn-next',
                        'nextBtn', 'submitBtn', 'nextPage'];
    for (const id of idPatterns) {
      const el = document.getElementById(id);
      if (el) return el;
    }

    // 2. Buttons / inputs whose visible label matches
    const navKeywords = /^(next|continue|proceed|submit|done|finish|ok|forward|go|advance)$/i;
    const clickables = [
      ...document.querySelectorAll(
        'button, input[type="submit"], input[type="button"], [role="button"], a'
      )
    ];
    for (const el of clickables) {
      const label = (el.textContent || el.value || el.getAttribute('aria-label') || '').trim();
      if (navKeywords.test(label)) return el;
    }

    // 3. Any button containing "next" or "submit" in its text
    for (const el of clickables) {
      const label = (el.textContent || el.value || '').toLowerCase();
      if (label.includes('next') || label.includes('submit') || label.includes('continue')) return el;
    }
  }

  return null;
}

function scrollToElement(el) {
  el.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function waitForElement(selector, timeout = 5000) {
  return new Promise(resolve => {
    if (document.querySelector(selector)) { resolve(true); return; }
    const observer = new MutationObserver(() => {
      if (document.querySelector(selector)) {
        observer.disconnect();
        resolve(true);
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    setTimeout(() => { observer.disconnect(); resolve(false); }, timeout);
  });
}
