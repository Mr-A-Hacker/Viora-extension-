// Viora Settings Logic

const apiKeyInput = document.getElementById('apiKeyInput');
const modelSelect = document.getElementById('modelSelect');
const autoScreenshot = document.getElementById('autoScreenshot');
const stepScreenshots = document.getElementById('stepScreenshots');
const saveBtn = document.getElementById('saveBtn');
const saveFeedback = document.getElementById('saveFeedback');
const toggleKeyBtn = document.getElementById('toggleKeyBtn');

// Load saved settings
async function loadSettings() {
  const data = await chrome.storage.local.get([
    'apiKey', 'model', 'autoScreenshot', 'stepScreenshots'
  ]);

  if (data.apiKey) apiKeyInput.value = data.apiKey;
  if (data.model) modelSelect.value = data.model;
  autoScreenshot.checked = data.autoScreenshot === true;
  stepScreenshots.checked = data.stepScreenshots !== false; // default true
}

// Save settings
async function saveSettings() {
  const apiKey = apiKeyInput.value.trim();
  const model = modelSelect.value;

  if (!apiKey) {
    showFeedback('⚠ API key is required', 'error');
    apiKeyInput.focus();
    return;
  }

  await chrome.storage.local.set({
    apiKey,
    model,
    autoScreenshot: autoScreenshot.checked,
    stepScreenshots: stepScreenshots.checked
  });

  showFeedback('✓ Saved!');
}

function showFeedback(msg, type = 'success') {
  saveFeedback.textContent = msg;
  saveFeedback.style.color = type === 'error' ? '#f87171' : '#34d399';
  saveFeedback.style.opacity = '1';
  setTimeout(() => {
    saveFeedback.style.opacity = '0';
  }, 2500);
}

// Toggle API key visibility
let keyVisible = false;
toggleKeyBtn.addEventListener('click', () => {
  keyVisible = !keyVisible;
  apiKeyInput.type = keyVisible ? 'text' : 'password';
  toggleKeyBtn.querySelector('#eyeIcon').innerHTML = keyVisible
    ? `<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>`
    : `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>`;
});

saveBtn.addEventListener('click', saveSettings);

// Save on Enter in key field
apiKeyInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') saveSettings();
});

loadSettings();
