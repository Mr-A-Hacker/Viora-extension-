// Viora Background Service Worker
// Handles: side panel, screenshots, tab control, content script bridge

// Open side panel on toolbar button click
chrome.action.onClicked.addListener(async (tab) => {
  await chrome.sidePanel.open({ tabId: tab.id });
});

// Enable side panel on all tabs
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});

// ─── Helper: resolve target tab (uses pinned tabId or falls back to active) ──
async function resolveTab(preferredTabId) {
  if (preferredTabId) {
    return new Promise(resolve => chrome.tabs.get(preferredTabId, tab => {
      if (chrome.runtime.lastError || !tab) resolve(null);
      else resolve(tab);
    }));
  }
  return new Promise(resolve => {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => resolve(tabs[0] || null));
  });
}

// Message router from sidepanel / content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  // List all open tabs (for @ picker)
  if (message.type === 'LIST_TABS') {
    chrome.tabs.query({}, (tabs) => {
      sendResponse({ tabs: tabs.map(t => ({ id: t.id, title: t.title, url: t.url, favIconUrl: t.favIconUrl })) });
    });
    return true;
  }

  // Screenshot — only works when tab is the visible (active) tab
  if (message.type === 'CAPTURE_SCREENSHOT') {
    resolveTab(message.tabId).then(tab => {
      if (!tab) { sendResponse({ error: 'No tab' }); return; }
      // If targeting a background tab, skip screenshot gracefully
      chrome.tabs.query({ active: true, currentWindow: true }, activeList => {
        if (message.tabId && activeList[0]?.id !== message.tabId) {
          sendResponse({ screenshot: null, skipped: true });
          return;
        }
        chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 80 }, (dataUrl) => {
          if (chrome.runtime.lastError) sendResponse({ error: chrome.runtime.lastError.message });
          else sendResponse({ screenshot: dataUrl });
        });
      });
    });
    return true;
  }

  // Navigate tab to URL
  if (message.type === 'NAVIGATE') {
    resolveTab(message.tabId).then(async tab => {
      if (!tab) { sendResponse({ error: 'No tab' }); return; }
      try {
        await chrome.tabs.update(tab.id, { url: message.url });
        const done = await waitForTabLoad(tab.id);
        sendResponse({ success: true, loaded: done });
      } catch (e) { sendResponse({ error: e.message }); }
    });
    return true;
  }

  // Open a new tab
  if (message.type === 'OPEN_TAB') {
    chrome.tabs.create({ url: message.url, active: true }, (tab) => {
      waitForTabLoad(tab.id).then(() => sendResponse({ success: true, tabId: tab.id }));
    });
    return true;
  }

  // Get tab info
  if (message.type === 'GET_TAB_INFO') {
    resolveTab(message.tabId).then(tab => {
      if (tab) sendResponse({ url: tab.url, title: tab.title, tabId: tab.id });
      else sendResponse({ error: 'No tab' });
    });
    return true;
  }

  // Relay DOM action to content script (works on non-active tabs too)
  if (message.type === 'DOM_ACTION') {
    resolveTab(message.tabId).then(async tab => {
      if (!tab) { sendResponse({ error: 'No tab' }); return; }
      const tabId = tab.id;
      const tabUrl = tab.url || '';

      if (tabUrl.startsWith('chrome://') || tabUrl.startsWith('chrome-extension://') ||
          tabUrl.startsWith('about:') || tabUrl.startsWith('edge://') ||
          tabUrl.startsWith('devtools://') || tabUrl === '') {
        sendResponse({
          success: false,
          error: `Cannot automate this page (${tabUrl.split('/')[0]}// pages are restricted). Navigate to a regular website first.`
        });
        return;
      }

      try {
        await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
      } catch (_) {}

      await new Promise(r => setTimeout(r, 150));

      try {
        const result = await chrome.tabs.sendMessage(tabId, { type: 'DOM_ACTION', action: message.action });
        sendResponse(result);
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    });
    return true;
  }

  // Get page content/text for AI context
  if (message.type === 'GET_PAGE_CONTENT') {
    resolveTab(message.tabId).then(async tab => {
      if (!tab) { sendResponse({ error: 'No tab' }); return; }
      try {
        const result = await chrome.tabs.sendMessage(tab.id, { type: 'GET_PAGE_CONTENT' });
        sendResponse(result);
      } catch (e) { sendResponse({ error: e.message }); }
    });
    return true;
  }
});

function waitForTabLoad(tabId, timeout = 8000) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(false);
    }, timeout);
    function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        setTimeout(() => resolve(true), 600);
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}
