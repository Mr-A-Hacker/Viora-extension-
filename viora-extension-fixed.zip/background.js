// Viora Background Service Worker
// Handles: side panel, screenshots, tab control, content script bridge

// Open side panel on toolbar button click
chrome.action.onClicked.addListener(async (tab) => {
  await chrome.sidePanel.open({ tabId: tab.id });
});

// Enable side panel on all tabs
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});

// Message router from sidepanel / content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  // Screenshot of visible tab
  if (message.type === 'CAPTURE_SCREENSHOT') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) { sendResponse({ error: 'No active tab' }); return; }
      chrome.tabs.captureVisibleTab(tabs[0].windowId, { format: 'jpeg', quality: 80 }, (dataUrl) => {
        if (chrome.runtime.lastError) {
          sendResponse({ error: chrome.runtime.lastError.message });
        } else {
          sendResponse({ screenshot: dataUrl });
        }
      });
    });
    return true; // keep channel open for async
  }

  // Navigate tab to URL
  if (message.type === 'NAVIGATE') {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (!tabs[0]) { sendResponse({ error: 'No active tab' }); return; }
      try {
        await chrome.tabs.update(tabs[0].id, { url: message.url });
        // Wait for load
        const tabId = tabs[0].id;
        const done = await waitForTabLoad(tabId);
        sendResponse({ success: true, loaded: done });
      } catch (e) {
        sendResponse({ error: e.message });
      }
    });
    return true;
  }

  // Open a new tab
  if (message.type === 'OPEN_TAB') {
    chrome.tabs.create({ url: message.url, active: true }, (tab) => {
      waitForTabLoad(tab.id).then(() => sendResponse({ success: true, tabId: tab.id }));
    });
    return true;
  }

  // Get current tab info
  if (message.type === 'GET_TAB_INFO') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        sendResponse({ url: tabs[0].url, title: tabs[0].title, tabId: tabs[0].id });
      } else {
        sendResponse({ error: 'No active tab' });
      }
    });
    return true;
  }

  // Relay DOM action to content script
  if (message.type === 'DOM_ACTION') {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (!tabs[0]) { sendResponse({ error: 'No active tab' }); return; }
      const tabId = tabs[0].id;
      const tabUrl = tabs[0].url || '';

      // Can't inject into chrome://, chrome-extension://, or other restricted URLs
      if (tabUrl.startsWith('chrome://') || tabUrl.startsWith('chrome-extension://') ||
          tabUrl.startsWith('about:') || tabUrl.startsWith('edge://') ||
          tabUrl.startsWith('devtools://') || tabUrl === '') {
        sendResponse({
          success: false,
          error: `Cannot automate this page (${tabUrl.split('/')[0]}// pages are restricted). Navigate to a regular website first.`
        });
        return;
      }

      // Ensure content script is injected
      try {
        await chrome.scripting.executeScript({
          target: { tabId },
          files: ['content.js']
        });
      } catch (_) {
        // Already injected or page doesn't support it
      }

      // Small wait for script to initialise
      await new Promise(r => setTimeout(r, 150));

      try {
        const result = await chrome.tabs.sendMessage(tabId, {
          type: 'DOM_ACTION',
          action: message.action
        });
        sendResponse(result);
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    });
    return true;
  }

  // Get page content/text for AI context
  if (message.type === 'GET_PAGE_CONTENT') {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (!tabs[0]) { sendResponse({ error: 'No active tab' }); return; }
      try {
        const result = await chrome.tabs.sendMessage(tabs[0].id, { type: 'GET_PAGE_CONTENT' });
        sendResponse(result);
      } catch (e) {
        sendResponse({ error: e.message });
      }
    });
    return true;
  }
});

function waitForTabLoad(tabId, timeout = 8000) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve(false);
    }, timeout);

    function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        setTimeout(() => resolve(true), 600); // extra settle time
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}
