const apiKeyInput = document.getElementById('apiKeyInput');
const autoScreenshot = document.getElementById('autoScreenshot');
const stepScreenshots = document.getElementById('stepScreenshots');
const fastMode = document.getElementById('fastMode');
const autoConfirmSensitive = document.getElementById('autoConfirmSensitive');
const saveBtn = document.getElementById('saveBtn');
const saveFeedback = document.getElementById('saveFeedback');
const toggleKeyBtn = document.getElementById('toggleKeyBtn');
const keyPrompt = document.getElementById('keyPrompt');

async function loadSettings() {
  const data = await chrome.storage.local.get([
    'apiKey', 'autoScreenshot', 'stepScreenshots', 'fastMode', 'autoConfirmSensitive'
  ]);
  if (data.apiKey) { apiKeyInput.value = data.apiKey; hideKeyPrompt(); }
  autoScreenshot.checked = data.autoScreenshot !== false;
  stepScreenshots.checked = data.stepScreenshots !== false;
  fastMode.checked = data.fastMode === true;
  autoConfirmSensitive.checked = data.autoConfirmSensitive === true;
}

async function saveSettings() {
  const apiKey = apiKeyInput.value.trim();
  if (!apiKey) { showFeedback('⚠ API key is required', 'error'); apiKeyInput.focus(); return; }
  await chrome.storage.local.set({
    apiKey,
    autoScreenshot: autoScreenshot.checked, stepScreenshots: stepScreenshots.checked,
    fastMode: fastMode.checked, autoConfirmSensitive: autoConfirmSensitive.checked
  });
  showFeedback('✓ Saved!');
}

function showFeedback(msg, type = 'success') {
  saveFeedback.textContent = msg;
  saveFeedback.style.color = type === 'error' ? '#f87171' : '#34d399';
  saveFeedback.style.opacity = '1';
  setTimeout(() => { saveFeedback.style.opacity = '0'; }, 2500);
}

function showKeyPrompt() {
  if (!apiKeyInput.value.trim()) { keyPrompt.style.display = 'flex'; apiKeyInput.focus(); }
}

function hideKeyPrompt() { keyPrompt.style.display = 'none'; }

let keyVisible = false;
toggleKeyBtn.addEventListener('click', () => {
  keyVisible = !keyVisible;
  apiKeyInput.type = keyVisible ? 'text' : 'password';
  toggleKeyBtn.querySelector('#eyeIcon').innerHTML = keyVisible
    ? `<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>`
    : `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>`;
});

autoScreenshot.addEventListener('change', saveSettings);
stepScreenshots.addEventListener('change', saveSettings);
fastMode.addEventListener('change', saveSettings);
autoConfirmSensitive.addEventListener('change', saveSettings);
saveBtn.addEventListener('click', saveSettings);
apiKeyInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') saveSettings(); });
apiKeyInput.addEventListener('input', () => { if (apiKeyInput.value.trim()) hideKeyPrompt(); });
loadSettings();
