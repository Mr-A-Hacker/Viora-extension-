// ═══════════════════════════════════════════════════════════════════════════
// SECTION 1: DOM REFERENCES
// ═══════════════════════════════════════════════════════════════════════════

const apiKeyInput = document.getElementById('apiKeyInput');
const autoScreenshot = document.getElementById('autoScreenshot');
const stepScreenshots = document.getElementById('stepScreenshots');
const fastMode = document.getElementById('fastMode');
const autoConfirmSensitive = document.getElementById('autoConfirmSensitive');
const saveBtn = document.getElementById('saveBtn');
const saveFeedback = document.getElementById('saveFeedback');
const toggleKeyBtn = document.getElementById('toggleKeyBtn');
const keyPrompt = document.getElementById('keyPrompt');
const modelSearch = document.getElementById('modelSearch');
const modelListEl = document.getElementById('modelList');
const modelListStatus = document.getElementById('modelListStatus');
const modelCountEl = document.getElementById('modelCount');
const apiKeyModelBadge = document.getElementById('apiKeyModelBadge');
const historyListStatus = document.getElementById('historyListStatus');
const historyListEl = document.getElementById('historyList');
const historyCountEl = document.getElementById('historyCount');
const clearHistoryBtn = document.getElementById('clearHistoryBtn');

const AUTO_MODEL = 'openrouter/auto';
let allModels = []; // full fetched catalog, each: {id, name, provider, context_length, promptPrice, vision}
let selectedModel = AUTO_MODEL;
const MODEL_CACHE_KEY = 'modelCatalogCache';
const MODEL_CACHE_TTL_MS = 24 * 60 * 60 * 1000; // refetch at most once a day — the catalog doesn't change hour to hour

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 2: PROVIDER CONFIGURATION
// ═══════════════════════════════════════════════════════════════════════════

function providerOf(id) {
  return id.includes('/') ? id.split('/')[0] : 'other';
}

function providerOfSelected() {
  if (selectedModel === AUTO_MODEL) return 'openrouter';
  const model = allModels.find(m => m.id === selectedModel);
  return model ? model.provider : 'openrouter';
}

function updateApiKeyModelBadge() {
  if (!apiKeyModelBadge) return;
  const prov = providerOfSelected();
  const label = selectedModel === AUTO_MODEL
    ? 'Auto (recommended)'
    : (allModels.find(m => m.id === selectedModel)?.name || selectedModel);
  apiKeyModelBadge.textContent = `for ${label} (via ${providerLabel(prov)})`;
  apiKeyModelBadge.title = selectedModel;
  apiKeyModelBadge.style.display = 'inline-block';
  const sectionTitle = document.getElementById('apiKeySectionTitle');
  if (sectionTitle) sectionTitle.textContent = providerLabel(prov);
  const hint = document.querySelector('.field-hint');
  if (hint) {
    const link = PROVIDER_API_KEY_HINTS[prov] || PROVIDER_API_KEY_HINTS.openrouter;
    const a = hint.querySelector('a');
    if (a) {
      a.textContent = link;
      const urlMatch = link.match(/https?:\/\/[^\s]+|(?:[\w-]+\.)+[\w-]+(?:\/[^\s]*)?/);
      if (urlMatch) a.href = 'https://' + urlMatch[0].replace(/^https?:\/\//, '');
    }
  }
  const keyPromptText = document.getElementById('keyPromptText');
  if (keyPromptText) {
    keyPromptText.textContent = `Add your ${providerLabel(prov)} API key to use this model`;
  }
  apiKeyInput.placeholder = prov === 'openrouter' ? 'sk-or-v1-…' : `gsk_... or ${providerLabel(prov)} API key…`;
}

function providerLabel(p) {
  const known = {
    openai: 'OpenAI', anthropic: 'Anthropic', google: 'Google', 'meta-llama': 'Meta',
    mistralai: 'Mistral', deepseek: 'DeepSeek', 'x-ai': 'xAI', cohere: 'Cohere',
    qwen: 'Qwen', perplexity: 'Perplexity', microsoft: 'Microsoft', nvidia: 'NVIDIA',
    amazon: 'Amazon', ai21: 'AI21', groq: 'Groq',
  };
  return known[p] || (p.charAt(0).toUpperCase() + p.slice(1));
}

const PROVIDER_API_ENDPOINTS = {
  openrouter: 'https://openrouter.ai/api/v1/chat/completions',
  groq: 'https://api.groq.com/openai/v1/chat/completions',
  openai: 'https://api.openai.com/v1/chat/completions',
  deepseek: 'https://api.deepseek.com/v1/chat/completions',
  mistralai: 'https://api.mistral.ai/v1/chat/completions',
  nvidia: 'https://integrate.api.nvidia.com/v1/chat/completions',
};

const PROVIDER_API_KEY_HINTS = {
  openrouter: 'Get a free key at openrouter.ai/keys',
  groq: 'Get a free key at console.groq.com/keys',
  openai: 'Get a key at platform.openai.com/api-keys',
  deepseek: 'Get a key at platform.deepseek.com/api_keys',
  mistralai: 'Get a key at console.mistral.ai/api-keys/',
  nvidia: 'Get a key at build.nvidia.com/explore/discover',
};

const GROQ_MODELS = [
  // ── Llama 3.3 ──────────────────────────────────────────────────────────
  { id: 'groq/llama-3.3-70b-versatile', apiId: 'llama-3.3-70b-versatile', name: 'Llama 3.3 70B Versatile', provider: 'groq', context_length: 131072, promptPrice: 0.59, vision: false },
  // ── Llama 3.1 ──────────────────────────────────────────────────────────
  { id: 'groq/llama-3.1-8b-instant', apiId: 'llama-3.1-8b-instant', name: 'Llama 3.1 8B Instant', provider: 'groq', context_length: 131072, promptPrice: 0.05, vision: false },
  // ── Llama 4 ────────────────────────────────────────────────────────────
  { id: 'groq/llama-4-scout-17b-16e-instruct', apiId: 'meta-llama/llama-4-scout-17b-16e-instruct', name: 'Llama 4 Scout 17B', provider: 'groq', context_length: 16384, promptPrice: 0.20, vision: false },
  // ── Groq Compound ──────────────────────────────────────────────────────
  { id: 'groq/compound', apiId: 'groq/compound', name: 'Groq Compound', provider: 'groq', context_length: 131072, promptPrice: 0.40, vision: false },
  // ── Qwen ───────────────────────────────────────────────────────────────
  { id: 'groq/qwen3-32b', apiId: 'qwen/qwen3-32b', name: 'Qwen 3 32B', provider: 'groq', context_length: 131072, promptPrice: 0.35, vision: false },
  { id: 'groq/qwen3.6-27b', apiId: 'qwen/qwen3.6-27b', name: 'Qwen 3.6 27B', provider: 'groq', context_length: 131072, promptPrice: 0.30, vision: false },
  // ── GPT-OSS (OpenAI) ───────────────────────────────────────────────────
  { id: 'groq/gpt-oss-120b', apiId: 'openai/gpt-oss-120b', name: 'GPT-OSS 120B', provider: 'groq', context_length: 16384, promptPrice: 0.90, vision: false },
  { id: 'groq/gpt-oss-20b', apiId: 'openai/gpt-oss-20b', name: 'GPT-OSS 20B', provider: 'groq', context_length: 16384, promptPrice: 0.20, vision: false },
  // ── Allam (Arabic) ─────────────────────────────────────────────────────
  { id: 'groq/allam-2-7b', apiId: 'allam-2-7b', name: 'Allam 2 7B (Arabic)', provider: 'groq', context_length: 8192, promptPrice: 0.05, vision: false },
];

const NVIDIA_MODELS = [
  // ── Nemotron ───────────────────────────────────────────────────────────
  { id: 'nvidia/nemotron-3-ultra', apiId: 'nvidia/nemotron-3-ultra', name: 'Nemotron 3 Ultra', provider: 'nvidia', context_length: 4096, promptPrice: 0, vision: false },
  { id: 'nvidia/nemotron-4-340b-instruct', apiId: 'nvidia/nemotron-4-340b-instruct', name: 'Nemotron 4 340B Instruct', provider: 'nvidia', context_length: 4096, promptPrice: 0, vision: false },
  // ── Llama 3.1/3.2/3.3 (NVIDIA hosted) ──────────────────────────────────
  { id: 'nvidia/llama-3.1-8b-instruct', apiId: 'meta/llama-3.1-8b-instruct', name: 'Llama 3.1 8B Instruct (NVIDIA)', provider: 'nvidia', context_length: 131072, promptPrice: 0, vision: false },
  { id: 'nvidia/llama-3.1-70b-instruct', apiId: 'meta/llama-3.1-70b-instruct', name: 'Llama 3.1 70B Instruct (NVIDIA)', provider: 'nvidia', context_length: 131072, promptPrice: 0, vision: false },
  { id: 'nvidia/llama-3.2-1b-instruct', apiId: 'meta/llama-3.2-1b-instruct', name: 'Llama 3.2 1B Instruct (NVIDIA)', provider: 'nvidia', context_length: 131072, promptPrice: 0, vision: false },
  { id: 'nvidia/llama-3.2-3b-instruct', apiId: 'meta/llama-3.2-3b-instruct', name: 'Llama 3.2 3B Instruct (NVIDIA)', provider: 'nvidia', context_length: 131072, promptPrice: 0, vision: false },
  { id: 'nvidia/llama-3.3-70b-instruct', apiId: 'meta/llama-3.3-70b-instruct', name: 'Llama 3.3 70B Instruct (NVIDIA)', provider: 'nvidia', context_length: 131072, promptPrice: 0, vision: false },
  // ── Mistral (NVIDIA hosted) ────────────────────────────────────────────
  { id: 'nvidia/mistral-7b-instruct-v0.3', apiId: 'mistralai/mistral-7b-instruct-v0.3', name: 'Mistral 7B Instruct v0.3 (NVIDIA)', provider: 'nvidia', context_length: 32768, promptPrice: 0, vision: false },
  { id: 'nvidia/mistral-nemo-12b-instruct', apiId: 'mistralai/mistral-nemo-12b-instruct', name: 'Mistral NeMo 12B Instruct (NVIDIA)', provider: 'nvidia', context_length: 131072, promptPrice: 0, vision: false },
  // ── Gemma (NVIDIA hosted) ──────────────────────────────────────────────
  { id: 'nvidia/gemma-2-9b-it', apiId: 'google/gemma-2-9b-it', name: 'Gemma 2 9B IT (NVIDIA)', provider: 'nvidia', context_length: 8192, promptPrice: 0, vision: false },
  { id: 'nvidia/gemma-2-27b-it', apiId: 'google/gemma-2-27b-it', name: 'Gemma 2 27B IT (NVIDIA)', provider: 'nvidia', context_length: 8192, promptPrice: 0, vision: false },
  // ── Phi / Other ─────────────────────────────────────────────────────────
  { id: 'nvidia/phi-3-mini-4k-instruct', apiId: 'microsoft/phi-3-mini-4k-instruct', name: 'Phi-3 Mini 4K Instruct (NVIDIA)', provider: 'nvidia', context_length: 4096, promptPrice: 0, vision: false },
  { id: 'nvidia/phi-3-medium-128k-instruct', apiId: 'microsoft/phi-3-medium-128k-instruct', name: 'Phi-3 Medium 128K Instruct (NVIDIA)', provider: 'nvidia', context_length: 131072, promptPrice: 0, vision: false },
];

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 3: MODEL CATALOG
// ═══════════════════════════════════════════════════════════════════════════

async function loadModelCatalog() {
  // Serve from cache instantly if it's fresh, then refresh in the background
  // so the list is never empty/blank on open, but also never goes stale for long.
  try {
    const cached = await chrome.storage.local.get([MODEL_CACHE_KEY]);
    const c = cached[MODEL_CACHE_KEY];
    if (c && c.models && (Date.now() - c.fetchedAt) < MODEL_CACHE_TTL_MS) {
      allModels = c.models;
      renderModelList();
    }
  } catch (_) {}

  try {
    const res = await fetch('https://openrouter.ai/api/v1/models');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    const models = (json.data || [])
      .filter(m => (m.architecture?.input_modalities || []).includes('text')) // keep the list to models Viora can actually use
      .map(m => ({
        id: m.id,
        name: m.name || m.id,
        provider: providerOf(m.id),
        context_length: m.context_length || m.top_provider?.context_length || null,
        promptPrice: m.pricing?.prompt ? parseFloat(m.pricing.prompt) : null,
        vision: (m.architecture?.input_modalities || []).includes('image'),
      }))
      .sort((a, b) => providerLabel(a.provider).localeCompare(providerLabel(b.provider)) || a.name.localeCompare(b.name));
    const merged = mergeExtraModels(models);
    allModels = merged;
    await chrome.storage.local.set({ [MODEL_CACHE_KEY]: { models: merged, fetchedAt: Date.now() } });
    renderModelList();
  } catch (e) {
    if (!allModels.length) {
      allModels = mergeExtraModels([]);
      renderModelList();
      modelListStatus.textContent = `Couldn't load full model list (${e.message}). Groq & NVIDIA models still available.`;
    }
  }
}

function mergeExtraModels(models) {
  const existing = new Set(models.map(m => m.id));
  const groqToAdd = GROQ_MODELS.filter(g => !existing.has(g.id));
  const nvidiaToAdd = NVIDIA_MODELS.filter(n => !existing.has(n.id));
  if (!groqToAdd.length && !nvidiaToAdd.length) return models;
  return [...models, ...groqToAdd, ...nvidiaToAdd].sort((a, b) => providerLabel(a.provider).localeCompare(providerLabel(b.provider)) || a.name.localeCompare(b.name));
}

function formatContext(n) {
  if (!n) return '';
  if (n >= 1000) return `${Math.round(n / 1000)}K ctx`;
  return `${n} ctx`;
}

function formatPrice(p) {
  if (p === null || p === undefined) return '';
  const perM = p * 1_000_000;
  if (perM === 0) return 'free';
  return `$${perM < 1 ? perM.toFixed(2) : perM.toFixed(1)}/M`;
}

function renderModelList(filter = '') {
  const q = filter.trim().toLowerCase();
  const filtered = q
    ? allModels.filter(m => m.id.toLowerCase().includes(q) || m.name.toLowerCase().includes(q) || providerLabel(m.provider).toLowerCase().includes(q))
    : allModels;

  modelCountEl.textContent = allModels.length ? `${allModels.length}+ available` : '';
  modelListStatus.style.display = 'none';
  modelListEl.style.display = 'block';
  modelListEl.innerHTML = '';

  // Auto is always pinned at the top, filter or not — it's the sane default.
  if (!q || 'auto'.includes(q) || 'openrouter'.includes(q)) {
    modelListEl.appendChild(buildModelRow({
      id: AUTO_MODEL, name: 'Auto (recommended)', provider: 'openrouter',
      context_length: null, promptPrice: null, vision: true,
    }, true));
  }

  if (!filtered.length && q) {
    const empty = document.createElement('div');
    empty.className = 'model-list-status';
    empty.textContent = `No models matching "${filter}"`;
    modelListEl.appendChild(empty);
    return;
  }

  let lastProvider = null;
  for (const m of filtered) {
    if (m.provider !== lastProvider) {
      const header = document.createElement('div');
      header.className = 'model-group-header';
      header.textContent = providerLabel(m.provider);
      modelListEl.appendChild(header);
      lastProvider = m.provider;
    }
    modelListEl.appendChild(buildModelRow(m, false));
  }
  updateApiKeyModelBadge();
}

function buildModelRow(m, isAuto) {
  const row = document.createElement('div');
  row.className = 'model-row' + (m.id === selectedModel ? ' selected' : '');
  row.dataset.modelId = m.id;

  const main = document.createElement('div');
  main.className = 'model-row-main';
  const name = document.createElement('div');
  name.className = 'model-row-name';
  name.textContent = m.name;
  main.appendChild(name);

  const meta = document.createElement('div');
  meta.className = 'model-row-meta';
  const bits = [];
  if (!isAuto) bits.push(m.id);
  if (m.context_length) bits.push(formatContext(m.context_length));
  const price = formatPrice(m.promptPrice);
  if (price) bits.push(price);
  if (m.vision) bits.push('vision');
  meta.textContent = bits.join(' · ');
  main.appendChild(meta);
  row.appendChild(main);

  const check = document.createElement('div');
  check.className = 'model-row-check';
  check.innerHTML = m.id === selectedModel
    ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>'
    : '';
  row.appendChild(check);

  row.addEventListener('click', () => selectModel(m.id));
  return row;
}

async function selectModel(id) {
  selectedModel = id;
  await chrome.storage.local.set({ model: id });
  document.querySelectorAll('.model-row').forEach(r => {
    const isSel = r.dataset.modelId === id;
    r.classList.toggle('selected', isSel);
    r.querySelector('.model-row-check').innerHTML = isSel
      ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>'
      : '';
  });
  const prov = providerOfSelected();
  const data = await chrome.storage.local.get([`apiKey_${prov}`, 'apiKey']);
  const provKey = data[`apiKey_${prov}`] || data.apiKey || '';
  apiKeyInput.value = provKey;
  if (provKey) hideKeyPrompt(); else showKeyPrompt();
  updateApiKeyModelBadge();
  showFeedback('✓ Model updated');
}

modelSearch.addEventListener('input', () => renderModelList(modelSearch.value));

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 4: SETTINGS PERSISTENCE (load / save)
// ═══════════════════════════════════════════════════════════════════════════

async function loadSettings() {
  const data = await chrome.storage.local.get([
    'apiKey', 'apiKey_openrouter', 'apiKey_groq', 'apiKey_openai', 'apiKey_deepseek', 'apiKey_mistralai', 'apiKey_nvidia',
    'autoScreenshot', 'stepScreenshots', 'fastMode', 'autoConfirmSensitive', 'model'
  ]);
  selectedModel = data.model || AUTO_MODEL;
  const prov = providerOfSelected();
  const provKey = data[`apiKey_${prov}`] || data.apiKey || '';
  if (provKey) { apiKeyInput.value = provKey; hideKeyPrompt(); }
  autoScreenshot.checked = data.autoScreenshot !== false;
  stepScreenshots.checked = data.stepScreenshots !== false;
  fastMode.checked = data.fastMode === true;
  autoConfirmSensitive.checked = data.autoConfirmSensitive === true;
  updateApiKeyModelBadge();
  loadModelCatalog();
}

async function saveSettings(requireKey = true) {
  // BUG FIX: every checkbox (Fast Mode, Auto Confirm Sensitive, etc.) called
  // this same function on 'change', but it bailed out — without saving ANY
  // of the toggle state, and while stealing focus to the API key box — the
  // moment the key field was empty. So toggling a setting before ever
  // entering an API key silently did nothing and was disruptive besides.
  // Toggle changes now always save their own state (requireKey=false,
  // no nag/focus-steal); only the explicit Save button / Enter-in-key-field
  // path still requires and persists a non-empty key.
  await chrome.storage.local.set({
    autoScreenshot: autoScreenshot.checked, stepScreenshots: stepScreenshots.checked,
    fastMode: fastMode.checked, autoConfirmSensitive: autoConfirmSensitive.checked
  });

  if (!requireKey) { showFeedback('✓ Saved!'); return; }

  const apiKey = apiKeyInput.value.trim();
  if (!apiKey) { showFeedback('⚠ API key is required', 'error'); apiKeyInput.focus(); return; }
  const prov = providerOfSelected();
  await chrome.storage.local.set({ [`apiKey_${prov}`]: apiKey, apiKey });
  showFeedback('✓ Saved!');
}

function showFeedback(msg, type = 'success') {
  saveFeedback.textContent = msg;
  saveFeedback.style.color = type === 'error' ? 'var(--red)' : 'var(--accent-2)';
  saveFeedback.style.opacity = '1';
  setTimeout(() => { saveFeedback.style.opacity = '0'; }, 2500);
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 5: UI HELPERS (theme toggle, key prompt, clipboard)
// ═══════════════════════════════════════════════════════════════════════════

const settingsThemeToggle = document.getElementById('settingsThemeToggle');
if (settingsThemeToggle) {
  settingsThemeToggle.addEventListener('click', () => {
    const root = document.documentElement;
    const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    try { localStorage.setItem('viora-theme', next); } catch (_) {}
  });
} else { console.warn('settingsThemeToggle not found'); }

function showKeyPrompt() {
  if (!apiKeyInput.value.trim()) { keyPrompt.style.display = 'flex'; apiKeyInput.focus(); }
}

function hideKeyPrompt() { keyPrompt.style.display = 'none'; }

let keyVisible = false;
if (toggleKeyBtn) toggleKeyBtn.addEventListener('click', () => {
  keyVisible = !keyVisible;
  if (apiKeyInput) apiKeyInput.type = keyVisible ? 'text' : 'password';
  const eye = toggleKeyBtn.querySelector('#eyeIcon');
  if (eye) eye.innerHTML = keyVisible
    ? `<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>`
    : `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>`;
});

// ─── CHAT HISTORY ───────────────────────────────────────────────────────────

function escapeHtml(str) { return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }

function relativeTime(ts) {
  const diff = Date.now() - ts;
  const min = Math.round(diff / 60000);
  if (min < 1) return 'just now';
  if (min < 60) return `${min}m ago`;
  const hr = Math.round(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.round(hr / 24);
  if (day < 7) return `${day}d ago`;
  return new Date(ts).toLocaleDateString();
}

let chatSessions = [];

async function loadChatHistory() {
  try {
    const data = await chrome.storage.local.get(['chatSessions']);
    chatSessions = Array.isArray(data.chatSessions) ? data.chatSessions : [];
  } catch (_) { chatSessions = []; }
  renderHistoryList();
}

function renderHistoryList() {
  historyCountEl.textContent = chatSessions.length ? String(chatSessions.length) : '';
  if (!chatSessions.length) {
    historyListStatus.textContent = 'No past chats yet — conversations you have in the side panel will show up here.';
    historyListStatus.style.display = 'block';
    historyListEl.style.display = 'none';
    clearHistoryBtn.style.display = 'none';
    return;
  }
  historyListStatus.style.display = 'none';
  historyListEl.style.display = 'block';
  clearHistoryBtn.style.display = 'block';

  historyListEl.innerHTML = chatSessions.map(s => `
    <div class="history-item" data-id="${escapeHtml(s.id)}">
      <div class="history-row">
        <div class="history-row-main">
          <div class="history-row-title">${escapeHtml(s.title || 'New chat')}</div>
          <div class="history-row-meta">${relativeTime(s.updatedAt)} · ${s.messageCount || s.messages?.length || 0} message${(s.messageCount||0) === 1 ? '' : 's'}</div>
        </div>
        <div class="history-row-actions">
          <button class="history-expand-btn" title="View transcript" data-id="${escapeHtml(s.id)}">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="transition:transform 0.15s"><polyline points="6 9 12 15 18 9"/></svg>
          </button>
          <button class="history-delete-btn" title="Delete" data-id="${escapeHtml(s.id)}">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
          </button>
        </div>
      </div>
      <div class="history-transcript" id="transcript-${escapeHtml(s.id)}">
        ${(s.messages || []).map(m => `<div class="history-turn"><span class="history-turn-role">${m.role === 'user' ? 'You' : 'Viora'}</span><span class="history-turn-text">${escapeHtml(m.text)}</span></div>`).join('') || '<div class="history-turn"><span class="history-turn-text">No text content saved for this chat.</span></div>'}
      </div>
    </div>
  `).join('');

  historyListEl.querySelectorAll('.history-row').forEach(row => {
    row.addEventListener('click', (e) => {
      if (e.target.closest('.history-delete-btn')) return;
      const id = row.closest('.history-item').dataset.id;
      const transcript = document.getElementById(`transcript-${CSS.escape(id)}`);
      const btn = row.querySelector('.history-expand-btn');
      if (!transcript) return;
      const willOpen = !transcript.classList.contains('open');
      transcript.classList.toggle('open', willOpen);
      btn.classList.toggle('open', willOpen);
    });
  });

  historyListEl.querySelectorAll('.history-delete-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const id = btn.dataset.id;
      chatSessions = chatSessions.filter(s => s.id !== id);
      await chrome.storage.local.set({ chatSessions });
      renderHistoryList();
    });
  });
}

if (clearHistoryBtn) clearHistoryBtn.addEventListener('click', async () => {
  if (!confirm('Delete all saved chat history? This can\'t be undone.')) return;
  chatSessions = [];
  await chrome.storage.local.set({ chatSessions: [] });
  renderHistoryList();
  showFeedback('✓ History cleared');
});

if (chrome.storage.onChanged) chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.chatSessions) try { loadChatHistory(); } catch (_) {}
});

try { loadChatHistory(); } catch (_) {}

// ─── TEST API KEY ──────────────────────────────────────────────────────
const testKeyBtn = document.getElementById('testKeyBtn');
const keyTestResult = document.getElementById('keyTestResult');

function guessProvider(key) {
  if (key.startsWith('gsk_')) return 'groq';
  if (key.startsWith('sk-or-')) return 'openrouter';
  if (key.startsWith('sk-proj-') || key.startsWith('sk-svc-')) return 'openai';
  if (key.startsWith('nvapi-')) return 'nvidia';
  if (key.startsWith('sk-')) return 'openrouter';
  if (key.startsWith('s46_')) return 'mistralai';
  return null;
}

async function testKey() {
  const key = apiKeyInput.value.trim();
  if (!key) { keyTestResult.innerHTML = 'Enter a key first'; return; }
  testKeyBtn.disabled = true;
  testKeyBtn.textContent = 'Testing…';
  keyTestResult.innerHTML = '';
  const guessed = guessProvider(key);
  let report = '';

  const groqModels = [
    { id: 'llama-3.3-70b-versatile', label: 'Llama 3.3 70B' },
    { id: 'llama-3.1-8b-instant', label: 'Llama 3.1 8B' },
    { id: 'meta-llama/llama-4-scout-17b-16e-instruct', label: 'Llama 4 Scout 17B' },
    { id: 'groq/compound', label: 'Groq Compound' },
    { id: 'qwen/qwen3-32b', label: 'Qwen 3 32B' },
    { id: 'qwen/qwen3.6-27b', label: 'Qwen 3.6 27B' },
    { id: 'openai/gpt-oss-120b', label: 'GPT-OSS 120B' },
    { id: 'openai/gpt-oss-20b', label: 'GPT-OSS 20B' },
    { id: 'allam-2-7b', label: 'Allam 2 7B' },
  ];

  const tryProvider = async (provider, endpoint, modelName) => {
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: modelName, messages: [{ role: 'user', content: 'ok' }], max_tokens: 5, temperature: 0 }),
        signal: AbortSignal.timeout(10000),
      });
      if (res.ok) return { ok: true, status: res.status };
      const body = await res.text().catch(() => '');
      return { ok: false, status: res.status, error: body.slice(0, 120) };
    } catch (e) {
      return { ok: false, error: e.message };
    }
  };

  if (guessed === 'groq' || !guessed) {
    let working = []; let failing = [];
    for (const m of groqModels) {
      const r = await tryProvider('groq', 'https://api.groq.com/openai/v1/chat/completions', m.id);
      if (r.ok) working.push(m.label); else failing.push(m.label);
    }
    if (working.length || guessed === 'groq') {
      report += `<div><span class="provider-label">Groq</span></div>`;
      if (working.length) report += `<div>✅ ${working.map(l => `<span class="model-item">${l}</span>`).join('')}</div>`;
      if (failing.length) report += `<div>❌ ${failing.map(l => `<span class="model-item failing">${l}</span>`).join('')}</div>`;
    }
  }

  if (guessed === 'openrouter' || (!guessed && !report.includes('Works'))) {
    const r = await tryProvider('openrouter', 'https://openrouter.ai/api/v1/chat/completions', 'openai/gpt-4o-mini');
    if (r.ok) {
      report += `<div><span class="provider-label">OpenRouter</span> <span class="working">✅ Works</span></div>`;
    } else if (guessed === 'openrouter') {
      report += `<div><span class="provider-label">OpenRouter</span> <span class="failing">❌ Key rejected</span></div>`;
    }
  }

  if (guessed === 'openai' || (!guessed && !report.includes('Works'))) {
    const r = await tryProvider('openai', 'https://api.openai.com/v1/chat/completions', 'gpt-4o-mini');
    if (r.ok) {
      report += `<div><span class="provider-label">OpenAI</span> <span class="working">✅ Works</span></div>`;
    } else if (guessed === 'openai') {
      report += `<div><span class="provider-label">OpenAI</span> <span class="failing">❌ Key rejected</span></div>`;
    }
  }

  if (guessed === 'mistralai' || (!guessed && !report.includes('Works'))) {
    const r = await tryProvider('mistralai', 'https://api.mistral.ai/v1/chat/completions', 'mistral-small-latest');
    if (r.ok) {
      report += `<div><span class="provider-label">Mistral</span> <span class="working">✅ Works</span></div>`;
    } else if (guessed === 'mistralai') {
      report += `<div><span class="provider-label">Mistral</span> <span class="failing">❌ Key rejected</span></div>`;
    }
  }

  if (guessed === 'nvidia' || (!guessed && !report.includes('Works'))) {
    const r = await tryProvider('nvidia', 'https://integrate.api.nvidia.com/v1/chat/completions', 'meta/llama-3.1-8b-instruct');
    if (r.ok) {
      report += `<div><span class="provider-label">NVIDIA</span> <span class="working">✅ Works</span></div>`;
    } else if (guessed === 'nvidia') {
      report += `<div><span class="provider-label">NVIDIA</span> <span class="failing">❌ Key rejected</span></div>`;
    }
  }

  if (!report) report = '<span class="failing">❌ No provider accepted this key</span>';
  keyTestResult.innerHTML = report;
  testKeyBtn.disabled = false;
  testKeyBtn.textContent = '🔍 Test Key';
}

if (testKeyBtn) testKeyBtn.addEventListener('click', testKey);

const safeToggle = (el, fn) => { if (el) el.addEventListener('change', fn); };
safeToggle(autoScreenshot, () => saveSettings(false));
safeToggle(stepScreenshots, () => saveSettings(false));
safeToggle(fastMode, () => saveSettings(false));
safeToggle(autoConfirmSensitive, () => saveSettings(false));
if (saveBtn) saveBtn.addEventListener('click', () => saveSettings(true));
if (apiKeyInput) {
  apiKeyInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') saveSettings(true); });
  apiKeyInput.addEventListener('input', () => { if (apiKeyInput.value.trim()) hideKeyPrompt(); });
}
try { loadSettings(); } catch (_) {}
