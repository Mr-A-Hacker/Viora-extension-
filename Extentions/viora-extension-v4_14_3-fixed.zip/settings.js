const apiKeyInput = document.getElementById('apiKeyInput');
const autoScreenshot = document.getElementById('autoScreenshot');
const stepScreenshots = document.getElementById('stepScreenshots');
const fastMode = document.getElementById('fastMode');
const autoConfirmSensitive = document.getElementById('autoConfirmSensitive');
const saveBtn = document.getElementById('saveBtn');
const saveFeedback = document.getElementById('saveFeedback');
const toggleKeyBtn = document.getElementById('toggleKeyBtn');
const keyPrompt = document.getElementById('keyPrompt');
const modelSearch = document.getElementById('modelSearch');
const modelListEl = document.getElementById('modelList');
const modelListStatus = document.getElementById('modelListStatus');
const modelCountEl = document.getElementById('modelCount');
const apiKeyModelBadge = document.getElementById('apiKeyModelBadge');

const AUTO_MODEL = 'openrouter/auto';
let allModels = []; // full fetched catalog, each: {id, name, provider, context_length, promptPrice, vision}
let selectedModel = AUTO_MODEL;
const MODEL_CACHE_KEY = 'modelCatalogCache';
const MODEL_CACHE_TTL_MS = 24 * 60 * 60 * 1000; // refetch at most once a day — the catalog doesn't change hour to hour

function providerOf(id) {
  return id.includes('/') ? id.split('/')[0] : 'other';
}

function updateApiKeyModelBadge() {
  if (!apiKeyModelBadge) return;
  const label = selectedModel === AUTO_MODEL
    ? 'Auto (recommended)'
    : (allModels.find(m => m.id === selectedModel)?.name || selectedModel);
  apiKeyModelBadge.textContent = `for ${label}`;
  apiKeyModelBadge.title = selectedModel;
  apiKeyModelBadge.style.display = 'inline-block';
}

function providerLabel(p) {
  const known = {
    openai: 'OpenAI', anthropic: 'Anthropic', google: 'Google', 'meta-llama': 'Meta',
    mistralai: 'Mistral', deepseek: 'DeepSeek', 'x-ai': 'xAI', cohere: 'Cohere',
    qwen: 'Qwen', perplexity: 'Perplexity', microsoft: 'Microsoft', nvidia: 'NVIDIA',
    amazon: 'Amazon', ai21: 'AI21',
  };
  return known[p] || (p.charAt(0).toUpperCase() + p.slice(1));
}

async function loadModelCatalog() {
  // Serve from cache instantly if it's fresh, then refresh in the background
  // so the list is never empty/blank on open, but also never goes stale for long.
  try {
    const cached = await chrome.storage.local.get([MODEL_CACHE_KEY]);
    const c = cached[MODEL_CACHE_KEY];
    if (c && c.models && (Date.now() - c.fetchedAt) < MODEL_CACHE_TTL_MS) {
      allModels = c.models;
      renderModelList();
    }
  } catch (_) {}

  try {
    const res = await fetch('https://openrouter.ai/api/v1/models');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    const models = (json.data || [])
      .filter(m => (m.architecture?.input_modalities || []).includes('text')) // keep the list to models Viora can actually use
      .map(m => ({
        id: m.id,
        name: m.name || m.id,
        provider: providerOf(m.id),
        context_length: m.context_length || m.top_provider?.context_length || null,
        promptPrice: m.pricing?.prompt ? parseFloat(m.pricing.prompt) : null,
        vision: (m.architecture?.input_modalities || []).includes('image'),
      }))
      .sort((a, b) => providerLabel(a.provider).localeCompare(providerLabel(b.provider)) || a.name.localeCompare(b.name));
    allModels = models;
    await chrome.storage.local.set({ [MODEL_CACHE_KEY]: { models, fetchedAt: Date.now() } });
    renderModelList();
  } catch (e) {
    if (!allModels.length) {
      modelListStatus.textContent = `Couldn't load the model list (${e.message}). Using Auto for now — try reopening Settings.`;
    }
  }
}

function formatContext(n) {
  if (!n) return '';
  if (n >= 1000) return `${Math.round(n / 1000)}K ctx`;
  return `${n} ctx`;
}

function formatPrice(p) {
  if (p === null || p === undefined) return '';
  const perM = p * 1_000_000;
  if (perM === 0) return 'free';
  return `$${perM < 1 ? perM.toFixed(2) : perM.toFixed(1)}/M`;
}

function renderModelList(filter = '') {
  const q = filter.trim().toLowerCase();
  const filtered = q
    ? allModels.filter(m => m.id.toLowerCase().includes(q) || m.name.toLowerCase().includes(q) || providerLabel(m.provider).toLowerCase().includes(q))
    : allModels;

  modelCountEl.textContent = allModels.length ? `${allModels.length}+ available` : '';
  modelListStatus.style.display = 'none';
  modelListEl.style.display = 'block';
  modelListEl.innerHTML = '';

  // Auto is always pinned at the top, filter or not — it's the sane default.
  if (!q || 'auto'.includes(q) || 'openrouter'.includes(q)) {
    modelListEl.appendChild(buildModelRow({
      id: AUTO_MODEL, name: 'Auto (recommended)', provider: 'openrouter',
      context_length: null, promptPrice: null, vision: true,
    }, true));
  }

  if (!filtered.length && q) {
    const empty = document.createElement('div');
    empty.className = 'model-list-status';
    empty.textContent = `No models matching "${filter}"`;
    modelListEl.appendChild(empty);
    return;
  }

  let lastProvider = null;
  for (const m of filtered) {
    if (m.provider !== lastProvider) {
      const header = document.createElement('div');
      header.className = 'model-group-header';
      header.textContent = providerLabel(m.provider);
      modelListEl.appendChild(header);
      lastProvider = m.provider;
    }
    modelListEl.appendChild(buildModelRow(m, false));
  }
  updateApiKeyModelBadge();
}

function buildModelRow(m, isAuto) {
  const row = document.createElement('div');
  row.className = 'model-row' + (m.id === selectedModel ? ' selected' : '');
  row.dataset.modelId = m.id;

  const main = document.createElement('div');
  main.className = 'model-row-main';
  const name = document.createElement('div');
  name.className = 'model-row-name';
  name.textContent = m.name;
  main.appendChild(name);

  const meta = document.createElement('div');
  meta.className = 'model-row-meta';
  const bits = [];
  if (!isAuto) bits.push(m.id);
  if (m.context_length) bits.push(formatContext(m.context_length));
  const price = formatPrice(m.promptPrice);
  if (price) bits.push(price);
  if (m.vision) bits.push('vision');
  meta.textContent = bits.join(' · ');
  main.appendChild(meta);
  row.appendChild(main);

  const check = document.createElement('div');
  check.className = 'model-row-check';
  check.innerHTML = m.id === selectedModel
    ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>'
    : '';
  row.appendChild(check);

  row.addEventListener('click', () => selectModel(m.id));
  return row;
}

async function selectModel(id) {
  selectedModel = id;
  await chrome.storage.local.set({ model: id });
  document.querySelectorAll('.model-row').forEach(r => {
    const isSel = r.dataset.modelId === id;
    r.classList.toggle('selected', isSel);
    r.querySelector('.model-row-check').innerHTML = isSel
      ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>'
      : '';
  });
  updateApiKeyModelBadge();
  showFeedback('✓ Model updated');
}

modelSearch.addEventListener('input', () => renderModelList(modelSearch.value));

async function loadSettings() {
  const data = await chrome.storage.local.get([
    'apiKey', 'autoScreenshot', 'stepScreenshots', 'fastMode', 'autoConfirmSensitive', 'model'
  ]);
  if (data.apiKey) { apiKeyInput.value = data.apiKey; hideKeyPrompt(); }
  autoScreenshot.checked = data.autoScreenshot !== false;
  stepScreenshots.checked = data.stepScreenshots !== false;
  fastMode.checked = data.fastMode === true;
  autoConfirmSensitive.checked = data.autoConfirmSensitive === true;
  selectedModel = data.model || AUTO_MODEL;
  updateApiKeyModelBadge();
  loadModelCatalog();
}

async function saveSettings(requireKey = true) {
  // BUG FIX: every checkbox (Fast Mode, Auto Confirm Sensitive, etc.) called
  // this same function on 'change', but it bailed out — without saving ANY
  // of the toggle state, and while stealing focus to the API key box — the
  // moment the key field was empty. So toggling a setting before ever
  // entering an API key silently did nothing and was disruptive besides.
  // Toggle changes now always save their own state (requireKey=false,
  // no nag/focus-steal); only the explicit Save button / Enter-in-key-field
  // path still requires and persists a non-empty key.
  await chrome.storage.local.set({
    autoScreenshot: autoScreenshot.checked, stepScreenshots: stepScreenshots.checked,
    fastMode: fastMode.checked, autoConfirmSensitive: autoConfirmSensitive.checked
  });

  if (!requireKey) { showFeedback('✓ Saved!'); return; }

  const apiKey = apiKeyInput.value.trim();
  if (!apiKey) { showFeedback('⚠ API key is required', 'error'); apiKeyInput.focus(); return; }
  await chrome.storage.local.set({ apiKey });
  showFeedback('✓ Saved!');
}

function showFeedback(msg, type = 'success') {
  saveFeedback.textContent = msg;
  saveFeedback.style.color = type === 'error' ? 'var(--red)' : 'var(--accent-2)';
  saveFeedback.style.opacity = '1';
  setTimeout(() => { saveFeedback.style.opacity = '0'; }, 2500);
}

const settingsThemeToggle = document.getElementById('settingsThemeToggle');
if (settingsThemeToggle) {
  settingsThemeToggle.addEventListener('click', () => {
    const root = document.documentElement;
    const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    try { localStorage.setItem('viora-theme', next); } catch (_) {}
  });
}

function showKeyPrompt() {
  if (!apiKeyInput.value.trim()) { keyPrompt.style.display = 'flex'; apiKeyInput.focus(); }
}

function hideKeyPrompt() { keyPrompt.style.display = 'none'; }

let keyVisible = false;
toggleKeyBtn.addEventListener('click', () => {
  keyVisible = !keyVisible;
  apiKeyInput.type = keyVisible ? 'text' : 'password';
  toggleKeyBtn.querySelector('#eyeIcon').innerHTML = keyVisible
    ? `<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>`
    : `<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>`;
});

autoScreenshot.addEventListener('change', () => saveSettings(false));
stepScreenshots.addEventListener('change', () => saveSettings(false));
fastMode.addEventListener('change', () => saveSettings(false));
autoConfirmSensitive.addEventListener('change', () => saveSettings(false));
saveBtn.addEventListener('click', () => saveSettings(true));
apiKeyInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') saveSettings(true); });
apiKeyInput.addEventListener('input', () => { if (apiKeyInput.value.trim()) hideKeyPrompt(); });
loadSettings();
