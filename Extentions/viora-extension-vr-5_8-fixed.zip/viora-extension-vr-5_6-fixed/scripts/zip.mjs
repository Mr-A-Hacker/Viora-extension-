// Packages the extension into dist/viora-extension.zip for Chrome Web Store upload.
// Requires the `zip` CLI to be available (preinstalled on macOS/Linux; on Windows,
// use WSL or Git Bash, or swap this for a Node-native zip library like `archiver`).

import { execSync } from 'node:child_process';
import { mkdirSync, existsSync, rmSync } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve(new URL('.', import.meta.url).pathname, '..');
const distDir = resolve(root, 'dist');
const outFile = resolve(distDir, 'viora-extension.zip');

const FILES = [
  'manifest.json',
  'background.js',
  'content.js',
  'settings.html',
  'settings.js',
  'settings.css',
  'sidepanel.html',
  'sidepanel.js',
  'sidepanel.css',
  'icons',
];

if (!existsSync(distDir)) mkdirSync(distDir, { recursive: true });
if (existsSync(outFile)) rmSync(outFile);

try {
  execSync(`zip -r "${outFile}" ${FILES.join(' ')} -x "*.DS_Store"`, {
    cwd: root,
    stdio: 'inherit',
  });
  console.log(`\n✅ Packaged extension → ${outFile}`);
} catch (err) {
  console.error('\n❌ Zip failed. Make sure the `zip` CLI is installed and on your PATH.');
  console.error('   (macOS/Linux: usually preinstalled. Windows: use WSL or Git Bash.)');
  process.exit(1);
}
