// Viora Side Panel — Main Logic
// Chat, AI integration, task execution

const SYSTEM_PROMPT = `You are Viora, a browser automation AI. You can see the user's screen, click any element, fill forms, navigate pages, and complete multi-step tasks on any website.

Every user message includes [Current page: URL] and optionally [Page text excerpt] so you always know what site they're on.

RESPOND IN ONE OF TWO WAYS:

── CHAT MODE ──
Use when: a screenshot is attached (describe what you see and offer to help), OR the user is asking a general knowledge question unrelated to their browser.
Just reply in plain text.

── ACTION MODE ──
Use when: the user wants you to do ANYTHING on a website — click, fill, search, navigate, extract, automate, finish a task, etc.
Reply ONLY with this JSON (no text before or after, no code fences):

{"type":"action_plan","title":"Task title","emoji":"🖱️","steps":[
  {"type":"screenshot","description":"See the page"},
  {"type":"navigate","url":"https://...","description":"Go to ..."},
  {"type":"click","selector":"CSS_SELECTOR","text":"visible button text","description":"what you're clicking"},
  {"type":"fill","selector":"CSS_SELECTOR","value":"text to type","description":"what you're filling"},
  {"type":"extract","selector":"CSS_SELECTOR","description":"get data"},
  {"type":"scroll","toBottom":true,"description":"scroll down"},
  {"type":"wait_for","selector":"CSS_SELECTOR","description":"wait for element"}
]}

SELECTOR STRATEGY — in order of preference:
1. Use [Current page URL] to know what site you're on and write accurate selectors
2. Use [Page text excerpt] to identify real element text for the "text" fallback
3. For Google: search input is "textarea[name='q']" or "input[name='q']", search button text is "Google Search"
4. For forms: use input[name=], input[type=], textarea, select selectors
5. Always include both selector AND text so there are two ways to find the element
6. NEVER prefix an attribute selector with a tag name — use [id='NextButton'] NOT div[id='NextButton']. The element might be a <button>, not a <div>.
7. For survey Next/Submit buttons, ALWAYS use: selector="#NextButton" text="Next" — this covers Qualtrics, SurveyMonkey, and most platforms
8. When using click_at with coordinates from a screenshot, set x and y to the CENTER of the button as seen in the screenshot image

RULES:
- Plans run automatically — make them correct and complete
- If you need to see the page first, start with a screenshot step
- After seeing a screenshot in conversation, use what you observe for precise selectors
- For homework / forms on screen: screenshot → read content → fill in answers step by step
- Chain as many steps as needed to fully complete the task
- If [Current page] URL is chrome://, chrome-extension://, about:, or devtools://, do NOT produce an action plan with click/fill steps — those pages are browser-internal and cannot be automated. Instead tell the user in CHAT MODE to navigate to a real website first.
- NEVER say you can't see or interact with a regular website.
- For survey navigation: ALWAYS use {"type":"click","selector":"#NextButton","text":"Next","description":"Click Next"} — never use div[id=...] or coordinate-only steps for navigation buttons.

Available step types: navigate, click, click_at, fill, clear, select, check, scroll, extract, extract_links, extract_table, wait_for, hover, press_key, get_page_info, screenshot
click_at takes {x, y} pixel coordinates from the screenshot and clicks whatever element is at that position.`;

// ─── State ────────────────────────────────────────────────────────────────
let apiKey = '';
let model = 'google/gemini-2.0-flash-001';
let conversationHistory = [];
let pendingScreenshot = null;
let activeTask = null;
let stopRequested = false;
let abortController = null;
let autoScreenshot = false;
let stepScreenshots = true;
let targetTabId = null;   // tab pinned via @ picker
let targetTabTitle = '';
let targetTabFavicon = '';

// ─── DOM refs ─────────────────────────────────────────────────────────────
const messagesEl = document.getElementById('messages');
const chatInput = document.getElementById('chatInput');
const sendBtn = document.getElementById('sendBtn');
const stopInputBtn = document.getElementById('stopInputBtn');
const welcomeEl = document.getElementById('welcome');
const typingIndicator = document.getElementById('typingIndicator');
const typingText = document.getElementById('typingText');
const screenshotBar = document.getElementById('screenshotBar');
const screenshotPreview = document.getElementById('screenshotPreview');
const noKeyNotice = document.getElementById('noKeyNotice');
const modeBadge = document.getElementById('modeBadge');
const tabPicker     = document.getElementById('tabPicker');
const tabPickerList = document.getElementById('tabPickerList');
const tabPickerSearch = document.getElementById('tabPickerSearch');
const tabBadge      = document.getElementById('tabBadge');
const tabBadgeFavicon = document.getElementById('tabBadgeFavicon');
const tabBadgeTitle = document.getElementById('tabBadgeTitle');
const tabBadgeClear = document.getElementById('tabBadgeClear');

// ─── Init ──────────────────────────────────────────────────────────────────
async function init() {
  const stored = await chrome.storage.local.get(['apiKey', 'model', 'autoScreenshot', 'stepScreenshots']);
  apiKey = stored.apiKey || '';
  model = stored.model || 'google/gemini-2.0-flash-001';
  autoScreenshot = stored.autoScreenshot === true;
  stepScreenshots = stored.stepScreenshots !== false; // default true

  if (!apiKey) {
    noKeyNotice.style.display = 'block';
  }

  setupEventListeners();
}

// Live-reload settings when saved from the settings page
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.apiKey) {
    apiKey = changes.apiKey.newValue || '';
    noKeyNotice.style.display = apiKey ? 'none' : 'block';
  }
  if (changes.model)           model           = changes.model.newValue           || 'google/gemini-2.0-flash-001';
  if (changes.autoScreenshot)  autoScreenshot  = changes.autoScreenshot.newValue  === true;
  if (changes.stepScreenshots) stepScreenshots = changes.stepScreenshots.newValue !== false;
});

function setupEventListeners() {
  // Send on button click
  sendBtn.addEventListener('click', handleSend);

  // Send on Enter (not Shift+Enter)
  chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  });

  // Auto-resize textarea
  chatInput.addEventListener('input', () => {
    chatInput.style.height = 'auto';
    chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
    sendBtn.disabled = chatInput.value.trim() === '';
  });

  // Quick chips
  document.querySelectorAll('.quick-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      chatInput.value = chip.dataset.prompt;
      chatInput.dispatchEvent(new Event('input'));
      handleSend();
    });
  });

  // Screenshot button (header)
  document.getElementById('screenshotBtn').addEventListener('click', captureAndAttach);

  // Attach screen button (input)
  document.getElementById('attachScreenBtn').addEventListener('click', captureAndAttach);

  // Remove screenshot
  document.getElementById('removeScreenshot').addEventListener('click', () => {
    pendingScreenshot = null;
    screenshotBar.style.display = 'none';
    document.getElementById('attachScreenBtn').classList.remove('active');
  });

  // Clear conversation
  document.getElementById('clearBtn').addEventListener('click', clearConversation);

  // ─── @ Tab Picker ────────────────────────────────────────────────────────
  chatInput.addEventListener('input', handleAtMention);
  chatInput.addEventListener('keydown', (e) => {
    if (tabPicker.style.display !== 'none') {
      const items = tabPickerList.querySelectorAll('.tab-picker-item');
      const sel = tabPickerList.querySelector('.tab-picker-item.selected');
      let idx = [...items].indexOf(sel);
      if (e.key === 'ArrowDown') { e.preventDefault(); selectPickerItem(items, Math.min(idx + 1, items.length - 1)); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); selectPickerItem(items, Math.max(idx - 1, 0)); }
      else if (e.key === 'Enter' && sel) { e.preventDefault(); sel.click(); }
      else if (e.key === 'Escape') { closeTabPicker(); }
    }
  });

  tabPickerSearch.addEventListener('input', () => renderTabPickerItems(tabPickerSearch.value));

  // Stop button (in input area — cancels AI generation or running task)
  stopInputBtn.addEventListener('click', () => {
    if (abortController) { abortController.abort(); abortController = null; }
    stopRequested = true;
    activeTask = null;
    hideTyping();
  });

  // Clear tab target badge
  tabBadgeClear.addEventListener('click', () => {
    targetTabId = null; targetTabTitle = ''; targetTabFavicon = '';
    tabBadge.style.display = 'none';
  });

  // Close picker on outside click
  document.addEventListener('click', (e) => {
    if (!tabPicker.contains(e.target) && e.target !== chatInput) closeTabPicker();
  });
}

// ─── @ Tab Picker Logic ───────────────────────────────────────────────────
let _allTabs = [];

function handleAtMention(e) {
  const val = chatInput.value;
  const cursor = chatInput.selectionStart;
  // Find the last @ before cursor
  const before = val.slice(0, cursor);
  const atIdx = before.lastIndexOf('@');
  if (atIdx !== -1 && !before.slice(atIdx + 1).includes(' ')) {
    const query = before.slice(atIdx + 1);
    openTabPicker(query);
  } else {
    closeTabPicker();
  }
}

function openTabPicker(query) {
  chrome.runtime.sendMessage({ type: 'LIST_TABS' }, (res) => {
    if (!res?.tabs) return;
    _allTabs = res.tabs.filter(t => t.url && !t.url.startsWith('chrome://') && !t.url.startsWith('chrome-extension://'));
    tabPickerSearch.value = query;
    renderTabPickerItems(query);
    tabPicker.style.display = 'flex';
    tabPickerSearch.focus();
  });
}

function renderTabPickerItems(query) {
  const q = (query || '').toLowerCase();
  const filtered = _allTabs.filter(t =>
    !q || t.title?.toLowerCase().includes(q) || t.url?.toLowerCase().includes(q)
  ).slice(0, 10);

  tabPickerList.innerHTML = filtered.length ? '' : '<div style="padding:12px;font-size:12px;color:var(--text-3);text-align:center">No tabs found</div>';

  filtered.forEach((tab, i) => {
    const item = document.createElement('div');
    item.className = 'tab-picker-item' + (i === 0 ? ' selected' : '');
    const domain = (() => { try { return new URL(tab.url).hostname.replace('www.', ''); } catch (_) { return tab.url; } })();
    item.innerHTML = `
      <div class="tab-picker-favicon-wrap">
        ${tab.favIconUrl
          ? `<img src="${tab.favIconUrl}" width="16" height="16" onerror="this.parentElement.innerHTML='<div class=tab-favicon-placeholder></div>'">`
          : '<div class="tab-favicon-placeholder"></div>'}
      </div>
      <div class="tab-picker-item-text">
        <div class="tab-picker-item-title">${escapeHtml(tab.title || 'Untitled')}</div>
        <div class="tab-picker-item-url">${escapeHtml(domain)}</div>
      </div>`;
    item.addEventListener('click', () => pickTab(tab));
    tabPickerList.appendChild(item);
  });
}

function selectPickerItem(items, idx) {
  items.forEach((el, i) => el.classList.toggle('selected', i === idx));
}

function pickTab(tab) {
  targetTabId = tab.id;
  targetTabTitle = tab.title || tab.url;
  targetTabFavicon = tab.favIconUrl || '';

  // Remove the @... text from input
  const val = chatInput.value;
  const cursor = chatInput.selectionStart;
  const before = val.slice(0, cursor);
  const atIdx = before.lastIndexOf('@');
  if (atIdx !== -1) {
    chatInput.value = val.slice(0, atIdx) + val.slice(cursor);
    chatInput.selectionStart = chatInput.selectionEnd = atIdx;
  }

  // Show badge
  tabBadgeTitle.textContent = targetTabTitle.length > 40 ? targetTabTitle.slice(0, 40) + '…' : targetTabTitle;
  tabBadgeFavicon.src = targetTabFavicon;
  tabBadgeFavicon.style.display = targetTabFavicon ? '' : 'none';
  tabBadge.style.display = 'flex';
  closeTabPicker();
  chatInput.focus();
}

function closeTabPicker() {
  tabPicker.style.display = 'none';
}

// ─── Send handler ──────────────────────────────────────────────────────────
async function handleSend() {
  const text = chatInput.value.trim();
  if (!text) return;
  if (!apiKey) {
    noKeyNotice.style.display = 'block';
    return;
  }

  chatInput.value = '';
  chatInput.style.height = 'auto';
  sendBtn.disabled = true;
  hideWelcome();

  // Auto-capture screenshot if setting is on and no screenshot already attached
  if (autoScreenshot && !pendingScreenshot) {
    try {
      const res = await new Promise(resolve =>
        chrome.runtime.sendMessage({ type: 'CAPTURE_SCREENSHOT', tabId: targetTabId }, resolve)
      );
      if (res?.screenshot) {
        pendingScreenshot = res.screenshot;
      }
    } catch (_) {}
  }

  // Add user message
  // Smart auto-screenshot: grab screen for page-related questions if not already attached
  const screenKeywords = /what.*(open|on|see|screen|page|tab)|see.*screen|look at|this page|this tab|help.*with.*this|finish.*this|fill.*this|do this|what is this|what's this/i;
  if (!pendingScreenshot && !autoScreenshot && screenKeywords.test(text)) {
    try {
      const res = await new Promise(resolve =>
        chrome.runtime.sendMessage({ type: 'CAPTURE_SCREENSHOT', tabId: targetTabId }, resolve)
      );
      if (res?.screenshot) pendingScreenshot = res.screenshot;
    } catch (_) {}
  }

  addUserMessage(text, pendingScreenshot);

  // Grab page context (URL + visible text) to help AI pick accurate selectors
  let pageContext = '';
  try {
    const tabInfo = await new Promise(resolve =>
      chrome.runtime.sendMessage({ type: 'GET_TAB_INFO', tabId: targetTabId }, resolve)
    );
    if (tabInfo?.url && !tabInfo.url.startsWith('chrome://')) {
      const pageContent = await new Promise(resolve =>
        chrome.runtime.sendMessage({ type: 'GET_PAGE_CONTENT', tabId: targetTabId }, resolve)
      );
      const pageText = pageContent?.text?.slice(0, 1500) || '';
      pageContext = `\n[Current page: ${tabInfo.url}]${pageText ? '\n[Page text excerpt]: ' + pageText : ''}`;
    }
  } catch (_) {}

  // Prepare conversation message
  let userContent;
  if (pendingScreenshot) {
    userContent = [
      { type: 'image_url', image_url: { url: pendingScreenshot } },
      { type: 'text', text: text + pageContext }
    ];
  } else {
    userContent = pageContext ? text + pageContext : text;
  }
  conversationHistory.push({ role: 'user', content: userContent });

  // Clear screenshot
  const screenshot = pendingScreenshot;
  pendingScreenshot = null;
  screenshotBar.style.display = 'none';
  document.getElementById('attachScreenBtn').classList.remove('active');

  showTyping('Thinking…');

  try {
    const response = await callAI(conversationHistory);
    hideTyping();


    // Extract action plan from anywhere in the response (AI sometimes mixes prose + JSON)
    const { plan, visibleText } = extractActionPlan(response);
    if (plan) {
      conversationHistory.push({ role: 'assistant', content: response });
      if (visibleText) addAssistantMessage(visibleText);
      renderTaskCard(plan);
      setBadge('actions');
      const taskId = document.querySelector('.task-card:last-child')?.id;
      if (taskId) setTimeout(() => startTask(taskId, plan), 120);
      return;
    }

    // Regular text response
    conversationHistory.push({ role: 'assistant', content: response });
    addAssistantMessage(response);
    setBadge('chat');

  } catch (err) {
    hideTyping();
    if (err.name === 'AbortError') return; // User hit stop — no error message needed
    addAssistantMessage(`⚠️ Error: ${err.message}\n\nPlease check your API key in settings.`);
  }
}


// ─── AI API call ───────────────────────────────────────────────────────────
async function callAI(history) {
  abortController = new AbortController();
  const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    signal: abortController.signal,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
      'HTTP-Referer': 'https://viora-extension.local',
      'X-Title': 'Viora Browser Assistant'
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        ...history
      ],
      max_tokens: 2500,
      temperature: 0.6
    })
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `HTTP ${response.status}`);
  }

  const data = await response.json();
  return data.choices?.[0]?.message?.content || '';
}

// ─── Task card rendering ───────────────────────────────────────────────────
function renderTaskCard(plan) {
  const taskId = 'task-' + Date.now();
  const stepsCount = plan.steps?.length || 0;

  const card = document.createElement('div');
  card.className = 'task-card';
  card.id = taskId;
  card.innerHTML = `
    <div class="task-card-header">
      <div class="task-icon">${plan.emoji || '⚡'}</div>
      <div class="task-meta">
        <div class="task-title">${escapeHtml(plan.title || 'Task')}</div>
        <div class="task-subtitle">${stepsCount} step${stepsCount !== 1 ? 's' : ''} planned</div>
      </div>
    </div>
    <div class="task-progress">
      <div class="task-progress-bar" id="${taskId}-progress"></div>
    </div>
    <div class="task-steps" id="${taskId}-steps">
      ${(plan.steps || []).map((step, i) => `
        <div class="task-step" id="${taskId}-step-${i}">
          <div class="step-status pending" id="${taskId}-status-${i}">
            ${stepStatusIcon('pending')}
          </div>
          <div class="step-info">
            <div class="step-desc">${escapeHtml(step.description || step.type)}</div>
            <div class="step-detail">${stepDetailText(step)}</div>
          </div>
        </div>
      `).join('')}
    </div>
    <div class="task-card-footer" id="${taskId}-footer">
      <button class="btn-run" id="${taskId}-runBtn" onclick="startTask('${taskId}', ${JSON.stringify(plan).replace(/'/g, '&#39;')})">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
        Run Task
      </button>
      <button class="btn-discard" onclick="discardTask('${taskId}')">Discard</button>
    </div>
  `;

  messagesEl.appendChild(card);
  scrollToBottom();
}

function stepDetailText(step) {
  if (step.type === 'navigate') return step.url || '';
  if (step.type === 'click') return step.selector || step.text || '';
  if (step.type === 'fill') return `${step.selector || ''} → "${step.value || ''}"`;
  if (step.type === 'extract') return step.selector || 'page content';
  if (step.type === 'wait_for') return step.selector || '';
  if (step.type === 'screenshot') return 'capture viewport';
  if (step.type === 'click_at')  return `coords (${step.x}, ${step.y})`;
  return step.selector || step.url || '';
}

function stepStatusIcon(status) {
  if (status === 'pending') return '○';
  if (status === 'running') return '↻';
  if (status === 'done') return '✓';
  if (status === 'error') return '✕';
  if (status === 'skipped') return '—';
  return '○';
}

// ─── Task execution ────────────────────────────────────────────────────────
async function startTask(taskId, plan) {
  if (activeTask) return;
  activeTask = taskId;
  stopRequested = false;

  const runBtn = document.getElementById(`${taskId}-runBtn`);
  const footer = document.getElementById(`${taskId}-footer`);

  // Replace run/discard with stop button
  footer.innerHTML = `
    <button class="btn-stop" onclick="requestStop()">
      <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><rect x="4" y="4" width="16" height="16"/></svg>
      Stop
    </button>
  `;

  const steps = plan.steps || [];
  let completed = 0;
  let lastError = null;

  for (let i = 0; i < steps.length; i++) {
    if (stopRequested) break;

    const step = steps[i];
    setStepStatus(taskId, i, 'running');
    showTyping(step.description || `Running step ${i + 1}…`);

    try {
      const result = await executeStep(step);
      setStepStatus(taskId, i, 'done');

      // Handle screenshot results — feed image into AI conversation
      if (step.type === 'screenshot' && result?.screenshot) {
        appendScreenshotToStep(taskId, i, result.screenshot);
        // Push screenshot to conversation so AI can SEE the page
        conversationHistory.push({
          role: 'user',
          content: [
            { type: 'image_url', image_url: { url: result.screenshot } },
            { type: 'text', text: `[Step ${i + 1} screenshot — this is what the page looks like now]` }
          ]
        });
      }

      // Auto-capture screenshot after each non-screenshot action when setting is on
      if (step.type !== 'screenshot' && stepScreenshots) {
        try {
          const snap = await new Promise(resolve =>
            chrome.runtime.sendMessage({ type: 'CAPTURE_SCREENSHOT', tabId: targetTabId }, resolve)
          );
          if (snap?.screenshot) {
            appendScreenshotToStep(taskId, i, snap.screenshot);
            // Feed to AI so it can verify the action worked
            conversationHistory.push({
              role: 'user',
              content: [
                { type: 'image_url', image_url: { url: snap.screenshot } },
                { type: 'text', text: `[After step ${i + 1}: "${step.description || step.type}" — page state now]` }
              ]
            });
          }
        } catch (_) {}
      }

      // Handle data extraction results
      if (result?.data) {
        appendDataToStep(taskId, i, result.data);
        // Add to conversation so AI has context
        conversationHistory.push({
          role: 'user',
          content: `[Step ${i + 1} extracted data]: ${result.data.slice(0, 2000)}`
        });
      }

      completed++;
      updateProgress(taskId, (completed / steps.length) * 100);
      await delay(300);

    } catch (err) {
      setStepStatus(taskId, i, 'error');
      appendErrorToStep(taskId, i, err.message);
      lastError = err;

      // Mark remaining steps as skipped
      for (let j = i + 1; j < steps.length; j++) {
        setStepStatus(taskId, j, 'skipped');
      }
      break;
    }
  }

  hideTyping();
  activeTask = null;

  const stopped = stopRequested;
  stopRequested = false;

  // Show completion banner
  const stepsEl = document.getElementById(`${taskId}-steps`);
  const banner = document.createElement('div');

  if (stopped) {
    banner.className = 'task-failed-banner';
    banner.innerHTML = '⏹ Task stopped by user';
  } else if (lastError) {
    banner.className = 'task-failed-banner';
    banner.innerHTML = `⚠️ Task stopped: ${escapeHtml(lastError.message)}`;
    // Let AI know
    await summarizeTaskResult(plan, steps, completed, lastError.message);
  } else {
    banner.className = 'task-complete-banner';
    banner.innerHTML = `✓ Task complete — ${completed} of ${steps.length} steps done`;
    await summarizeTaskResult(plan, steps, completed, null);
  }

  footer.innerHTML = '';
  const card = document.getElementById(taskId);
  card.appendChild(banner);
  setBadge('chat');
  scrollToBottom();
}

async function summarizeTaskResult(plan, steps, completed, error) {
  const summary = error
    ? `Task "${plan.title}" failed at step ${completed + 1}: ${error}`
    : `Task "${plan.title}" completed successfully. All ${completed} steps done.`;

  // Take a fresh screenshot so the AI can see the current page
  let postTaskContext = `[Task result]: ${summary}\n[Original goal]: ${plan.title}\nExamine the screenshot carefully. Is the ORIGINAL GOAL fully complete, or is there more to do (e.g. more survey pages, more questions)? If NOT done, produce an action_plan to continue. If fully done, say so briefly.`;

  try {
    const tabInfo = await new Promise(resolve =>
      chrome.runtime.sendMessage({ type: 'GET_TAB_INFO', tabId: targetTabId }, resolve)
    );
    if (tabInfo?.url && !tabInfo.url.startsWith('chrome://')) {
      postTaskContext += `\n[Now on: ${tabInfo.url}]`;
    }
    const snap = await new Promise(resolve =>
      chrome.runtime.sendMessage({ type: 'CAPTURE_SCREENSHOT', tabId: targetTabId }, resolve)
    );
    if (snap?.screenshot) {
      conversationHistory.push({
        role: 'user',
        content: [
          { type: 'image_url', image_url: { url: snap.screenshot } },
          { type: 'text', text: postTaskContext }
        ]
      });
    } else {
      conversationHistory.push({ role: 'user', content: postTaskContext });
    }
  } catch (_) {
    conversationHistory.push({ role: 'user', content: postTaskContext });
  }

  showTyping("Checking if there's more to do...");
  try {
    const reply = await callAI(conversationHistory);
    hideTyping();
    conversationHistory.push({ role: 'assistant', content: reply });

    // Extract action plan from anywhere in the reply (handles mixed prose + JSON)
    const { plan: nextPlan, visibleText } = extractActionPlan(reply);
    if (nextPlan) {
      if (visibleText) addAssistantMessage(visibleText);
      renderTaskCard(nextPlan);
      setBadge('actions');
      const taskId = document.querySelector('.' + 'task-card:last-child')?.id;
      if (taskId) setTimeout(() => startTask(taskId, nextPlan), 120);
      return;
    }

    addAssistantMessage(reply);
  } catch (err) {
    hideTyping();
    if (err.name !== 'AbortError') console.warn('summarize error', err);
  }
}

function requestStop() {
  stopRequested = true;
}

function discardTask(taskId) {
  const card = document.getElementById(taskId);
  if (card) {
    card.style.opacity = '0';
    card.style.transform = 'scale(0.97)';
    card.style.transition = 'all 0.2s';
    setTimeout(() => card.remove(), 200);
  }
  setBadge('chat');
}

// ─── Step executor ────────────────────────────────────────────────────────
async function executeStep(step) {
  if (step.type === 'screenshot') {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'CAPTURE_SCREENSHOT', tabId: targetTabId }, (res) => {
        if (chrome.runtime.lastError || res?.error) {
          resolve({ success: true, screenshot: null });
        } else {
          resolve({ success: true, screenshot: res.screenshot });
        }
      });
    });
  }

  if (step.type === 'navigate') {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'NAVIGATE', url: step.url, tabId: targetTabId }, (res) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else if (res?.error) reject(new Error(res.error));
        else resolve(res);
      });
    });
  }

  // DOM actions go through background → content script
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: 'DOM_ACTION', action: step, tabId: targetTabId }, (res) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else if (res?.success === false) {
        reject(new Error(res.error || 'Action failed'));
      } else {
        resolve(res || { success: true });
      }
    });
  });
}

// ─── Task UI helpers ───────────────────────────────────────────────────────
function setStepStatus(taskId, index, status) {
  const statusEl = document.getElementById(`${taskId}-status-${index}`);
  if (!statusEl) return;
  statusEl.className = `step-status ${status}`;
  statusEl.textContent = stepStatusIcon(status);
}

function updateProgress(taskId, percent) {
  const bar = document.getElementById(`${taskId}-progress`);
  if (bar) bar.style.width = percent + '%';
}

function appendScreenshotToStep(taskId, index, dataUrl) {
  const stepsEl = document.getElementById(`${taskId}-steps`);
  const img = document.createElement('img');
  img.src = dataUrl;
  img.className = 'step-screenshot';
  stepsEl.appendChild(img);
}

function appendDataToStep(taskId, index, data) {
  const stepsEl = document.getElementById(`${taskId}-steps`);
  const prev = document.createElement('div');
  prev.className = 'data-preview';
  prev.textContent = data.slice(0, 600) + (data.length > 600 ? '…' : '');
  stepsEl.appendChild(prev);
}

function appendErrorToStep(taskId, index, message) {
  const stepEl = document.getElementById(`${taskId}-step-${index}`);
  if (!stepEl) return;
  const errEl = document.createElement('div');
  errEl.className = 'step-error';
  errEl.textContent = message;
  stepEl.querySelector('.step-info').appendChild(errEl);
}

// ─── Screenshot ────────────────────────────────────────────────────────────
async function captureAndAttach() {
  chrome.runtime.sendMessage({ type: 'CAPTURE_SCREENSHOT', tabId: targetTabId }, (res) => {
    if (res?.screenshot) {
      pendingScreenshot = res.screenshot;
      screenshotPreview.src = res.screenshot;
      screenshotBar.style.display = 'flex';
      document.getElementById('attachScreenBtn').classList.add('active');
    }
  });
}

// ─── Message rendering ─────────────────────────────────────────────────────
function addUserMessage(text, screenshot) {
  hideWelcome();
  const div = document.createElement('div');
  div.className = 'message user';
  let html = `<div class="msg-label">You</div><div class="msg-bubble">${escapeHtml(text)}</div>`;
  if (screenshot) {
    html += `<img src="${screenshot}" class="msg-screenshot" style="max-width:200px;margin-top:4px" />`;
  }
  div.innerHTML = html;
  messagesEl.appendChild(div);
  scrollToBottom();
}

function addAssistantMessage(text) {
  // Final safety strip: remove any JSON action_plan blobs that slipped through
  const { visibleText } = extractActionPlan(text);
  const cleaned = (visibleText || text).trim();
  if (!cleaned) return; // nothing to show
  const div = document.createElement('div');
  div.className = 'message assistant';
  div.innerHTML = `<div class="msg-label">Viora</div><div class="msg-bubble">${formatMarkdown(cleaned)}</div>`;
  messagesEl.appendChild(div);
  scrollToBottom();
}

// Basic markdown formatter
function formatMarkdown(text) {
  return text
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/```[\s\S]*?```/g, '')  // strip code blocks — don't show raw code to user
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/^### (.+)$/gm, '<strong>$1</strong>')
    .replace(/^## (.+)$/gm, '<strong>$1</strong>')
    .replace(/^# (.+)$/gm, '<strong>$1</strong>')
    .replace(/^\- (.+)$/gm, '• $1')
    .replace(/\n\n/g, '</p><p>')
    .replace(/\n/g, '<br>');
}

// ─── Extract action plan JSON from anywhere in an AI response ─────────────────
// Returns { plan, visibleText } where visibleText is the prose with JSON stripped.
function extractActionPlan(response) {
  // Fast path: entire response is a JSON action plan
  const trimmed = response.trim();
  if (trimmed.startsWith('{"type":"action_plan"') || trimmed.startsWith('{ "type": "action_plan"')) {
    try {
      const plan = JSON.parse(trimmed);
      if (plan?.type === 'action_plan') return { plan, visibleText: '' };
    } catch (_) {}
  }

  // Slow path: find a JSON object anywhere inside the text
  // Walk through looking for { ... } blocks that parse as action_plan
  let i = 0;
  while (i < response.length) {
    const brace = response.indexOf('{', i);
    if (brace === -1) break;
    // Try to extract a balanced JSON object starting here
    let depth = 0, j = brace;
    while (j < response.length) {
      if (response[j] === '{') depth++;
      else if (response[j] === '}') { depth--; if (depth === 0) break; }
      j++;
    }
    if (depth === 0) {
      const candidate = response.slice(brace, j + 1);
      try {
        const plan = JSON.parse(candidate);
        if (plan?.type === 'action_plan') {
          // Strip the JSON blob from the visible text
          const visibleText = (response.slice(0, brace) + response.slice(j + 1)).trim();
          return { plan, visibleText };
        }
      } catch (_) {}
    }
    i = brace + 1;
  }

  return { plan: null, visibleText: response };
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;')
    .replace(/'/g,'&#39;');
}

// ─── UI helpers ────────────────────────────────────────────────────────────
function hideWelcome() {
  if (welcomeEl) { welcomeEl.style.display = 'none'; }
}

function showTyping(msg = 'Thinking…') {
  typingText.textContent = msg;
  typingIndicator.style.display = 'flex';
  // Swap send → stop while busy
  sendBtn.style.display = 'none';
  stopInputBtn.style.display = 'flex';
  scrollToBottom();
}

function hideTyping() {
  typingIndicator.style.display = 'none';
  // Restore send button
  stopInputBtn.style.display = 'none';
  sendBtn.style.display = '';
  sendBtn.disabled = chatInput.value.trim() === '';
}

function scrollToBottom() {
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function setBadge(mode) {
  modeBadge.textContent = mode === 'actions' ? 'Actions' : 'Chat';
  modeBadge.className = 'mode-badge' + (mode === 'actions' ? ' actions' : '');
}

function clearConversation() {
  conversationHistory = [];
  messagesEl.innerHTML = '';
  // Recreate welcome
  const welcome = document.createElement('div');
  welcome.id = 'welcome';
  welcome.className = 'welcome';
  welcome.innerHTML = `
    <div class="welcome-icon">
      <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
        <circle cx="20" cy="20" r="19" fill="url(#wGrad2)" />
        <polyline points="10,15 20,27 30,15" stroke="white" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
        <circle cx="20" cy="11" r="3" fill="#34d399"/>
        <defs><linearGradient id="wGrad2" x1="0" y1="0" x2="40" y2="40"><stop offset="0%" stop-color="#6366f1"/><stop offset="100%" stop-color="#8b5cf6"/></linearGradient></defs>
      </svg>
    </div>
    <h2>Hi, I'm Viora</h2>
    <p>Chat with me or ask me to automate tasks on any website.</p>`;
  messagesEl.appendChild(welcome);
  setBadge('chat');
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ─── Make startTask/discardTask/requestStop global for inline onclick ──────
window.startTask = startTask;
window.discardTask = discardTask;
window.requestStop = requestStop;

// ─── Boot ─────────────────────────────────────────────────────────────────
init();
