chrome.action.onClicked.addListener(async (tab) => {
  await chrome.sidePanel.open({ tabId: tab.id });
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});

async function resolveTab(preferredTabId) {
  if (preferredTabId) {
    try { const tab = await chrome.tabs.get(preferredTabId); if (tab) return tab; } catch (_) {}
  }
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0] || null;
}

function isRestrictedPage(url) {
  if (!url) return true;
  return url.startsWith('chrome://') || url.startsWith('chrome-extension://') ||
    url.startsWith('about:') || url.startsWith('edge://') ||
    url.startsWith('devtools://') || url === '';
}

async function ensureContentScript(tabId) {
  try { await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }); await delay(250); } catch (_) {}
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.type === 'LIST_TABS') {
    chrome.tabs.query({}, tabs => sendResponse({ tabs: tabs.map(t => ({ id: t.id, title: t.title, url: t.url, favIconUrl: t.favIconUrl })) }));
    return true;
  }

  if (message.type === 'CAPTURE_SCREENSHOT') {
    resolveTab(message.tabId).then(tab => {
      if (!tab) { sendResponse({ error: 'No tab' }); return; }
      chrome.tabs.query({ active: true, currentWindow: true }, activeList => {
        if (message.tabId && activeList[0]?.id !== message.tabId) { sendResponse({ screenshot: null, skipped: true }); return; }
        chrome.tabs.captureVisibleTab(tab.windowId, { format: 'jpeg', quality: 92 }, dataUrl => {
          if (chrome.runtime.lastError) {
            chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' }, png => {
              if (chrome.runtime.lastError) sendResponse({ error: chrome.runtime.lastError.message });
              else sendResponse({ screenshot: png });
            });
          } else sendResponse({ screenshot: dataUrl });
        });
      });
    });
    return true;
  }

  if (message.type === 'NAVIGATE') {
    resolveTab(message.tabId).then(async tab => {
      if (!tab) { sendResponse({ error: 'No tab' }); return; }
      try {
        await chrome.tabs.update(tab.id, { url: message.url });
        const done = await waitForTabLoad(tab.id);
        await ensureContentScript(tab.id);
        sendResponse({ success: true, loaded: done });
      } catch (e) { sendResponse({ error: e.message }); }
    });
    return true;
  }

  if (message.type === 'OPEN_TAB') {
    chrome.tabs.create({ url: message.url, active: true }, tab => {
      waitForTabLoad(tab.id).then(() => sendResponse({ success: true, tabId: tab.id }));
    });
    return true;
  }

  if (message.type === 'GET_TAB_INFO') {
    resolveTab(message.tabId).then(tab => {
      if (tab) sendResponse({ url: tab.url, title: tab.title, tabId: tab.id });
      else sendResponse({ error: 'No tab' });
    });
    return true;
  }

  if (message.type === 'DOM_ACTION') {
    resolveTab(message.tabId).then(async tab => {
      if (!tab) { sendResponse({ error: 'No tab' }); return; }
      const tabId = tab.id, tabUrl = tab.url || '';
      if (isRestrictedPage(tabUrl)) { sendResponse({ success: false, error: `Cannot automate ${tabUrl.split('/')[0]}// pages.` }); return; }
      await ensureContentScript(tabId);
      try {
        const result = await chrome.tabs.sendMessage(tabId, { type: 'DOM_ACTION', action: message.action });
        sendResponse(result);
      } catch (e) {
        await ensureContentScript(tabId);
        try { const result = await chrome.tabs.sendMessage(tabId, { type: 'DOM_ACTION', action: message.action }); sendResponse(result); }
        catch (e2) { sendResponse({ success: false, error: `Cannot reach page: ${e2.message}.` }); }
      }
    });
    return true;
  }

  if (message.type === 'GET_PAGE_CONTENT') {
    resolveTab(message.tabId).then(async tab => {
      if (!tab) { sendResponse({ error: 'No tab' }); return; }
      try { const r = await chrome.tabs.sendMessage(tab.id, { type: 'GET_PAGE_CONTENT' }); sendResponse(r); }
      catch (e) { sendResponse({ error: e.message }); }
    });
    return true;
  }

  if (message.type === 'ANALYZE_PAGE') {
    resolveTab(message.tabId).then(async tab => {
      if (!tab) { sendResponse({ error: 'No tab' }); return; }
      try { const r = await chrome.tabs.sendMessage(tab.id, { type: 'ANALYZE_PAGE' }); sendResponse(r); }
      catch (e) { sendResponse({ error: e.message }); }
    });
    return true;
  }

  if (message.type === 'GET_ENHANCED_CONTENT') {
    resolveTab(message.tabId).then(async tab => {
      if (!tab) { sendResponse({ error: 'No tab' }); return; }
      try { const r = await chrome.tabs.sendMessage(tab.id, { type: 'GET_ENHANCED_CONTENT' }); sendResponse(r); }
      catch (e) { sendResponse({ error: e.message }); }
    });
    return true;
  }

  if (message.type === 'GET_VIEWPORT_STATE') {
    resolveTab(message.tabId).then(async tab => {
      if (!tab) { sendResponse({ error: 'No tab' }); return; }
      try { const r = await chrome.tabs.sendMessage(tab.id, { type: 'GET_VIEWPORT_STATE' }); sendResponse(r); }
      catch (e) { sendResponse({ error: e.message }); }
    });
    return true;
  }

  if (message.type === 'GET_ELEMENT_CONTEXT') {
    resolveTab(message.tabId).then(async tab => {
      if (!tab) { sendResponse({ error: 'No tab' }); return; }
      try { const r = await chrome.tabs.sendMessage(tab.id, { type: 'GET_ELEMENT_CONTEXT', selector: message.selector, text: message.text }); sendResponse(r); }
      catch (e) { sendResponse({ error: e.message }); }
    });
    return true;
  }

  if (message.type === 'SMART_CLICK') {
    resolveTab(message.tabId).then(async tab => {
      if (!tab) { sendResponse({ error: 'No tab' }); return; }
      await ensureContentScript(tab.id);
      try {
        const r = await chrome.tabs.sendMessage(tab.id, { type: 'SMART_CLICK', target: message.target, options: message.options || {} });
        sendResponse(r);
      } catch (e) { sendResponse({ success: false, error: e.message }); }
    });
    return true;
  }

  // V4: Security confirmation relay
  if (message.type === 'SECURITY_CONFIRM') {
    resolveTab(message.tabId).then(async tab => {
      if (!tab) { sendResponse({ error: 'No tab' }); return; }
      try {
        const r = await chrome.tabs.sendMessage(tab.id, { type: 'SECURITY_CONFIRM', allowed: message.allowed, fieldCategory: message.fieldCategory });
        sendResponse(r);
      } catch (e) { sendResponse({ error: e.message }); }
    });
    return true;
  }

  // V4: Undo action
  if (message.type === 'UNDO_ACTION') {
    resolveTab(message.tabId).then(async tab => {
      if (!tab) { sendResponse({ error: 'No tab' }); return; }
      await ensureContentScript(tab.id);
      try {
        const r = await chrome.tabs.sendMessage(tab.id, { type: 'DOM_ACTION', action: { type: 'undo' } });
        sendResponse(r);
      } catch (e) { sendResponse({ success: false, error: e.message }); }
    });
    return true;
  }
});

function waitForTabLoad(tabId, timeout = 12000) {
  return new Promise(resolve => {
    const timer = setTimeout(() => { chrome.tabs.onUpdated.removeListener(listener); resolve(false); }, timeout);
    function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        clearTimeout(timer); chrome.tabs.onUpdated.removeListener(listener);
        setTimeout(() => resolve(true), 1000);
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
