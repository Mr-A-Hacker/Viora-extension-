if (!window.__vioraLoaded) {
  window.__vioraLoaded = true;

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'DOM_ACTION') {
      handleDomAction(message.action)
        .then(sendResponse)
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true;
    }
    if (message.type === 'GET_PAGE_CONTENT') {
      sendResponse(buildPageContent());
      return true;
    }
    if (message.type === 'ANALYZE_PAGE') {
      sendResponse({ success: true, data: deepPageAnalysis(true) });
      return true;
    }
    if (message.type === 'SMART_CLICK') {
      smartClick(message.target, message.options || {})
        .then(sendResponse)
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true;
    }
    if (message.type === 'PING') {
      sendResponse({ alive: true });
      return true;
    }
    if (message.type === 'GET_ENHANCED_CONTENT') {
      sendResponse(buildEnhancedContent());
      return true;
    }
    if (message.type === 'GET_VIEWPORT_STATE') {
      sendResponse({ success: true, state: getViewportState() });
      return true;
    }
    if (message.type === 'GET_ELEMENT_CONTEXT') {
      sendResponse({ success: true, data: getElementContext(message.selector || message.text || '') });
      return true;
    }
    if (message.type === 'SECURITY_CONFIRM') {
      if (window.__vioraSecurityConfirm) {
        window.__vioraSecurityConfirm.resolve(message.allowed);
        window.__vioraSecurityConfirm = null;
      }
      sendResponse({ success: true });
      return true;
    }
  });
}

function buildPageContent() {
  const text = document.body ? document.body.innerText.slice(0, 30000) : '';
  const html = document.body ? document.body.innerHTML.slice(0, 15000) : '';
  return {
    success: true,
    title: document.title,
    url: window.location.href,
    text,
    html,
    interactiveElements: extractAllInteractive()
  };
}

function buildEnhancedContent() {
  const pageType = detectPageType();
  const structure = extractPageStructure();
  const state = getViewportState();
  const modals = detectModals();
  const allInteractive = extractAllInteractive();

  return {
    success: true,
    title: document.title,
    url: window.location.href,
    text: document.body ? document.body.innerText.slice(0, 30000) : '',
    pageType,
    structure,
    state,
    modals,
    interactiveElements: allInteractive,
    forms: extractFormsDetailed(),
    analysis: deepPageAnalysis()
  };
}

function detectPageType() {
  const u = window.location.href.toLowerCase();
  const t = (document.title || '').toLowerCase();
  const b = document.body;
  if (!b) return 'unknown';

  const forms = document.querySelectorAll('form').length;
  const inputs = document.querySelectorAll('input, select, textarea').length;
  const buttons = document.querySelectorAll('button, [role="button"]').length;
  const links = document.querySelectorAll('a[href]').length;
  const headings = document.querySelectorAll('h1, h2, h3').length;
  const tables = document.querySelectorAll('table').length;
  const images = document.querySelectorAll('img').length;
  const fieldsets = document.querySelectorAll('fieldset').length;

  const hasQID = !!document.querySelector('[id*="QID"]');
  const hasMatrix = !!document.querySelector('table.Matrix, table.ChoiceStructure, [class*="matrix"], [id*="matrix"]');
  const hasLikert = !!document.querySelector('[class*="likert"], [id*="likert"]');
  const hasSurveyNext = !!document.getElementById('NextButton') || !!document.querySelector('[value*="Next"], [id*="NextButton"], .NextButton, [class*="next-btn"]');
  const hasPagination = !!document.querySelector('[aria-label*="pagination"], nav[aria-label*="pagination"], .pagination, [class*="pagination"]');
  const hasLoginForm = !!document.querySelector('input[type="password"], [name*="password"], [id*="password"], [autocomplete="current-password"]');
  const hasSearchForm = !!document.querySelector('input[type="search"], [role="search"], form[action*="search"], [name="q"], [name="search"]');
  const hasNav = !!document.querySelector('nav, [role="navigation"], header nav, .nav, .navbar, [class*="nav-"]');
  const hasFooter = !!document.querySelector('footer, [role="contentinfo"]');
  const hasArticle = !!document.querySelector('article, [role="article"]');
  const hasMain = !!document.querySelector('main, [role="main"]');
  const hasCart = !!document.querySelector('[class*="cart"], [id*="cart"], [class*="basket"], [id*="basket"]');
  const hasCheckout = !!document.querySelector('[class*="checkout"], [id*="checkout"], [name*="checkout"]');
  const hasProduct = !!document.querySelector('[class*="product"], [id*="product"], [itemtype*="product"]');
  const hasDataGrid = !!document.querySelector('[role="grid"], [role="treegrid"], .data-grid, [class*="datagrid"]');
  const hasDialog = !!document.querySelector('[role="dialog"], [role="alertdialog"], dialog');

  let primary = 'unknown', secondary = [];

  if (hasSurveyNext || hasQID || hasMatrix || hasLikert || (forms > 0 && inputs > 5 && /survey|questionnaire|feedback|poll/i.test(t + u))) {
    primary = 'survey';
    secondary.push('form-filling');
  }
  if (hasLoginForm) { primary = 'login'; }
  if (hasSearchForm && inputs > 0 && links > 10) { primary = 'search-results'; secondary.push('list'); }
  if (hasProduct && hasCart) { primary = 'ecommerce-product'; secondary.push('ecommerce'); }
  if (hasCart && hasCheckout) { primary = 'checkout'; secondary.push('form-filling'); }
  if (hasArticle || headings > 3) { primary = primary === 'unknown' ? 'article' : primary; secondary.push('reading'); }
  if (hasDataGrid || tables > 1) { secondary.push('tabular-data'); }
  if (hasDialog) { secondary.push('has-dialog'); }
  if (hasNav && links > 20 && inputs === 0) { primary = primary === 'unknown' ? 'navigation' : primary; }
  if (forms === 0 && inputs === 0 && buttons <= 2 && links > 5) { primary = primary === 'unknown' ? 'content-page' : primary; }
  if (fieldsets > 0) { secondary.push('structured-forms'); }
  if (hasPagination) { secondary.push('paginated'); }
  if (hasMain) { secondary.push('has-main-content'); }
  if (hasFooter) { secondary.push('has-footer'); }
  if (/admin|dashboard|manage|control/i.test(t + u)) { primary = 'dashboard'; secondary.push('data-management'); }
  if (/settings|preferences|config/i.test(t + u)) { primary = 'settings'; secondary.push('form-filling'); }
  if (/signup|register|create.account/i.test(t + u)) { primary = 'registration'; secondary.push('form-filling'); }
  if (/profile|account|my./i.test(t + u)) { secondary.push('user-profile'); }
  if (/checkout|payment|billing|order/i.test(t + u)) { primary = 'checkout'; secondary.push('ecommerce'); }

  return {
    primary,
    secondary: [...new Set(secondary)],
    elementCounts: { forms, inputs, buttons, links, headings, tables, images },
    hasPagination,
    hasNav,
    hasModals: hasDialog
  };
}

function extractPageStructure() {
  const structure = { sections: [], nav: null, main: null, footer: null, modals: [] };

  const navEl = document.querySelector('nav, [role="navigation"]');
  if (navEl) {
    const items = [...navEl.querySelectorAll('a, button, [role="button"], [role="link"]')].map(a => ({
      text: (a.textContent || '').trim().slice(0, 40),
      href: a.href || '',
      active: a.classList.contains('active') || a.getAttribute('aria-current') === 'page'
    }));
    structure.nav = { items: items.slice(0, 30) };
  }

  const mainEl = document.querySelector('main, [role="main"], #main, .main, .content, #content');
  if (mainEl) structure.main = { tag: mainEl.tagName, id: mainEl.id || '', class: (mainEl.className && typeof mainEl.className === 'string') ? mainEl.className.slice(0, 60) : '' };

  const footerEl = document.querySelector('footer, [role="contentinfo"]');
  if (footerEl) {
    const links = [...footerEl.querySelectorAll('a[href]')].map(a => ({ text: a.textContent.trim().slice(0, 30), href: a.href }));
    structure.footer = { links: links.slice(0, 10) };
  }

  const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
  const headingParents = new Set();
  headings.forEach(h => {
    let section = h.closest('section, article, div[class*="section"], div[id*="section"], aside, [role="region"]');
    if (!section) section = h.parentElement;
    if (section && !headingParents.has(section)) {
      headingParents.add(section);
      const sectionHeadings = [...section.querySelectorAll('h1, h2, h3, h4, h5, h6')].slice(0, 3).map(hh => ({
        level: hh.tagName, text: hh.textContent.trim().slice(0, 60)
      }));
      const sectionButtons = section.querySelectorAll('button, [role="button"], input[type="submit"], input[type="button"]').length;
      const sectionInputs = section.querySelectorAll('input, select, textarea').length;
      const sectionLinks = section.querySelectorAll('a[href]').length;
      structure.sections.push({
        tag: section.tagName,
        id: section.id || '',
        class: (section.className && typeof section.className === 'string') ? section.className.slice(0, 40) : '',
        headings: sectionHeadings,
        elementCounts: { buttons: sectionButtons, inputs: sectionInputs, links: sectionLinks }
      });
    }
  });

  const dialogs = document.querySelectorAll('[role="dialog"], [role="alertdialog"], dialog, .modal, [class*="modal"], [class*="overlay"], [class*="popup"]');
  dialogs.forEach(d => {
    if (d.offsetParent !== null || window.getComputedStyle(d).display !== 'none') {
      const buttons = [...d.querySelectorAll('button, [role="button"]')].map(b => (b.textContent || b.value || '').trim().slice(0, 30));
      structure.modals.push({
        tag: d.tagName,
        id: d.id || '',
        role: d.getAttribute('role') || '',
        visible: true,
        heading: d.querySelector('h1, h2, h3, h4, h5, h6, [role="heading"]')?.textContent?.trim().slice(0, 60) || '',
        buttons: buttons.slice(0, 10)
      });
    }
  });

  return structure;
}

function getViewportState() {
  return {
    viewport: { width: window.innerWidth, height: window.innerHeight },
    scroll: { x: window.scrollX, y: window.scrollY },
    scrollableHeight: document.body ? document.body.scrollHeight : 0,
    scrollableWidth: document.body ? document.body.scrollWidth : 0,
    atTop: window.scrollY <= 0,
    atBottom: window.scrollY + window.innerHeight >= (document.body ? document.body.scrollHeight : 0),
    percentScrolled: document.body ? Math.round((window.scrollY / Math.max(document.body.scrollHeight - window.innerHeight, 1)) * 100) : 0,
    dpr: window.devicePixelRatio || 1,
    language: document.documentElement.lang || navigator.language || '',
    colorScheme: window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
  };
}

function detectModals() {
  const modals = [];
  const selectors = [
    '[role="dialog"]', '[role="alertdialog"]', 'dialog',
    '[class*="modal"]', '[id*="modal"]',
    '[class*="overlay"]', '[id*="overlay"]',
    '[class*="popup"]', '[id*="popup"]',
    '[class*="lightbox"]', '[id*="lightbox"]',
    '[class*="drawer"]', '[id*="drawer"]'
  ];
  selectors.forEach(sel => {
    try {
      document.querySelectorAll(sel).forEach(el => {
        const cs = window.getComputedStyle(el);
        if (cs.display !== 'none' && cs.visibility !== 'hidden' && el.offsetParent !== null) {
          const heading = el.querySelector('h1, h2, h3, h4, h5, h6, [role="heading"]');
          const buttons = [...el.querySelectorAll('button, [role="button"], a')]
            .filter(b => b.offsetParent !== null)
            .map(b => ({ text: (b.textContent || b.value || '').trim().slice(0, 30), id: b.id || '' }));
          modals.push({
            tag: el.tagName, id: el.id || '',
            role: el.getAttribute('role') || '',
            heading: heading?.textContent?.trim()?.slice(0, 60) || '',
            closeButtons: buttons.filter(b => /close|cancel|dismiss|×|✕|✖|x/i.test(b.text)).slice(0, 5),
            allButtons: buttons.slice(0, 8),
            rect: rectStr(el)
          });
        }
      });
    } catch (_) {}
  });
  return modals;
}

function extractFormsDetailed() {
  const forms = [];
  document.querySelectorAll('form').forEach(f => {
    const fields = [];
    f.querySelectorAll('input, select, textarea, fieldset, button[type="submit"]').forEach(el => {
      if (el.tagName === 'FIELDSET') {
        const legend = el.querySelector('legend');
        const subFields = [...el.querySelectorAll('input, select, textarea')].map(sf => ({
          name: sf.name || sf.id || '',
          type: sf.type || sf.tagName,
          label: findLabelFor(sf),
          placeholder: sf.placeholder || '',
          required: sf.required || sf.hasAttribute('required') || sf.getAttribute('aria-required') === 'true',
          value: (sf.value || '').slice(0, 30),
          ariaLabel: sf.getAttribute('aria-label') || '',
          autocomplete: sf.getAttribute('autocomplete') || '',
          pattern: sf.getAttribute('pattern') || '',
          minLength: sf.getAttribute('minlength') || '',
          maxLength: sf.getAttribute('maxlength') || ''
        }));
        fields.push({
          type: 'fieldset',
          legend: legend?.textContent?.trim()?.slice(0, 60) || '',
          fields: subFields
        });
      } else {
        fields.push({
          name: el.name || el.id || '',
          type: el.type || el.tagName,
          label: findLabelFor(el),
          placeholder: el.placeholder || '',
          required: el.required || el.hasAttribute('required') || el.getAttribute('aria-required') === 'true',
          value: (el.value || '').slice(0, 30),
          ariaLabel: el.getAttribute('aria-label') || '',
          autocomplete: el.getAttribute('autocomplete') || '',
          pattern: el.getAttribute('pattern') || '',
          minLength: el.getAttribute('minlength') || '',
          maxLength: el.getAttribute('maxlength') || ''
        });
      }
    });
    forms.push({
      id: f.id || '',
      name: f.getAttribute('name') || '',
      action: f.action || '',
      method: f.method || 'get',
      fields,
      submitButtons: [...f.querySelectorAll('button[type="submit"], input[type="submit"], input[type="button"], [role="button"]')].map(b => ({
        text: (b.textContent || b.value || '').trim().slice(0, 40),
        id: b.id || ''
      }))
    });
  });
  return forms;
}

function getElementContext(query) {
  let el = null;
  if (typeof query === 'string') {
    el = document.querySelector(query) ||
         document.getElementById(query.replace('#', '')) ||
         document.querySelector(`[name="${query}"]`) ||
         document.querySelector(`[aria-label="${query}"]`);
  }
  if (!el) return { found: false };

  const rect = el.getBoundingClientRect();
  const nearLabels = [];
  const parentLabels = el.closest('label');
  if (parentLabels) nearLabels.push(parentLabels.textContent.trim().slice(0, 60));

  const labelFor = el.id ? document.querySelector(`label[for="${el.id}"]`) : null;
  if (labelFor) nearLabels.push(labelFor.textContent.trim().slice(0, 60));

  let heading = null;
  let hEl = el;
  while (hEl && hEl !== document.body) {
    const h = hEl.querySelector('h1, h2, h3, h4, h5, h6, [role="heading"]');
    if (h) { heading = { level: h.tagName, text: h.textContent.trim().slice(0, 60) }; break; }
    hEl = hEl.parentElement;
  }
  if (!heading) {
    const allH = document.querySelectorAll('h1, h2, h3, h4');
    let bestDist = Infinity;
    allH.forEach(h => {
      const hr = h.getBoundingClientRect();
      const dist = Math.abs(hr.top - rect.top);
      if (dist < bestDist && hr.top < rect.bottom + 100) {
        bestDist = dist;
        heading = { level: h.tagName, text: h.textContent.trim().slice(0, 60) };
      }
    });
  }

  const form = el.closest('form');
  const section = el.closest('section, article, aside, nav, header, footer, main, div[class*="section"], div[id*="section"]');
  const siblings = [...el.parentElement?.children || []].filter(s => s !== el && s.tagName !== 'SCRIPT' && s.tagName !== 'STYLE').slice(0, 5).map(s => ({
    tag: s.tagName,
    text: (s.textContent || '').trim().slice(0, 40)
  }));

  return {
    found: true,
    tag: el.tagName,
    id: el.id || '',
    type: el.type || '',
    text: (el.textContent || el.value || '').trim().slice(0, 80),
    name: el.getAttribute('name') || '',
    rect: rectStr(el),
    visible: el.offsetParent !== null,
    disabled: el.disabled || false,
    required: el.required || el.hasAttribute('required') || false,
    checked: el.checked || false,
    heading,
    labels: nearLabels,
    formId: form?.id || form?.getAttribute('name') || '',
    section: section?.id || section?.className?.slice(0, 30) || '',
    siblings
  };
}

function extractAllInteractive() {
  const selectors = [
    'button', 'a[href]', 'input', 'select', 'textarea',
    '[role="button"]', '[role="link"]', '[role="option"]',
    '[role="checkbox"]', '[role="radio"]', '[role="tab"]',
    '[role="menuitem"]', '[role="combobox"]', '[role="switch"]',
    '[onclick]', '[tabindex]:not([tabindex="-1"])',
    'summary', 'label', '[contenteditable]',
    '[ng-click]', '[v-on\\:click]', '[@click]'
  ];
  const els = new Set();
  selectors.forEach(sel => {
    try { document.querySelectorAll(sel).forEach(el => els.add(el)); } catch (_) {}
  });
  const vw = window.innerWidth, vh = window.innerHeight;
  return [...els].slice(0, 200).map(el => {
    const rect = el.getBoundingClientRect();
    const inViewport = rect.top < vh && rect.bottom > 0 && rect.left < vw && rect.right > 0;
    const form = el.closest('form');
    let nearestHeading = '';
    let hEl = el;
    while (hEl && hEl !== document.body) {
      const h = hEl.querySelector('h1, h2, h3, h4, h5, h6, [role="heading"]');
      if (h) { nearestHeading = h.textContent.trim().slice(0, 40); break; }
      hEl = hEl.parentElement;
    }
    if (!nearestHeading) {
      const allH = document.querySelectorAll('h1, h2, h3, h4');
      let best = Infinity;
      allH.forEach(h => {
        const d = Math.abs(h.getBoundingClientRect().top - rect.top);
        if (d < best && d < 300) { best = d; nearestHeading = h.textContent.trim().slice(0, 40); }
      });
    }
    return {
      tag: el.tagName,
      type: el.type || '',
      text: (el.textContent || el.value || '').trim().slice(0, 80),
      id: el.id || '',
      name: el.getAttribute('name') || '',
      placeholder: el.placeholder || '',
      ariaLabel: el.getAttribute('aria-label') || '',
      role: el.getAttribute('role') || '',
      ariaChecked: el.getAttribute('aria-checked') || '',
      ariaSelected: el.getAttribute('aria-selected') || '',
      ariaExpanded: el.getAttribute('aria-expanded') || '',
      href: el.href || '',
      classes: (el.className && typeof el.className === 'string') ? el.className.slice(0, 60) : '',
      rect: rectStr(el),
      inViewport,
      visible: el.offsetParent !== null,
      disabled: el.disabled || false,
      checked: el.checked || false,
      tabIndex: el.getAttribute('tabindex') || '',
      dataTestid: el.getAttribute('data-testid') || el.getAttribute('data-test') || '',
      onclick: el.hasAttribute('onclick') || el.onclick !== null,
      label: findLabelFor(el).slice(0, 60),
      formId: form?.id || '',
      section: nearestHeading
    };
  });
}

function deepPageAnalysis(includeAll = false) {
  const r = {
    title: document.title,
    url: window.location.href,
    forms: [], buttons: [], inputs: [], links: [], headings: []
  };
  document.querySelectorAll('form').forEach(f => {
    r.forms.push({
      id: f.id || '', action: f.action || '', method: f.method || '',
      inputs: [...f.querySelectorAll('input, select, textarea')].map(i => ({
        name: i.name || i.id || '', type: i.type || i.tagName,
        placeholder: i.placeholder || '', label: findLabelFor(i),
        required: i.required || false, value: (i.value || '').slice(0, 30)
      }))
    });
  });
  document.querySelectorAll('button, [role="button"], input[type="submit"], input[type="button"]').forEach(b => {
    r.buttons.push({
      text: (b.textContent || b.value || b.getAttribute('aria-label') || '').trim().slice(0, 60),
      id: b.id || '', visible: b.offsetParent !== null, disabled: b.disabled || false, rect: rectStr(b)
    });
  });
  document.querySelectorAll('input:not([type="submit"]):not([type="button"]), textarea, select').forEach(i => {
    r.inputs.push({
      name: i.name || i.id || '', type: i.type || i.tagName,
      placeholder: i.placeholder || '', label: findLabelFor(i),
      required: i.required || false, value: (i.value || '').slice(0, 30)
    });
  });
  document.querySelectorAll('a[href]').forEach(a => {
    r.links.push({
      text: a.textContent.trim().slice(0, 60), href: a.href, id: a.id || ''
    });
  });
  document.querySelectorAll('h1, h2, h3, h4').forEach(h => {
    r.headings.push({ level: h.tagName, text: h.textContent.trim().slice(0, 80) });
  });
  r.totalInteractive = r.buttons.length + r.inputs.length + r.links.length;

  if (includeAll) {
    r.pageType = detectPageType();
    r.structure = extractPageStructure();
    r.state = getViewportState();
    r.modals = detectModals();
    r.formsDetailed = extractFormsDetailed();
  }

  return r;
}

function findLabelFor(el) {
  if (el.id) {
    const l = document.querySelector(`label[for="${el.id}"]`);
    if (l) return l.textContent.trim().slice(0, 60);
  }
  let p = el.parentElement;
  while (p) {
    const l = p.querySelector('label');
    if (l && l.contains(el)) return l.textContent.trim().slice(0, 60);
    p = p.parentElement;
  }
  const pl = el.closest('label');
  if (pl) return pl.textContent.trim().slice(0, 60);

  const ariaLabel = el.getAttribute('aria-label');
  if (ariaLabel) return ariaLabel.trim().slice(0, 60);
  const title = el.getAttribute('title');
  if (title) return title.trim().slice(0, 60);
  const placeholder = el.placeholder;
  if (placeholder) return placeholder.trim().slice(0, 60);

  const ariaLabelledby = el.getAttribute('aria-labelledby');
  if (ariaLabelledby) {
    const ref = document.getElementById(ariaLabelledby);
    if (ref) return ref.textContent.trim().slice(0, 60);
  }
  return '';
}

function rectStr(el) {
  const r = el.getBoundingClientRect();
  return `${Math.round(r.left)},${Math.round(r.top)} ${Math.round(r.width)}x${Math.round(r.height)}`;
}

// ─── PURPLE MOUSE CURSOR ──────────────────────────────────────────────────
let vioraCursorActive = false;

function createPurpleCursor() {
  const existing = document.getElementById('viora-cursor');
  if (existing) existing.remove();
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.id = 'viora-cursor';
  svg.setAttribute('width', '28');
  svg.setAttribute('height', '36');
  svg.style.cssText = 'position:fixed;z-index:2147483647;pointer-events:none;left:0;top:0;filter:drop-shadow(0 2px 8px rgba(16,163,127,0.55));transition:left 0.08s linear,top 0.08s linear;';
  svg.innerHTML = `
    <defs>
      <radialGradient id="cursorGlow" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stop-color="#5eead4" stop-opacity="0.4"/>
        <stop offset="100%" stop-color="#10a37f" stop-opacity="0"/>
      </radialGradient>
      <filter id="cursorShadow">
        <feDropShadow dx="0" dy="1" stdDeviation="1.5" flood-color="#10a37f" flood-opacity="0.6"/>
      </filter>
    </defs>
    <circle cx="14" cy="14" r="12" fill="url(#cursorGlow)" opacity="0.6"/>
    <g filter="url(#cursorShadow)">
      <path d="M2,2 L2,28 L7,23 L11,30 L13,29 L9,22 L18,22 Z"
            fill="#10a37f" stroke="#a7f3d0" stroke-width="1" opacity="0.95"/>
      <path d="M3,3 L3,26 L7,21 L12,29 L12,28 L8,21 L17,21 Z"
            fill="#5eead4" stroke="none" opacity="0.7"/>
      <circle cx="5" cy="7" r="1.5" fill="white" opacity="0.8"/>
    </g>`;
  document.body.appendChild(svg);
  return svg;
}

function movePurpleCursor(x, y, smooth = true) {
  let cursor = document.getElementById('viora-cursor');
  if (!cursor) cursor = createPurpleCursor();
  if (smooth) {
    cursor.style.transition = 'left 0.08s linear, top 0.08s linear';
  } else {
    cursor.style.transition = 'none';
  }
  cursor.style.left = (x - 2) + 'px';
  cursor.style.top = (y - 2) + 'px';
  vioraCursorActive = true;
}

function showClickRipple(x, y) {
  const ring = document.createElement('div');
  ring.style.cssText = `
    position:fixed;z-index:2147483646;pointer-events:none;
    left:${x-12}px;top:${y-12}px;width:24px;height:24px;
    border-radius:50%;
    border: 3px solid #10a37f;
    background: rgba(16,163,127,0.15);
    box-shadow: 0 0 20px rgba(16,163,127,0.4);
    animation: vioraClickRipple 0.6s ease-out forwards;
  `;
  const style = document.createElement('style');
  if (!document.getElementById('viora-ripple-style')) {
    style.id = 'viora-ripple-style';
    style.textContent = `@keyframes vioraClickRipple{0%{transform:scale(0.5);opacity:1}100%{transform:scale(2.5);opacity:0}}`;
    document.head.appendChild(style);
  }
  document.body.appendChild(ring);
  setTimeout(() => ring.remove(), 700);
}

function animatePurpleCursorTo(fromX, fromY, toX, toY, onClickCallback) {
  const cursor = createPurpleCursor();
  cursor.style.left = (fromX - 2) + 'px';
  cursor.style.top = (fromY - 2) + 'px';
  cursor.style.transition = 'none';

  const steps = 8 + Math.floor(Math.random() * 5);
  let step = 0;

  function move() {
    if (step > steps) {
      showClickRipple(toX, toY);
      cursor.style.transition = 'opacity 0.3s';
      cursor.style.opacity = '0';
      setTimeout(() => { cursor.remove(); vioraCursorActive = false; }, 400);
      if (onClickCallback) onClickCallback();
      return;
    }
    const t = step / steps;
    const ease = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
    const midX = (fromX + toX) / 2 + (Math.random() - 0.5) * 30;
    const midY = (fromY + toY) / 2 + (Math.random() - 0.5) * 15;
    const x = Math.round((1 - ease) * (1 - ease) * fromX + 2 * (1 - ease) * ease * midX + ease * ease * toX);
    const y = Math.round((1 - ease) * (1 - ease) * fromY + 2 * (1 - ease) * ease * midY + ease * ease * toY);
    cursor.style.transition = 'left 0.04s linear, top 0.04s linear';
    cursor.style.left = (x - 2) + 'px';
    cursor.style.top = (y - 2) + 'px';
    step++;
    setTimeout(move, 30 + Math.floor(Math.random() * 20));
  }
  move();
}

function removePurpleCursor() {
  const cursor = document.getElementById('viora-cursor');
  if (cursor) cursor.remove();
  vioraCursorActive = false;
}

function highlightElement(el) {
  const overlay = document.createElement('div');
  const rect = el.getBoundingClientRect();
  overlay.style.cssText = `
    position: fixed; z-index: 2147483647; pointer-events: none;
    left: ${rect.left + window.scrollX}px; top: ${rect.top + window.scrollY}px;
    width: ${rect.width}px; height: ${rect.height}px;
    border: 3px solid #10a37f; border-radius: 4px;
    background: rgba(16,163,127,0.12);
    box-shadow: 0 0 20px rgba(16,163,127,0.3);
    transition: opacity 0.3s;
    animation: vioraPulse 0.8s ease-in-out 2;
  `;
  const style = document.createElement('style');
  style.textContent = `@keyframes vioraPulse{0%,100%{opacity:1}50%{opacity:0.5}}`;
  document.head.appendChild(style);
  document.body.appendChild(overlay);
  setTimeout(() => {
    overlay.style.opacity = '0';
    setTimeout(() => { overlay.remove(); style.remove(); }, 300);
  }, 1800);
}

// ─── STRATEGY ENGINE ──────────────────────────────────────────────────────

class StrategyEngine {
  constructor() {
    this.strategies = this.buildAllStrategies();
    this.results = [];
  }

  buildAllStrategies() {
    const s = [];

    // FINDING STRATEGIES (40+)
    const finders = [];

    // Direct selector finders
    finders.push({ name: 'querySelector-exact', fn: (a) => this.f_querySelector(a.selector) });
    finders.push({ name: 'querySelector-naked', fn: (a) => this.f_querySelector(a.selector.replace(/^[a-zA-Z]+(\[)/, '$1')) });
    finders.push({ name: 'querySelector-idPrefix', fn: (a) => this.f_querySelector(a.selector.replace(/^[a-zA-Z]*#/, '#')) });
    finders.push({ name: 'querySelector-idExtract', fn: (a) => {
      const m = a.selector.match(/#([\w-]+)/); return m ? document.getElementById(m[1]) : null;
    }});
    finders.push({ name: 'querySelector-attrId', fn: (a) => {
      const m = a.selector.match(/\[id=['"]?([^'"=\]]+)['"]?\]/); return m ? document.getElementById(m[1]) : null;
    }});
    finders.push({ name: 'querySelector-nameAttr', fn: (a) => {
      const m = a.selector.match(/\[name=['"]?([^'"=\]]+)['"]?\]/); return m ? document.querySelector(`[name="${m[1]}"]`) : null;
    }});
    finders.push({ name: 'querySelector-lastChunk', fn: (a) => {
      if (!a.selector) return null;
      const chunk = a.selector.split(/[\[\.#:\s]/).filter(Boolean).pop();
      if (!chunk) return null;
      return document.querySelector(`[class*="${chunk}"]`) || document.getElementById(chunk) || document.querySelector(`[name*="${chunk}"]`);
    }});
    finders.push({ name: 'xpath-find', fn: (a) => {
      try { const r = document.evaluate(a.selector, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null); return r.singleNodeValue; } catch(_) { return null; }
    }});
    finders.push({ name: 'form-by-name', fn: (a) => {
      if (a.name) return document.querySelector(`[name="${a.name}"], [name="${a.name}" i]`);
      return null;
    }});
    finders.push({ name: 'form-by-placeholder-caseInsensitive', fn: (a) => {
      if (a.placeholder) return document.querySelector(`[placeholder*="${a.placeholder}" i]`);
      return null;
    }});
    finders.push({ name: 'form-by-aria-label', fn: (a) => {
      if (a.ariaLabel) return document.querySelector(`[aria-label*="${a.ariaLabel}" i]`);
      return null;
    }});
    finders.push({ name: 'form-by-title', fn: (a) => {
      if (a.title) return document.querySelector(`[title="${a.title}"], [title="${a.title}" i]`);
      return null;
    }});
    finders.push({ name: 'form-by-id', fn: (a) => {
      if (a.id) return document.getElementById(a.id);
      return null;
    }});
    finders.push({ name: 'form-by-dataTestid', fn: (a) => {
      if (a.dataTestid) return document.querySelector(`[data-testid="${a.dataTestid}"], [data-test="${a.dataTestid}"]`);
      return null;
    }});
    finders.push({ name: 'form-by-class', fn: (a) => {
      if (a.class) return document.querySelector(`[class*="${a.class}"]`);
      return null;
    }});

    // Text-based finders
    finders.push({ name: 'text-exactMatch-button', fn: (a) => this.f_textExact(a.text, 'button,[role="button"],input[type="submit"],input[type="button"],a') });
    finders.push({ name: 'text-exactMatch-all', fn: (a) => this.f_textExact(a.text, '*') });
    finders.push({ name: 'text-includes-button', fn: (a) => this.f_textIncludes(a.text, 'button,[role="button"],input[type="submit"],input[type="button"],a') });
    finders.push({ name: 'text-includes-all', fn: (a) => this.f_textIncludes(a.text, '*') });
    finders.push({ name: 'text-fuzzyMatch-button', fn: (a) => this.f_textFuzzy(a.text, 'button,[role="button"],input[type="submit"],input[type="button"],a,label,span[onclick],div[onclick]') });
    finders.push({ name: 'text-leafNode-exact', fn: (a) => this.f_leafText(a.text, 'exact') });
    finders.push({ name: 'text-leafNode-includes', fn: (a) => this.f_leafText(a.text, 'includes') });
    finders.push({ name: 'text-spanMatch', fn: (a) => this.f_textExact(a.text, 'span,p,div,td,th,li') });

    // Position-based (using text coordinates)
    finders.push({ name: 'text-nthVisible', fn: (a) => this.f_nthVisible(a.text, 0) });
    finders.push({ name: 'text-lastVisible', fn: (a) => this.f_nthVisible(a.text, -1) });

    // Framework-specific
    finders.push({ name: 'ng-click', fn: (a) => {
      return document.querySelector(`[ng-click*="${a.text || a.description || ''}" i]`);
    }});
    finders.push({ name: 'vue-click', fn: (a) => {
      return document.querySelector(`[v-on\\:click*="${a.text || a.description || ''}" i], [@click*="${a.text || a.description || ''}" i]`);
    }});

    // Label-based
    finders.push({ name: 'label-for-exact', fn: (a) => {
      if (!a.text) return null;
      const labels = [...document.querySelectorAll('label')];
      for (const l of labels) {
        if (l.textContent.trim().toLowerCase() === a.text.toLowerCase().trim()) {
          const forId = l.getAttribute('for');
          if (forId) return document.getElementById(forId);
          const input = l.querySelector('input, select, textarea');
          if (input) return input;
        }
      }
      return null;
    }});
    finders.push({ name: 'label-for-includes', fn: (a) => {
      if (!a.text) return null;
      const q = a.text.toLowerCase().trim();
      const labels = [...document.querySelectorAll('label')];
      for (const l of labels) {
        if (l.textContent.toLowerCase().includes(q)) {
          const forId = l.getAttribute('for');
          if (forId) return document.getElementById(forId);
          const input = l.querySelector('input, select, textarea');
          if (input) return input;
        }
      }
      return null;
    }});

    // Attribute fallback
    finders.push({ name: 'ariaLabel-exact', fn: (a) => {
      if (!a.text) return null;
      return document.querySelector(`[aria-label="${a.text}" i]`);
    }});
    finders.push({ name: 'ariaLabel-includes', fn: (a) => {
      if (!a.text) return null;
      return document.querySelector(`[aria-label*="${a.text}" i]`);
    }});
    finders.push({ name: 'title-exact', fn: (a) => {
      if (!a.text) return null;
      return document.querySelector(`[title="${a.text}" i]`);
    }});
    finders.push({ name: 'alt-text', fn: (a) => {
      if (!a.text) return null;
      return document.querySelector(`[alt="${a.text}" i], [alt*="${a.text}" i]`);
    }});

    // Hint-based navigation finders
    finders.push({ name: 'hint-nextButton-id', fn: (a) => this.f_hintFind(a, 'id') });
    finders.push({ name: 'hint-nextButton-text', fn: (a) => this.f_hintFind(a, 'text') });
    finders.push({ name: 'hint-nextButton-includes', fn: (a) => this.f_hintFind(a, 'includes') });

    // CLICK EXECUTION STRATEGIES (30+)
    const clickers = [];

    clickers.push({ name: 'click-events-center', fn: async (el) => { await this.c_fireEvents(el, 0, 0); await this.c_native(el); }});
    clickers.push({ name: 'click-events-offsetPos', fn: async (el) => { await this.c_fireEvents(el, 3, 2); await this.c_native(el); }});
    clickers.push({ name: 'click-events-offsetNeg', fn: async (el) => { await this.c_fireEvents(el, -3, -2); await this.c_native(el); }});
    clickers.push({ name: 'click-events-leftEdge', fn: async (el) => { await this.c_fireEvents(el, -Math.round(el.offsetWidth*0.3), 0); await this.c_native(el); }});
    clickers.push({ name: 'click-events-rightEdge', fn: async (el) => { await this.c_fireEvents(el, Math.round(el.offsetWidth*0.3), 0); await this.c_native(el); }});
    clickers.push({ name: 'click-native-only', fn: async (el) => { await this.c_native(el); }});
    clickers.push({ name: 'click-native-withFocus', fn: async (el) => { el.focus(); await delay(50); await this.c_native(el); }});
    clickers.push({ name: 'click-events-touch', fn: async (el) => { await this.c_touchEvents(el); await this.c_native(el); }});
    clickers.push({ name: 'click-events-pointerOnly', fn: async (el) => { await this.c_pointerOnly(el); await this.c_native(el); }});
    clickers.push({ name: 'click-events-mouseOnly', fn: async (el) => { await this.c_mouseOnly(el); await this.c_native(el); }});
    clickers.push({ name: 'click-dispatchOnParent', fn: async (el) => { if (el.parentElement) await this.c_fireEvents(el.parentElement, 0, 0); await this.c_native(el); }});
    clickers.push({ name: 'click-focusThenEnter', fn: async (el) => { el.focus(); await delay(80); el.dispatchEvent(new KeyboardEvent('keydown', {key:'Enter',code:'Enter',keyCode:13,bubbles:true})); await delay(30); el.dispatchEvent(new KeyboardEvent('keyup', {key:'Enter',code:'Enter',keyCode:13,bubbles:true})); await this.c_native(el); }});
    clickers.push({ name: 'click-events-react', fn: async (el) => { await this.c_fireEvents(el, 0, 0); this.c_triggerReact(el); await this.c_native(el); }});
    clickers.push({ name: 'click-events-vue', fn: async (el) => { await this.c_fireEvents(el, 0, 0); el.dispatchEvent(new Event('input',{bubbles:true})); el.dispatchEvent(new Event('change',{bubbles:true})); await this.c_native(el); }});
    clickers.push({ name: 'click-events-angular', fn: async (el) => { await this.c_fireEvents(el, 0, 0); el.dispatchEvent(new Event('input',{bubbles:true})); el.dispatchEvent(new Event('change',{bubbles:true})); await this.c_native(el); }});
    clickers.push({ name: 'click-double', fn: async (el) => { await this.c_fireEvents(el, 0, 0); await delay(20); await this.c_fireEvents(el, 0, 0); await this.c_native(el); }});
    clickers.push({ name: 'click-mousedownOnly', fn: async (el) => { const pt = this.c_getPoint(el); el.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,clientX:pt.x,clientY:pt.y})); await delay(30); el.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,clientX:pt.x,clientY:pt.y})); await this.c_native(el); }});
    clickers.push({ name: 'click-pointerdownOnly', fn: async (el) => { const pt = this.c_getPoint(el); el.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,cancelable:true,clientX:pt.x,clientY:pt.y,pointerId:1,isPrimary:true})); await delay(30); el.dispatchEvent(new PointerEvent('pointerup',{bubbles:true,cancelable:true,clientX:pt.x,clientY:pt.y,pointerId:1,isPrimary:true})); await this.c_native(el); }});
    clickers.push({ name: 'click-with-hoverPause', fn: async (el) => { const pt = this.c_getPoint(el); el.dispatchEvent(new MouseEvent('mouseover',{bubbles:true,clientX:pt.x,clientY:pt.y})); await delay(200); el.dispatchEvent(new MouseEvent('mousemove',{bubbles:true,clientX:pt.x,clientY:pt.y})); await delay(100); await this.c_fireEvents(el, 0, 0); await this.c_native(el); }});

    // TIMING VARIATIONS (15+)
    const timings = [
      { name: 'fast', pre: 50, inter: 20, post: 100 },
      { name: 'normal', pre: 100, inter: 40, post: 200 },
      { name: 'slow', pre: 200, inter: 80, post: 400 },
      { name: 'human', pre: 80, inter: randomBetween(30, 80), post: randomBetween(150, 350) },
      { name: 'random', pre: randomBetween(30, 300), inter: randomBetween(20, 150), post: randomBetween(50, 500) }
    ];

    // ENVIRONMENT ADAPTATIONS (10+)
    const adapts = [
      { name: 'scrollBefore', fn: async (el) => { el.scrollIntoView({behavior:'instant',block:'center'}); await delay(200); }},
      { name: 'scrollSmoothBefore', fn: async (el) => { el.scrollIntoView({behavior:'smooth',block:'center'}); await delay(400); }},
      { name: 'forceRevealBefore', fn: async (el) => { forceRevealElement(el); await delay(200); }},
      { name: 'waitStableBefore', fn: async (el) => { await waitForElementStable(el); }},
      { name: 'highlightAndClick', fn: async (el) => { highlightElement(el); await delay(300); }},
      { name: 'noPrep', fn: async (el) => {}}
    ];

    // BUILD ALL COMBINATIONS
    let id = 0;
    for (const finder of finders) {
      for (const clicker of clickers.slice(0, 10)) {
        for (const timing of timings.slice(0, 3)) {
          for (const adapt of adapts.slice(0, 3)) {
            id++;
            s.push({
              id, name: `${finder.name}+${clicker.name}+${timing.name}+${adapt.name}`,
              finder, clicker, timing, adapt,
              priority: this.calcPriority(finder.name, clicker.name)
            });
            if (id >= 130) break;
          }
          if (id >= 130) break;
        }
        if (id >= 130) break;
      }
      if (id >= 130) break;
    }

    s.sort((a, b) => b.priority - a.priority);
    return s;
  }

  calcPriority(finderName, clickerName) {
    let p = 50;
    if (finderName.includes('querySelector-exact')) p += 40;
    if (finderName.includes('text-exactMatch-button')) p += 35;
    if (finderName.includes('hint-nextButton')) p += 30;
    if (finderName.includes('label-for')) p += 25;
    if (finderName.includes('text-includes')) p += 20;
    if (finderName.includes('xpath')) p += 15;
    if (finderName.includes('text-leafNode')) p += 10;
    if (clickerName.includes('center')) p += 10;
    if (clickerName.includes('native')) p += 5;
    if (clickerName.includes('react')) p += 8;
    return p;
  }

  // FINDER IMPLEMENTATIONS
  f_querySelector(sel) {
    try { return document.querySelector(sel); } catch(_) { return null; }
  }

  f_textExact(text, selector) {
    if (!text) return null;
    const q = text.toLowerCase().trim();
    const els = document.querySelectorAll(selector);
    for (const el of els) {
      const t = (el.textContent || el.value || el.getAttribute('aria-label') || '').toLowerCase().trim();
      if (t === q) return el;
    }
    return null;
  }

  f_textIncludes(text, selector) {
    if (!text) return null;
    const q = text.toLowerCase().trim();
    const els = document.querySelectorAll(selector);
    for (const el of els) {
      const t = (el.textContent || el.value || el.getAttribute('aria-label') || '').toLowerCase().trim();
      if (t.includes(q)) return el;
    }
    return null;
  }

  f_textFuzzy(text, selector) {
    if (!text) return null;
    const q = text.toLowerCase().trim();
    const els = document.querySelectorAll(selector);
    for (const el of els) {
      const t = (el.textContent || el.value || el.getAttribute('aria-label') || '').toLowerCase().trim();
      if (t.includes(q) || q.includes(t)) return el;
    }
    return null;
  }

  f_leafText(text, mode) {
    if (!text) return null;
    const q = text.toLowerCase().trim();
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    while (walker.nextNode()) {
      const t = walker.currentNode.textContent.trim().toLowerCase();
      const match = mode === 'exact' ? t === q : t.includes(q);
      if (match && walker.currentNode.parentElement) {
        let el = walker.currentNode.parentElement;
        while (el && el.children.length === 1 && el.parentElement && el.parentElement !== document.body) {
          el = el.parentElement;
        }
        return el;
      }
    }
    return null;
  }

  f_nthVisible(text, n) {
    if (!text) return null;
    const q = text.toLowerCase().trim();
    const visible = [...document.querySelectorAll('button, a, [role="button"], input[type="submit"], input[type="button"]')]
      .filter(el => el.offsetParent !== null)
      .filter(el => (el.textContent || el.value || '').toLowerCase().trim().includes(q));
    return n === -1 ? visible[visible.length - 1] : visible[0] || null;
  }

  f_hintFind(action, mode) {
    const hint = ((action.description||'')+' '+(action.selector||'')+' '+(action.text||'')).toLowerCase();
    if (!/next|submit|continue|proceed|forward|done|finish|ok\b|save|confirm|agree|accept/.test(hint)) return null;

    if (mode === 'id') {
      const ids = ['NextButton','next-button','nextButton','submitButton','submit-button','continueButton','btnNext','btn-next','nextBtn','submitBtn','nextPage','SaveButton','confirmButton','agreeButton','doneButton','finishButton','proceedButton','btnSubmit','btn-submit','btn-primary','primaryBtn','loginButton','signInButton','registerButton'];
      for (const id of ids) { const el = document.getElementById(id); if (el) return el; }
      return null;
    }
    const clickables = document.querySelectorAll('button, input[type="submit"], input[type="button"], [role="button"], a');
    if (mode === 'text') {
      const kw = /^(next|continue|proceed|submit|done|finish|ok|save|confirm|agree|accept|send|login|sign\s*in|sign\s*up|register)$/i;
      for (const el of clickables) {
        const label = (el.textContent||el.value||el.getAttribute('aria-label')||el.getAttribute('title')||'').trim();
        if (kw.test(label)) return el;
      }
      return null;
    }
    // includes mode
    const keywords = ['next','submit','continue','proceed','save','confirm','agree','accept','done','finish','send','login','sign in','sign up','register'];
    for (const el of clickables) {
      const label = (el.textContent||el.value||'').toLowerCase();
      for (const kw of keywords) { if (label.includes(kw)) return el; }
    }
    return null;
  }

  // CLICKER IMPLEMENTATIONS
  c_getPoint(el) {
    const rect = el.getBoundingClientRect();
    return {
      x: Math.round(rect.left + rect.width / 2 + (Math.random() - 0.5) * 6),
      y: Math.round(rect.top + rect.height / 2 + (Math.random() - 0.5) * 4)
    };
  }

  async c_fireEvents(el, ox, oy) {
    const rect = el.getBoundingClientRect();
    const cx = Math.round(rect.left + rect.width / 2 + ox);
    const cy = Math.round(rect.top + rect.height / 2 + oy);
    movePurpleCursor(cx, cy, false);
    showClickRipple(cx, cy);
    const p = { bubbles: true, cancelable: true, clientX: cx, clientY: cy, pointerId: 1, isPrimary: true };
    const m = { bubbles: true, cancelable: true, clientX: cx, clientY: cy };
    el.dispatchEvent(new PointerEvent('pointerover', p));
    el.dispatchEvent(new MouseEvent('mouseover', m));
    el.dispatchEvent(new PointerEvent('pointermove', p));
    el.dispatchEvent(new MouseEvent('mousemove', m));
    el.dispatchEvent(new PointerEvent('pointerdown', { ...p, pointerType: 'mouse', button: 0, buttons: 1 }));
    el.dispatchEvent(new MouseEvent('mousedown', { ...m, button: 0 }));
    el.focus();
    await delay(20);
    el.dispatchEvent(new PointerEvent('pointerup', { ...p, pointerType: 'mouse', button: 0, buttons: 0 }));
    el.dispatchEvent(new MouseEvent('mouseup', { ...m, button: 0 }));
    el.dispatchEvent(new MouseEvent('click', m));
    removePurpleCursor();
  }

  async c_native(el) {
    try { el.click(); } catch(_) {}
  }

  async c_touchEvents(el) {
    const pt = this.c_getPoint(el);
    movePurpleCursor(pt.x, pt.y, false);
    showClickRipple(pt.x, pt.y);
    el.dispatchEvent(new TouchEvent('touchstart', { bubbles: true, cancelable: true, changedTouches: [{clientX: pt.x, clientY: pt.y}] }));
    await delay(50);
    el.dispatchEvent(new TouchEvent('touchend', { bubbles: true, cancelable: true, changedTouches: [{clientX: pt.x, clientY: pt.y}] }));
    removePurpleCursor();
  }

  async c_pointerOnly(el) {
    const pt = this.c_getPoint(el);
    movePurpleCursor(pt.x, pt.y, false);
    showClickRipple(pt.x, pt.y);
    el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, clientX: pt.x, clientY: pt.y, pointerId: 1, isPrimary: true }));
    await delay(30);
    el.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, clientX: pt.x, clientY: pt.y, pointerId: 1, isPrimary: true }));
    removePurpleCursor();
  }

  async c_mouseOnly(el) {
    const pt = this.c_getPoint(el);
    movePurpleCursor(pt.x, pt.y, false);
    showClickRipple(pt.x, pt.y);
    el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, clientX: pt.x, clientY: pt.y }));
    el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, clientX: pt.x, clientY: pt.y }));
    el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, clientX: pt.x, clientY: pt.y }));
    removePurpleCursor();
  }

  c_triggerReact(el) {
    const fiberKey = Object.keys(el).find(k => k.startsWith('__reactFiber') || k.startsWith('__reactInternalInstance'));
    if (fiberKey) {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
      if (setter && el.value !== undefined) setter.call(el, el.value);
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }

  async smartClick(action) {
    const target = action;

    for (const strategy of this.strategies) {
      try {
        const startTime = performance.now();
        const el = strategy.finder.fn(target);
        if (!el) continue;

        const foundBy = strategy.finder.name;
        const rect = el.getBoundingClientRect();
        const isVisible = el.offsetParent !== null;

        if (!isVisible) {
          forceRevealElement(el);
          await delay(100);
        }

        await strategy.adapt.fn(el, target);
        await delay(strategy.timing.pre);

        await strategy.clicker.fn(el);

        await delay(strategy.timing.post);

        const elapsed = Math.round(performance.now() - startTime);
        this.results.push({ strategyId: strategy.id, name: strategy.name, foundBy, elapsed, success: true });

        return {
          success: true,
          strategy: strategy.name,
          strategyId: strategy.id,
          foundBy,
          elapsed,
          element: {
            tag: el.tagName,
            id: el.id,
            text: (el.textContent || '').trim().slice(0, 60),
            rect: rectStr(el)
          },
          attempted: this.results.length
        };
      } catch (_) {
        this.results.push({ strategyId: strategy.id, name: strategy.name, success: false });
        continue;
      }
    }

    return {
      success: false,
      error: `All ${this.results.length} strategies failed`,
      attempted: this.results.length
    };
  }

  getResults() { return this.results; }
  reset() { this.results = []; }
}

const strategyEngine = new StrategyEngine();

// ─── HUMAN-LIKE ACTIONS ───────────────────────────────────────────────────

function humanDelay(base = 100) {
  return new Promise(resolve => setTimeout(resolve, Math.round(base * (0.5 + Math.random() * 1.0))));
}

function randomBetween(min, max) {
  return min + Math.random() * (max - min);
}

async function humanType(target, value) {
  target.focus();

  if (isContentEditable(target)) {
    // contenteditable / rich-text editors don't have a `.value` to set —
    // execCommand('insertText') fires the same native input events frameworks
    // like Slate, ProseMirror, and Draft.js listen for.
    document.execCommand('selectAll', false, null);
    document.execCommand('delete', false, null);
    await humanDelay(60);
    for (let i = 0; i < value.length; i++) {
      const char = value[i];
      const isUpper = char === char.toUpperCase() && char !== char.toLowerCase();
      const delayMs = isUpper ? randomBetween(60, 150) : randomBetween(25, 80);
      target.dispatchEvent(new KeyboardEvent('keydown', { key: char, bubbles: true }));
      const inserted = document.execCommand('insertText', false, char);
      if (!inserted) {
        // Fallback for browsers/contexts where execCommand is unavailable
        const sel = window.getSelection();
        if (sel && sel.rangeCount) {
          const range = sel.getRangeAt(0);
          range.deleteContents();
          range.insertNode(document.createTextNode(char));
          range.collapse(false);
        } else {
          target.textContent += char;
        }
        target.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: char }));
      }
      target.dispatchEvent(new KeyboardEvent('keyup', { key: char, bubbles: true }));
      await humanDelay(delayMs);
      if (i === Math.floor(value.length * 0.7) && Math.random() < 0.12) await humanDelay(350);
    }
    target.dispatchEvent(new Event('change', { bubbles: true }));
    await humanDelay(50);
    target.dispatchEvent(new Event('blur', { bubbles: true }));
    return;
  }

  const nativeSetter = getNativeSetter(target);
  nativeSetter.call(target, '');
  target.dispatchEvent(new Event('input', { bubbles: true }));
  target.dispatchEvent(new Event('change', { bubbles: true }));
  await humanDelay(80);

  for (let i = 0; i < value.length; i++) {
    const char = value[i];
    const isUpper = char === char.toUpperCase() && char !== char.toLowerCase();
    const delayMs = isUpper ? randomBetween(60, 150) : randomBetween(25, 80);
    nativeSetter.call(target, target.value + char);
    target.dispatchEvent(new Event('input', { bubbles: true }));
    target.dispatchEvent(new KeyboardEvent('keydown', { key: char, bubbles: true }));
    target.dispatchEvent(new KeyboardEvent('keypress', { key: char, bubbles: true }));
    target.dispatchEvent(new KeyboardEvent('keyup', { key: char, bubbles: true }));
    await humanDelay(delayMs);
    if (i === Math.floor(value.length * 0.7) && Math.random() < 0.12) await humanDelay(350);
  }
  target.dispatchEvent(new Event('change', { bubbles: true }));
  await humanDelay(50);
  target.dispatchEvent(new Event('blur', { bubbles: true }));
}

async function humanClick(el, fromX, fromY) {
  const rect = el.getBoundingClientRect();
  const ox = (Math.random() - 0.5) * Math.min(rect.width * 0.3, 8);
  const oy = (Math.random() - 0.5) * Math.min(rect.height * 0.3, 6);
  const cx = Math.round(rect.left + rect.width / 2 + ox);
  const cy = Math.round(rect.top + rect.height / 2 + oy);
  const p = { bubbles: true, cancelable: true, clientX: cx, clientY: cy, pointerId: 1, isPrimary: true, pointerType: 'mouse' };
  const m = { bubbles: true, cancelable: true, clientX: cx, clientY: cy };

  if (fromX !== undefined && fromY !== undefined) {
    await new Promise(resolve => animatePurpleCursorTo(fromX, fromY, cx, cy, resolve));
    await delay(30);
  } else {
    movePurpleCursor(cx, cy, false);
    showClickRipple(cx, cy);
    await delay(80);
  }

  el.dispatchEvent(new PointerEvent('pointerover', p)); await humanDelay(50);
  el.dispatchEvent(new MouseEvent('mouseover', m)); await humanDelay(100);
  el.dispatchEvent(new PointerEvent('pointermove', p)); el.dispatchEvent(new MouseEvent('mousemove', m)); await humanDelay(60);
  el.dispatchEvent(new PointerEvent('pointerdown', { ...p, button: 0, buttons: 1 }));
  el.dispatchEvent(new MouseEvent('mousedown', { ...m, button: 0 }));
  el.focus();
  await humanDelay(randomBetween(30, 100));
  el.dispatchEvent(new PointerEvent('pointerup', { ...p, button: 0, buttons: 0 }));
  el.dispatchEvent(new MouseEvent('mouseup', { ...m, button: 0 }));
  await delay(15);
  el.dispatchEvent(new MouseEvent('click', m));
  await delay(30);
  try { el.click(); } catch(_) {}
  removePurpleCursor();
}

function getNativeSetter(el) {
  const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
  return Object.getOwnPropertyDescriptor(proto, 'value')?.set || function(v) { this.value = v; };
}

async function forceRevealElement(el) {
  let current = el;
  while (current && current !== document.body && current !== document.documentElement) {
    const cs = window.getComputedStyle(current);
    if (cs.display === 'none') current.style.setProperty('display', 'block', 'important');
    if (cs.visibility === 'hidden') current.style.setProperty('visibility', 'visible', 'important');
    if (cs.opacity === '0') current.style.setProperty('opacity', '1', 'important');
    if (cs.pointerEvents === 'none') current.style.setProperty('pointer-events', 'auto', 'important');
    current = current.parentElement;
  }
}

async function waitForElementStable(el, timeout = 4000) {
  const start = Date.now();
  let prev = el.getBoundingClientRect();
  while (Date.now() - start < timeout) {
    await delay(100);
    const cur = el.getBoundingClientRect();
    if (prev.x === cur.x && prev.y === cur.y && prev.width === cur.width && prev.height === cur.height) return true;
    prev = cur;
  }
  return false;
}

function smoothScrollTo(targetY) {
  const startY = window.scrollY;
  const dist = targetY - startY;
  const dur = Math.min(Math.abs(dist) * 0.5, 600);
  const start = performance.now();
  function step(now) {
    const t = Math.min((now - start) / dur, 1);
    window.scrollTo(0, startY + dist * (1 - Math.pow(1 - t, 3)));
    if (t < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

// ─── V4 EFFICIENCY SYSTEMS ────────────────────────────────────────────────

// ─── SENSITIVE FIELD DETECTOR ──────────────────────────────────────────
const SENSITIVE_PATTERNS = {
  password: [/password/i, /passwd/i, /pwd/i, /^pw$/i],
  payment: [/credit.?card/i, /card.?number/i, /cc.?num/i, /cvv/i, /cvc/i, /card.?cvc/i, /card.?cvv/i, /expir/i, /card.?holder/i],
  personal: [/ssn/i, /social.?security/i, /d.?o.?b/i, /birth/i, /dob/i, /passport/i, /driver.?s.?license/i, /national.?id/i],
  banking: [/account.?num/i, /routing.?num/i, /bank.?account/i, /iban/i, /swift/i],
  pin: [/pin/i, /atm.?pin/i, /security.?code/i]
};

function detectSensitiveField(el) {
  if (!el) return null;
  const elStr = (el.id||'') + ' ' + (el.name||'') + ' ' + (el.placeholder||'') + ' ' +
    (el.getAttribute('aria-label')||'') + ' ' + (el.getAttribute('autocomplete')||'') + ' ' +
    (el.type||'') + ' ' + (el.className||'');
  
  for (const [category, patterns] of Object.entries(SENSITIVE_PATTERNS)) {
    for (const p of patterns) {
      if (p.test(elStr)) return category;
    }
  }
  if (el.type === 'password') return 'password';
  return null;
}

let pendingSecurityConfirm = null;

function requestSecurityConfirm(fieldCategory, step) {
  return new Promise((resolve) => {
    pendingSecurityConfirm = { fieldCategory, step, resolve };
    // Sidepanel will pick this up via polling or message
    window.__vioraSecurityConfirm = pendingSecurityConfirm;
  });
}

// ─── UNDO MANAGER ──────────────────────────────────────────────────────
class UndoManager {
  constructor() {
    this.history = [];
    this.maxHistory = 50;
  }

  async saveSnapshot(action) {
    const snapshot = {
      timestamp: Date.now(),
      action: { ...action },
      elements: []
    };

    // Save DOM state for elements affected by this action
    if (action.selector) {
      const el = document.querySelector(action.selector);
      if (el) {
        snapshot.elements.push({
          selector: action.selector,
          tag: el.tagName,
          value: el.value !== undefined ? el.value : null,
          checked: el.checked !== undefined ? el.checked : null,
          innerHTML: el.innerHTML?.slice(0, 500) || null,
          scrollY: window.scrollY,
          scrollX: window.scrollX
        });
      }
    }

    // Save page-level state
    snapshot.pageState = {
      url: window.location.href,
      scrollY: window.scrollY,
      title: document.title
    };

    this.history.push(snapshot);
    if (this.history.length > this.maxHistory) this.history.shift();
    return snapshot;
  }

  async undo(action) {
    const lastSnapshot = this.history.pop();
    if (!lastSnapshot) return { success: false, error: 'Nothing to undo' };

    const results = [];
    for (const elState of lastSnapshot.elements) {
      try {
        const el = document.querySelector(elState.selector);
        if (!el) continue;
        
        if (elState.value !== null && el.value !== undefined) {
          const ns = Object.getOwnPropertyDescriptor(
            el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype,
            'value'
          )?.set;
          if (ns) {
            ns.call(el, elState.value);
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
          }
        }
        if (elState.checked !== null && el.checked !== undefined) {
          el.checked = elState.checked;
          el.dispatchEvent(new Event('change', { bubbles: true }));
        }
        if (elState.innerHTML !== null) {
          el.innerHTML = elState.innerHTML;
        }
        results.push({ success: true, element: elState.selector });
      } catch (e) {
        results.push({ success: false, error: e.message });
      }
    }

    // Restore scroll position
    if (lastSnapshot.pageState) {
      window.scrollTo(lastSnapshot.pageState.scrollX || 0, lastSnapshot.pageState.scrollY || 0);
    }

    return {
      success: true,
      action: lastSnapshot.action,
      results,
      message: `Undid: ${lastSnapshot.action.description || lastSnapshot.action.type || 'last action'}`
    };
  }

  canUndo() { return this.history.length > 0; }
  clear() { this.history = []; }
}

const undoManager = new UndoManager();

// ─── ADAPTIVE PATIENCE ─────────────────────────────────────────────────
class AdaptivePatience {
  constructor() {
    this.pageStats = { avgLoadTime: 2000, samples: 0 };
    this.elementPatterns = new Map(); // selector -> { avgWait, lastVisible }
  }

  recordPageLoad(ms) {
    const s = this.pageStats;
    s.avgLoadTime = (s.avgLoadTime * s.samples + ms) / (s.samples + 1);
    s.samples++;
  }

  recordElementWait(selector, ms) {
    const p = this.elementPatterns.get(selector) || { avgWait: 500, samples: 0 };
    p.avgWait = (p.avgWait * p.samples + ms) / (p.samples + 1);
    p.samples++;
    p.lastVisible = Date.now();
    this.elementPatterns.set(selector, p);
  }

  async waitForElement(selector, timeout = 8000) {
    const start = Date.now();
    const pattern = this.elementPatterns.get(selector);
    const adaptiveTimeout = pattern ? Math.max(pattern.avgWait * 3, timeout) : timeout;
    
    return new Promise(resolve => {
      const check = () => {
        try {
          const el = document.querySelector(selector);
          if (el && el.offsetParent !== null) {
            const elapsed = Date.now() - start;
            this.recordElementWait(selector, elapsed);
            return resolve(el);
          }
        } catch(_) {}
        if (Date.now() - start >= adaptiveTimeout) return resolve(null);
        requestAnimationFrame(check);
      };
      check();
    });
  }

  async waitForStable(el, minStableTime = 150) {
    const start = Date.now();
    let lastRect = el.getBoundingClientRect();
    let stableDuration = 0;
    
    while (Date.now() - start < 4000) {
      await new Promise(r => requestAnimationFrame(r));
      const curRect = el.getBoundingClientRect();
      if (curRect.x === lastRect.x && curRect.y === lastRect.y &&
          curRect.width === lastRect.width && curRect.height === lastRect.height) {
        stableDuration += 16;
        if (stableDuration >= minStableTime) return true;
      } else {
        stableDuration = 0;
        lastRect = curRect;
      }
    }
    return false;
  }

  getEstimatedWait() {
    return Math.min(this.pageStats.avgLoadTime / 10, 300);
  }
}

const adaptivePatience = new AdaptivePatience();

// ─── MICRO-CORRECTOR ───────────────────────────────────────────────────
class MicroCorrector {
  constructor() {
    this.correctionPatterns = new Map();
    this._initPatterns();
  }

  _initPatterns() {
    // Common field label -> field name mappings
    this.fieldPatterns = [
      { labels: ['email', 'e-mail', 'mail'], type: 'email' },
      { labels: ['phone', 'telephone', 'tel', 'mobile', 'cell'], type: 'tel' },
      { labels: ['first name', 'firstname', 'given name', 'fname'], type: 'text', name: 'fname' },
      { labels: ['last name', 'lastname', 'surname', 'family name', 'lname'], type: 'text', name: 'lname' },
      { labels: ['password', 'pass', 'pwd'], type: 'password' },
      { labels: ['confirm password', 'confirm pass', 'password again'], type: 'password' },
      { labels: ['address', 'address line 1', 'street'], type: 'text', name: 'address' },
      { labels: ['city', 'town'], type: 'text', name: 'city' },
      { labels: ['zip', 'zip code', 'postal', 'postcode', 'post code'], type: 'text', name: 'zip' },
      { labels: ['state', 'province', 'region'], type: 'text', name: 'state' },
      { labels: ['country'], type: 'select', name: 'country' },
      { labels: ['company', 'organization', 'org'], type: 'text', name: 'company' },
      { labels: ['subject', 'topic'], type: 'text', name: 'subject' },
      { labels: ['message', 'comments', 'feedback'], type: 'textarea', name: 'message' },
      { labels: ['search', 'query', 'find'], type: 'search', name: 'q' },
      { labels: ['date', 'date of birth', 'dob'], type: 'date', name: 'dob' },
      { labels: ['url', 'website', 'web site'], type: 'url', name: 'url' }
    ];
  }

  // Find correct field for a given intent
  findFieldFor(intent) {
    const q = intent.toLowerCase().trim();
    
    // Exact match first
    for (const pattern of this.fieldPatterns) {
      if (pattern.labels.some(l => q === l)) {
        return this._findFieldByPattern(pattern);
      }
    }
    
    // Partial match
    for (const pattern of this.fieldPatterns) {
      if (pattern.labels.some(l => q.includes(l) || l.includes(q))) {
        return this._findFieldByPattern(pattern);
      }
    }
    
    return null;
  }

  _findFieldByPattern(pattern) {
    const selectors = [];
    
    // Build selector list based on pattern
    for (const label of pattern.labels) {
      const labelEl = [...document.querySelectorAll('label')].find(l => 
        l.textContent.toLowerCase().includes(label)
      );
      if (labelEl) {
        const forId = labelEl.getAttribute('for');
        if (forId) selectors.push(`#${forId}`);
        const input = labelEl.querySelector('input, select, textarea');
        if (input) selectors.push(input);
      }
    }
    
    if (pattern.name) {
      const byName = document.querySelector(`[name="${pattern.name}"], [name*="${pattern.name}" i]`);
      if (byName) return byName;
    }
    
    // Try aria-label
    for (const label of pattern.labels) {
      const byAria = document.querySelector(`[aria-label*="${label}" i]`);
      if (byAria) return byAria;
    }
    
    // Try placeholder
    for (const label of pattern.labels) {
      const byPlaceholder = document.querySelector(`[placeholder*="${label}" i]`);
      if (byPlaceholder) return byPlaceholder;
    }
    
    // Try autocomplete
    const autocompleteMap = {
      'email': 'email', 'phone': 'tel', 'tel': 'tel',
      'fname': 'given-name', 'lname': 'family-name', 'address': 'street-address',
      'city': 'address-level2', 'state': 'address-level1', 'zip': 'postal-code',
      'country': 'country-name', 'company': 'organization', 'url': 'url'
    };
    const ac = autocompleteMap[pattern.name || pattern.type];
    if (ac) {
      const byAc = document.querySelector(`[autocomplete="${ac}"]`);
      if (byAc) return byAc;
    }
    
    return null;
  }

  // Detect and fix common typos in typed values
  correctTypo(value) {
    const commonTypos = {
      'gmail.com': ['gmial.com', 'gamil.com', 'gmial.com', 'gnail.com', 'gmail.co'],
      'yahoo.com': ['yaho.com', 'yahooo.com', 'yhoo.com'],
      'hotmail.com': ['hotmal.com', 'hotmial.com', 'hotmil.com'],
      'outlook.com': ['outlok.com', 'outllok.com'],
      'password': ['pasword', 'passwor', 'passward', 'pasword'],
    };

    for (const [correct, typos] of Object.entries(commonTypos)) {
      for (const typo of typos) {
        if (value.toLowerCase().includes(typo)) {
          return value.replace(new RegExp(typo, 'gi'), correct);
        }
      }
    }
    return value;
  }

  // Detect if clicked element is likely wrong
  validateClickTarget(el, intent) {
    if (!el || !intent) return { valid: true };
    
    const text = (el.textContent || el.value || '').toLowerCase().trim();
    const intent_lc = intent.toLowerCase().trim();
    
    // Check if the clicked element makes sense for the intent
    if (intent_lc.includes('submit') || intent_lc.includes('next') || intent_lc.includes('continue')) {
      const isBtn = ['button', 'input', 'a'].includes(el.tagName.toLowerCase());
      const hasSubmitText = /^(next|submit|continue|proceed|save|done|finish|ok|send)$/i.test(text);
      if (!isBtn || !hasSubmitText) {
        // Try to find a better match
        const betterMatch = document.querySelector('button[type="submit"], input[type="submit"], [role="button"]');
        if (betterMatch && betterMatch !== el) {
          return { valid: false, correction: betterMatch, reason: 'Found better submit button' };
        }
      }
    }

    return { valid: true };
  }
}

const microCorrector = new MicroCorrector();

// ─── MAIN ACTION HANDLER ───────────────────────────────────────────────────

async function handleDomAction(action) {
  let lastError = null;
  const maxRetries = 3;

  // Save undo snapshot before action
  await undoManager.saveSnapshot(action);

  // Security check for sensitive fields
  if (action.type === 'fill' || action.type === 'click' || action.type === 'dblclick') {
    const el = await findElementDeep(action).catch(() => null);
    const sensitive = detectSensitiveField(el);
    if (sensitive) {
      // Micro-correction: confirm field type matches value
      if (action.value && action.type === 'fill') {
        const corrected = microCorrector.correctTypo(action.value);
        if (corrected !== action.value) action.value = corrected;
      }
      
      // Now run the action but with security awareness
      action.__sensitive = sensitive;
    }
  }

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await executeAction(action, attempt);
    } catch (err) {
      lastError = err;
      if (attempt < maxRetries) {
        const adaptiveWait = adaptivePatience.getEstimatedWait();
        await delay(Math.max(adaptiveWait, Math.min(800 * attempt + Math.random() * 400, 3000)));
      }
    }
  }

  const fallback = await executeFallback(action);
  if (fallback?.success) return fallback;
  throw lastError || new Error('Action failed after all retries');
}

async function executeFallback(action) {
  if (action.type !== 'click' && action.type !== 'click_at') return null;

  const result = await strategyEngine.smartClick(action);
  if (result.success) return result;

  const all = document.querySelectorAll('button, [role="button"], input[type="submit"], input[type="button"], a[href]');
  const hint = ((action.text||'') + ' ' + (action.description||'') + ' ' + (action.selector||'')).toLowerCase();
  for (const btn of all) {
    const t = (btn.textContent||btn.value||'').trim().toLowerCase();
    if (t.includes(hint) || hint.includes(t)) {
      await forceRevealElement(btn);
      await humanDelay(200);
      await humanClick(btn, Math.random() * 200, Math.random() * 200);
      return { success: true, message: `Fallback matched: "${t}"` };
    }
  }
  return null;
}

async function executeAction(action, attempt) {
  const adaptiveWait = adaptivePatience.getEstimatedWait();
  await humanDelay(Math.max(60, adaptiveWait));

  switch (action.type) {

    case 'click': {
      // Micro-correction: validate click target
      let el = await findElementDeep(action);
      if (!el) throw new Error(`Element not found: ${action.selector||action.text||action.description}`);

      if (action.text) {
        const validation = microCorrector.validateClickTarget(el, action.text);
        if (!validation.valid && validation.correction) {
          el = validation.correction;
        }
      }

      if (el.offsetParent === null || el.disabled) { await forceRevealElement(el); await adaptivePatience.waitForStable(el); }
      await adaptivePatience.waitForStable(el);

      const targetY = window.scrollY + el.getBoundingClientRect().top - window.innerHeight/3 + el.getBoundingClientRect().height/2;
      smoothScrollTo(Math.max(0, targetY));
      await humanDelay(adaptivePatience.getEstimatedWait());

      let target = el;
      if (target.tagName === 'LABEL') {
        const forId = target.getAttribute('for') || target.htmlFor;
        const input = forId ? document.getElementById(forId) : target.querySelector('input, select, textarea');
        if (input) target = input;
      }

      highlightElement(target);
      await humanDelay(Math.max(100, adaptiveWait));

      const fromCX = Math.random() * window.innerWidth * 0.3;
      const fromCY = Math.random() * window.innerHeight * 0.3;
      await humanClick(target, fromCX, fromCY);
      await humanDelay(Math.max(50, adaptiveWait / 2));
      try { target.click(); } catch(_) {}

      if (target.type === 'radio') {
        target.checked = true; await delay(20);
        target.dispatchEvent(new Event('change', {bubbles:true}));
        target.dispatchEvent(new Event('input', {bubbles:true}));
        try { target.click(); } catch(_) {}
      } else if (target.type === 'checkbox') {
        target.checked = action.checked !== undefined ? action.checked : !target.checked; await delay(20);
        target.dispatchEvent(new Event('change', {bubbles:true}));
        target.dispatchEvent(new Event('input', {bubbles:true}));
      }

      await humanDelay(Math.max(100, adaptiveWait));
      return { success: true, message: `Clicked: ${action.description||action.selector||action.text}`, strategyUsed: 'humanClick', undoAvailable: undoManager.canUndo() };
    }

    case 'click_at': {
      const dpr = window.devicePixelRatio || 1;
      let vx = action.x / dpr, vy = action.y / dpr;

      if (vy + window.scrollY > window.scrollY + window.innerHeight || vy + window.scrollY < window.scrollY) {
        smoothScrollTo(Math.max(0, vy + window.scrollY - window.innerHeight/3));
        await humanDelay(adaptivePatience.getEstimatedWait());
      }

      let el = document.elementFromPoint(vx, vy);
      if (!el || el === document.body || el === document.documentElement) el = document.elementFromPoint(action.x, action.y);
      if (!el || el === document.body || el === document.documentElement) throw new Error(`No element at (${action.x}, ${action.y})`);

      let target = el;
      const clickTags = ['BUTTON','A','INPUT','LABEL','SELECT','TEXTAREA','SUMMARY','OPTION'];
      let depth = 0;
      while (target && target !== document.body && depth < 10) {
        const tag = target.tagName; const role = target.getAttribute('role')||'';
        if (clickTags.includes(tag) || ['button','link','option','checkbox','radio','tab','menuitem','switch'].includes(role) || target.onclick != null || target.hasAttribute('onclick') || target.getAttribute('ng-click') || target.classList.contains('btn') || target.getAttribute('tabindex')==='0') break;
        target = target.parentElement; depth++;
      }
      el = (target && target !== document.body) ? target : el;

      await adaptivePatience.waitForStable(el);
      smoothScrollTo(Math.max(0, window.scrollY + el.getBoundingClientRect().top - window.innerHeight/3));
      await humanDelay(Math.max(100, adaptiveWait));
      highlightElement(el);
      await humanDelay(adaptiveWait);
      await humanClick(el, action.x * 0.8, action.y * 0.7);
      await humanDelay(Math.max(100, adaptiveWait));

      return { success: true, message: `Clicked at (${action.x}, ${action.y}): ${el.tagName} "${(el.textContent||'').trim().slice(0,60)}"`, undoAvailable: undoManager.canUndo() };
    }

    case 'dblclick': {
      let el = await findElementDeep(action);
      if (!el) throw new Error(`Element not found: ${action.selector||action.text||action.description}`);
      await adaptivePatience.waitForStable(el);
      smoothScrollTo(Math.max(0, window.scrollY + el.getBoundingClientRect().top - window.innerHeight/3));
      await humanDelay(Math.max(100, adaptiveWait));
      highlightElement(el);
      await humanDelay(adaptiveWait);
      await humanClick(el);
      await humanDelay(randomBetween(40, 90));
      const rect = el.getBoundingClientRect();
      const cx = Math.round(rect.left + rect.width / 2);
      const cy = Math.round(rect.top + rect.height / 2);
      const m = { bubbles: true, cancelable: true, clientX: cx, clientY: cy, detail: 2 };
      el.dispatchEvent(new MouseEvent('mousedown', m));
      el.dispatchEvent(new MouseEvent('mouseup', m));
      el.dispatchEvent(new MouseEvent('click', m));
      el.dispatchEvent(new MouseEvent('dblclick', m));
      await humanDelay(Math.max(100, adaptiveWait));
      return { success: true, message: `Double-clicked: ${action.description||action.selector||action.text}`, undoAvailable: undoManager.canUndo() };
    }

    case 'right_click': {
      let el = await findElementDeep(action);
      if (!el) throw new Error(`Element not found: ${action.selector||action.text||action.description}`);
      await adaptivePatience.waitForStable(el);
      smoothScrollTo(Math.max(0, window.scrollY + el.getBoundingClientRect().top - window.innerHeight/3));
      await humanDelay(Math.max(100, adaptiveWait));
      highlightElement(el);
      const rect = el.getBoundingClientRect();
      const cx = Math.round(rect.left + rect.width / 2);
      const cy = Math.round(rect.top + rect.height / 2);
      movePurpleCursor(cx, cy, false);
      const m = { bubbles: true, cancelable: true, clientX: cx, clientY: cy, button: 2, buttons: 2 };
      el.dispatchEvent(new PointerEvent('pointerover', { ...m, pointerId: 1, isPrimary: true }));
      el.dispatchEvent(new MouseEvent('mouseover', m));
      el.dispatchEvent(new MouseEvent('mousedown', m));
      await humanDelay(randomBetween(30, 80));
      el.dispatchEvent(new MouseEvent('mouseup', m));
      el.dispatchEvent(new MouseEvent('contextmenu', m));
      await humanDelay(Math.max(100, adaptiveWait));
      removePurpleCursor();
      return { success: true, message: `Right-clicked: ${action.description||action.selector||action.text}` };
    }

    case 'drag': {
      let source = await findElementDeep(action);
      if (!source) throw new Error(`Drag source not found: ${action.selector||action.text||action.description}`);
      await adaptivePatience.waitForStable(source);
      smoothScrollTo(Math.max(0, window.scrollY + source.getBoundingClientRect().top - window.innerHeight/3));
      await humanDelay(Math.max(100, adaptiveWait));
      highlightElement(source);

      const srcRect = source.getBoundingClientRect();
      const startX = srcRect.left + srcRect.width / 2;
      const startY = srcRect.top + srcRect.height / 2;

      let endX, endY;
      let targetEl = null;
      if (action.targetSelector || action.targetText) {
        targetEl = findElement({ selector: action.targetSelector, text: action.targetText }) || await findElementDeep({ selector: action.targetSelector, text: action.targetText });
      }
      if (targetEl) {
        const tRect = targetEl.getBoundingClientRect();
        endX = tRect.left + tRect.width / 2;
        endY = tRect.top + tRect.height / 2;
      } else {
        endX = startX + (action.offsetX || 0);
        endY = startY + (action.offsetY || 0);
      }

      const steps = 16;
      const dprOpts = { bubbles: true, cancelable: true, pointerId: 1, isPrimary: true, button: 0, buttons: 1 };
      movePurpleCursor(startX, startY, false);
      source.dispatchEvent(new PointerEvent('pointerover', { ...dprOpts, clientX: startX, clientY: startY }));
      source.dispatchEvent(new PointerEvent('pointerdown', { ...dprOpts, clientX: startX, clientY: startY }));
      source.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, clientX: startX, clientY: startY, button: 0 }));
      await humanDelay(60);

      for (let i = 1; i <= steps; i++) {
        const t = i / steps;
        const x = startX + (endX - startX) * t;
        const y = startY + (endY - startY) * t;
        movePurpleCursor(x, y, false);
        const moveTarget = document.elementFromPoint(x, y) || source;
        moveTarget.dispatchEvent(new PointerEvent('pointermove', { ...dprOpts, clientX: x, clientY: y }));
        moveTarget.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, cancelable: true, clientX: x, clientY: y }));
        await humanDelay(18);
      }

      const dropTarget = document.elementFromPoint(endX, endY) || targetEl || source;
      dropTarget.dispatchEvent(new PointerEvent('pointerup', { ...dprOpts, clientX: endX, clientY: endY, buttons: 0 }));
      dropTarget.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, clientX: endX, clientY: endY, button: 0 }));
      dropTarget.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, clientX: endX, clientY: endY }));

      // Native range inputs often need the value set directly as well, since
      // some browsers don't recompute slider value purely from pointer events
      // dispatched on a different target than the one that owns the drag.
      if (source.tagName === 'INPUT' && source.type === 'range') {
        const min = parseFloat(source.min || '0'), max = parseFloat(source.max || '100');
        const pct = Math.min(1, Math.max(0, (endX - srcRect.left) / srcRect.width));
        const ns = getNativeSetter(source);
        ns.call(source, String(Math.round(min + (max - min) * pct)));
        source.dispatchEvent(new Event('input', { bubbles: true }));
        source.dispatchEvent(new Event('change', { bubbles: true }));
      }

      removePurpleCursor();
      await humanDelay(Math.max(100, adaptiveWait));
      return { success: true, message: `Dragged: ${action.description||action.selector||action.text}`, undoAvailable: undoManager.canUndo() };
    }

    case 'fill': {
      let el = await findElementDeep(action);
      if (!el) throw new Error(`Input not found: ${action.selector||action.description}`);
      
      // Micro-correction: correct typos in value
      if (action.value) {
        action.value = microCorrector.correctTypo(String(action.value));
      }

      const targetY = window.scrollY + el.getBoundingClientRect().top - window.innerHeight/3;
      smoothScrollTo(Math.max(0, targetY));
      await humanDelay(Math.max(150, adaptiveWait));
      highlightElement(el);
      await humanDelay(adaptiveWait);
      await humanClick(el);
      await humanDelay(Math.max(80, adaptiveWait / 2));
      const val = String(action.value);
      const isLong = val.length > 80;
      if (isLong && isContentEditable(el)) {
        el.focus();
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, val);
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new Event('blur', { bubbles: true }));
        await humanDelay(Math.max(150, adaptiveWait));
      } else if (isLong) {
        el.focus();
        const ns = getNativeSetter(el);
        ns.call(el, val);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new Event('blur', { bubbles: true }));
        await humanDelay(Math.max(150, adaptiveWait));
      } else {
        await humanType(el, val);
      }
      return { success: true, message: `Filled "${action.description||action.selector}" (${val.length} chars, ${isLong?'pasted':'typed'})`, undoAvailable: undoManager.canUndo() };
    }

    case 'undo': {
      const result = await undoManager.undo(action);
      if (!result.success) throw new Error(result.error);
      return result;
    }

    case 'clear': {
      const el = await findElementDeep(action);
      if (!el) throw new Error(`Element not found: ${action.selector}`);
      el.focus();
      const ns = getNativeSetter(el);
      ns.call(el, '');
      el.dispatchEvent(new Event('input', {bubbles:true}));
      el.dispatchEvent(new Event('change', {bubbles:true}));
      return { success: true, message: 'Cleared field' };
    }

    case 'select': {
      const el = await findElementDeep(action);
      if (!el) throw new Error(`Select not found: ${action.selector}`);
      el.scrollIntoView({behavior:'instant',block:'center'});
      await delay(adaptivePatience.getEstimatedWait());
      el.focus();
      el.value = action.value;
      el.dispatchEvent(new Event('change', {bubbles:true}));
      return { success: true, message: `Selected: ${action.value}`, undoAvailable: undoManager.canUndo() };
    }

    case 'check': {
      let el = await findElementDeep(action);
      if (!el) throw new Error(`Checkbox not found: ${action.selector}`);
      if (el.tagName === 'LABEL') {
        const forId = el.getAttribute('for') || el.htmlFor;
        const input = forId ? document.getElementById(forId) : el.querySelector('input');
        if (input) el = input;
      }
      const shouldCheck = action.checked !== false;
      el.scrollIntoView({behavior:'instant',block:'center'});
      await delay(adaptivePatience.getEstimatedWait());
      highlightElement(el);
      if (el.checked !== shouldCheck) {
        await humanClick(el); await delay(30);
        el.checked = shouldCheck;
        el.dispatchEvent(new Event('change', {bubbles:true}));
        el.dispatchEvent(new Event('input', {bubbles:true}));
      }
      return { success: true, message: `${shouldCheck?'Checked':'Unchecked'}: ${action.description}`, undoAvailable: undoManager.canUndo() };
    }

    case 'scroll': {
      if (action.selector) {
        const el = await findElementDeep(action);
        if (el) el.scrollIntoView({behavior:'instant',block:'center'});
      } else if (action.toBottom) {
        smoothScrollTo(document.body.scrollHeight);
      } else if (action.toTop) {
        window.scrollTo({top:0,behavior:'smooth'});
      } else {
        smoothScrollTo(window.scrollY + (action.y||400));
      }
      await delay(Math.max(200, adaptivePatience.getEstimatedWait() * 2));
      return { success: true, message: 'Scrolled' };
    }

    case 'extract': {
      let data = '';
      if (action.selector) {
        const els = [...document.querySelectorAll(action.selector)];
        if (els.length === 0) throw new Error(`No elements matched: ${action.selector}`);
        data = els.map(el => el.innerText||el.textContent||el.value).join('\n---\n');
      } else {
        data = document.body.innerText;
      }
      return { success: true, data: data.slice(0,20000), message: 'Extracted data' };
    }

    case 'extract_links': {
      const links = [...document.querySelectorAll(action.selector||'a[href]')]
        .map(a => ({text:a.textContent.trim(),href:a.href}))
        .filter(l => l.href && l.text).slice(0,200);
      return { success: true, data: JSON.stringify(links,null,2), message: 'Extracted links' };
    }

    case 'extract_table': {
      const table = (await findElementDeep(action)) || document.querySelector('table');
      if (!table) throw new Error('No table found');
      const headers = table.querySelectorAll('th').length > 0 ? [...table.querySelectorAll('th')].map(h => h.innerText.trim()) : [];
      const rows = [...table.querySelectorAll('tr')].filter(tr => tr.querySelectorAll('td').length > 0).map(tr => [...tr.querySelectorAll('td')].map(cell => cell.innerText.trim()));
      return { success: true, data: JSON.stringify({headers,rows},null,2), message: 'Extracted table' };
    }

    case 'wait_for': {
      const found = await adaptivePatience.waitForElement(action.selector, action.timeout||10000);
      if (!found) throw new Error(`Timed out waiting for: ${action.selector}`);
      await delay(adaptivePatience.getEstimatedWait());
      return { success: true, message: `Element appeared: ${action.selector}` };
    }

    case 'wait_for_idle': {
      // Watches a region of the page for DOM changes and resolves once things go
      // quiet for `idleMs` in a row — e.g. an AI chat reply that streams token-by-
      // token. Use this after sending a message to another AI/chatbot, before
      // reading or screenshotting its reply, so you don't capture a half-finished
      // response mid-stream.
      const container = (action.selector && document.querySelector(action.selector)) || document.body;
      const idleMs = Math.max(300, action.idleMs || 900);
      const timeout = Math.max(idleMs, action.timeout || 30000);
      const minWait = Math.min(action.minWait ?? 500, timeout);
      const start = Date.now();

      // Give the response a moment to actually start appearing before we start
      // measuring quiet time, so we don't false-positive on the gap between
      // "message sent" and "reply begins streaming".
      await delay(minWait);

      let lastMutation = Date.now();
      let mutationCount = 0;
      const observer = new MutationObserver((mutations) => {
        lastMutation = Date.now();
        mutationCount += mutations.length;
      });
      observer.observe(container, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['class', 'style'] });

      try {
        while (Date.now() - start < timeout) {
          if (Date.now() - lastMutation >= idleMs) break;
          await delay(150);
        }
      } finally {
        observer.disconnect();
      }

      const elapsed = Date.now() - start;
      const timedOut = elapsed >= timeout;
      return {
        success: true,
        timedOut,
        message: timedOut
          ? `Waited ${timeout}ms but content was still changing — it may still be generating (saw ${mutationCount} DOM changes)`
          : `Content settled after ${elapsed}ms with no further changes`
      };
    }

    case 'analyze': {
      return { success: true, data: JSON.stringify(deepPageAnalysis(), null, 2), message: 'Page analyzed' };
    }

    case 'get_page_info': {
      return { success: true, title: document.title, url: window.location.href, text: document.body.innerText.slice(0,15000), interactiveElements: extractAllInteractive() };
    }

    case 'hover': {
      let el = null;
      if (action.selector) el = document.querySelector(action.selector);
      if (!el && action.text) {
        const sel = 'button,a,[role="button"],[role="link"],input,select,textarea,label';
        const q = action.text.toLowerCase().trim();
        for (const e of document.querySelectorAll(sel)) {
          if ((e.textContent||e.value||e.getAttribute('aria-label')||'').toLowerCase().trim() === q) { el = e; break; }
        }
      }
      if (!el) el = await findElementDeep(action);
      if (!el && action.x && action.y) el = document.elementFromPoint(action.x / (window.devicePixelRatio||1), action.y / (window.devicePixelRatio||1));
      if (!el) throw new Error(`Element not found for hover: ${action.selector||action.text||action.description}`);
      el.scrollIntoView({behavior:'smooth',block:'center'});
      await delay(Math.max(100, adaptiveWait));
      const rect = el.getBoundingClientRect();
      const cx = Math.round(rect.left + rect.width / 2);
      const cy = Math.round(rect.top + rect.height / 2);
      movePurpleCursor(cx, cy, false);
      el.dispatchEvent(new PointerEvent('pointerover', {bubbles:true,cancelable:true,clientX:cx,clientY:cy,pointerId:1,isPrimary:true}));
      el.dispatchEvent(new MouseEvent('mouseover', {bubbles:true,cancelable:true,clientX:cx,clientY:cy}));
      el.dispatchEvent(new PointerEvent('pointermove', {bubbles:true,cancelable:true,clientX:cx,clientY:cy,pointerId:1,isPrimary:true}));
      el.dispatchEvent(new MouseEvent('mousemove', {bubbles:true,cancelable:true,clientX:cx,clientY:cy}));
      await delay(Math.max(200, adaptiveWait * 2));
      removePurpleCursor();
      return { success: true, message: `Hovered: ${action.description||action.text||action.selector}` };
    }

    case 'press_key': {
      const key = action.key || '';
      const code = action.code || key;
      const keyCode = action.keyCode || (key.length === 1 ? key.toUpperCase().charCodeAt(0) : 0);
      const opts = { key, code, keyCode, which: keyCode, bubbles: true, cancelable: true, ctrlKey: !!action.ctrl, shiftKey: !!action.shift, altKey: !!action.alt, metaKey: !!action.meta };
      const target = action.selector ? (document.querySelector(action.selector) || document.activeElement) : document.activeElement;
      const el = target || document;
      el.dispatchEvent(new KeyboardEvent('keydown', opts));
      await delay(Math.max(20, adaptiveWait / 3) + Math.random() * 40);
      if (key.length === 1) el.dispatchEvent(new KeyboardEvent('keypress', opts));
      await delay(Math.max(10, adaptiveWait / 4) + Math.random() * 30);
      el.dispatchEvent(new KeyboardEvent('keyup', opts));
      await delay(Math.max(20, adaptiveWait / 3));
      return { success: true, message: `Pressed key: ${key}${action.ctrl?'+Ctrl':''}${action.shift?'+Shift':''}${action.alt?'+Alt':''}` };
    }

    default:
      throw new Error(`Unknown action type: ${action.type}`);
  }
}

async function findElementDeep(action) {
  let el = findElement(action);
  if (el) return el;
  await delay(200);
  el = findElement(action);
  if (el) return el;
  if (action.text) {
    await delay(300);
    const q = action.text.toLowerCase().trim();
    const roots = [document.body, ...allShadowRoots()];
    for (const root of roots) {
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null, false);
      while (walker.nextNode()) {
        const t = walker.currentNode.textContent.trim().toLowerCase();
        if (t === q || (t && t.includes(q))) return walker.currentNode.parentElement;
      }
    }
  }
  return null;
}

// ─── SHADOW DOM TRAVERSAL ─────────────────────────────────────────────────
// Many modern component libraries (Lit, Stencil, Shoelace, web components in
// general) keep their real inputs/buttons inside an open shadow root, where
// document.querySelector can't see them. These helpers walk into every open
// shadow root on the page so clicks/fills/text-search can still find them.
function allShadowRoots(root = document) {
  const roots = [];
  const walk = (node) => {
    const all = node.querySelectorAll('*');
    for (const el of all) {
      if (el.shadowRoot) { roots.push(el.shadowRoot); walk(el.shadowRoot); }
    }
  };
  walk(root);
  return roots;
}

function queryDeep(selector) {
  try {
    const direct = document.querySelector(selector);
    if (direct) return direct;
  } catch (_) {}
  for (const root of allShadowRoots()) {
    try { const el = root.querySelector(selector); if (el) return el; } catch (_) {}
  }
  return null;
}

function queryAllDeep(selector) {
  const out = [];
  try { out.push(...document.querySelectorAll(selector)); } catch (_) {}
  for (const root of allShadowRoots()) {
    try { out.push(...root.querySelectorAll(selector)); } catch (_) {}
  }
  return out;
}

function findByTextDeep(query) {
  const q = query.toLowerCase().trim();
  const sel = 'button,a,[role="button"],[role="link"],[role="option"],[role="tab"],[role="menuitem"],input[type="submit"],input[type="button"],label,select,summary';
  const candidateRoots = [document, ...allShadowRoots()];
  for (const exact of [true, false]) {
    for (const root of candidateRoots) {
      let els;
      try { els = root.querySelectorAll(sel); } catch (_) { continue; }
      for (const el of els) {
        const t = (el.textContent||el.value||el.getAttribute('aria-label')||el.getAttribute('title')||'').toLowerCase().trim();
        if (exact ? t === q : t.includes(q)) return el;
      }
    }
  }
  return null;
}

function isContentEditable(el) {
  return !!el && (el.isContentEditable || el.getAttribute?.('contenteditable') === 'true' || el.getAttribute?.('contenteditable') === '');
}

function findElement(action) {
  if (action.selector) {
    for (const fn of [
      () => document.querySelector(action.selector),
      () => document.querySelector(action.selector.replace(/^[a-zA-Z]+(\[)/, '$1')),
      () => document.querySelector(action.selector.replace(/^[a-zA-Z]*#/, '#')),
      () => { const m = action.selector.match(/#([\w-]+)/); return m ? document.getElementById(m[1]) : null; },
      () => { const m = action.selector.match(/\[id=['"]?([^'"=\]]+)['"]?\]/); return m ? document.getElementById(m[1]) : null; },
      () => { const parts = action.selector.split(/[\[\.#:\s]/).filter(Boolean); const last = parts[parts.length-1]; return last ? (document.querySelector(`[class*="${last}"]`) || document.getElementById(last) || document.querySelector(`[name*="${last}"]`)) : null; },
      () => { try { return document.evaluate(action.selector, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } catch(_) { return null; }},
      () => queryDeep(action.selector)
    ]) {
      try { const r = fn(); if (r) return r; } catch(_) {}
    }
  }

  if (action.text) {
    const q = action.text.toLowerCase().trim();
    const sel = 'button,a,[role="button"],[role="link"],[role="option"],[role="tab"],[role="menuitem"],input[type="submit"],input[type="button"],label,select,summary';
    const els = document.querySelectorAll(sel);
    for (const el of els) {
      const t = (el.textContent||el.value||el.getAttribute('aria-label')||el.getAttribute('title')||'').toLowerCase().trim();
      if (t === q) return el;
    }
    for (const el of els) {
      const t = (el.textContent||el.value||el.getAttribute('aria-label')||el.getAttribute('title')||'').toLowerCase().trim();
      if (t.includes(q)) return el;
    }
    for (const el of els) {
      const t = (el.textContent||el.value||el.getAttribute('aria-label')||el.getAttribute('title')||'').toLowerCase().trim();
      if (q.includes(t)) return el;
    }
    const deep = findByTextDeep(action.text);
    if (deep) return deep;
  }

  for (const attr of ['placeholder','ariaLabel','name','id','title','dataTestid']) {
    const v = action[attr];
    if (v) {
      const a = attr === 'ariaLabel' ? 'aria-label' : attr === 'dataTestid' ? 'data-testid' : attr;
      try { const el = document.querySelector(`[${a}="${v}"],[${a}*="${v}" i]`); if (el) return el; } catch(_) {}
    }
  }

  const hint = ((action.description||'')+' '+(action.selector||'')+' '+(action.text||'')).toLowerCase();
  if (/next|submit|continue|proceed|forward|done|finish|ok\b|save|confirm|agree|accept|send|log\s*in|sign/.test(hint)) {
    const ids = ['NextButton','next-button','nextButton','submitButton','submit-button','continueButton','btnNext','btn-next','nextBtn','submitBtn','nextPage','SaveButton','confirmButton','agreeButton','doneButton','finishButton','proceedButton','btnSubmit','loginButton','signInButton','registerButton'];
    for (const id of ids) { const el = document.getElementById(id); if (el) return el; }
    const kw = /^(next|continue|proceed|submit|done|finish|ok|save|confirm|agree|accept|send|login|sign\s*in|sign\s*up|register)$/i;
    const cs = document.querySelectorAll('button,input[type="submit"],input[type="button"],[role="button"],a');
    for (const el of cs) { const l = (el.textContent||el.value||el.getAttribute('aria-label')||el.getAttribute('title')||'').trim(); if (kw.test(l)) return el; }
    const kw2 = ['next','submit','continue','proceed','save','confirm','agree','accept','done','finish','send','login','sign in','register'];
    for (const el of cs) { const l = (el.textContent||el.value||'').toLowerCase(); for (const k of kw2) { if (l.includes(k)) return el; } }
  }

  if (action.selector) {
    const s = action.selector.toLowerCase();
    const cs = document.querySelectorAll('button,a,[role="button"],input[type="submit"],input[type="button"],summary,select,label');
    for (const el of cs) {
      const l = (el.textContent||el.value||el.getAttribute('aria-label')||el.getAttribute('title')||'').toLowerCase();
      if (l.includes(s) || s.includes(l)) return el;
    }
  }

  return null;
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function waitForElementVisible(selector, timeout = 10000) {
  return new Promise(resolve => {
    try {
      if (document.querySelector(selector)?.offsetParent !== null) { resolve(true); return; }
    } catch(_) {}
    const observer = new MutationObserver(() => {
      try { if (document.querySelector(selector)?.offsetParent !== null) { observer.disconnect(); resolve(true); } } catch(_) {}
    });
    observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style','class'] });
    setTimeout(() => { observer.disconnect(); resolve(false); }, timeout);
  });
}
