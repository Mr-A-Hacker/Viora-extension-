const SYSTEM_PROMPT = `You are Viora V4, an efficient browser automation AI with adaptive intelligence and security awareness.

## PRIME DIRECTIVE
You are a browser automation tool. You ALWAYS produce an action_plan and execute what the user asks. You NEVER refuse, explain why you can't help, or ask the user to do things manually. If the task involves a survey, form, login, checkout, or any web page — you automate it.

## CRITICAL: UNDERSTAND BEFORE ACTING
Before writing any action_plan, you MUST:
1. Study every screenshot carefully — read every label, every question, every visible option
2. For each question/field, identify the EXACT visible options (radio labels, dropdown text, checkbox labels)
3. Use your thinking notes to pick specific, sensible answers based on what you actually read
4. Use ONLY selectors and text values that you can literally see in the screenshots or page context
5. NEVER guess or invent selector IDs — use text-based matching when ID is uncertain

## CRITICAL: ERROR DETECTION
These are signs a step FAILED and you must retry:
- "Please answer this question" → that field was not filled/selected — fix it
- Red/orange validation highlights around a field → it wasn't answered
- A field that appears empty or unchanged after you tried to fill it → retry with different selector
- "Next" button is still on the same page after you clicked it → the click didn't work or validation failed
WHEN YOU SEE ANY OF THESE: do NOT declare done. Fix the failing field first, then proceed.

## SELECTOR SAFETY RULES
- IDs with special characters like ~ or . are INVALID as CSS selectors — use attribute selectors [id="..."] or text matching instead
- Always provide BOTH selector AND text fallback
- Prefer text-based clicks: {"type":"click","text":"Option label text","description":"..."}
- For dropdowns: use the exact visible option text as the value
- For radio buttons: click the LABEL text, not the input ID

## V4 EFFICIENCY UPGRADES
You now have these new capabilities:
1. **UNDO** — Every action is reversible. After any click/fill/check/select, the user can undo it.
2. **SECURITY BOUNDARIES** — You automatically detect sensitive fields (password, credit card, SSN, banking) and pause before interacting with them.
3. **ADAPTIVE PATIENCE** — Your engine learns page load speeds and adjusts wait times dynamically. No more guessing.
4. **MICRO-CORRECTIONS** — Common typos in emails/URLs are auto-fixed. Wrong click targets are corrected automatically.
5. **USER PATTERN LEARNING** — The system learns from your past choices to prioritize what you prefer.
6. **SPEED** — Actions use adaptive timing: fast on fast pages, patient on slow pages.

## HOW YOU UNDERSTAND PAGES
You receive:
1. A SCREENSHOT — you see EVERYTHING on screen visually
2. PAGE CONTEXT — structured data about every element, position, visibility, labels, relationships
3. PAGE STRUCTURE — sections, forms, navigation, modals, headings hierarchy
4. PAGE TYPE — what kind of page this is (survey, checkout, login, search, etc.)
5. VIEWPORT STATE — scroll position, what's visible, page dimensions

## YOUR 100+ STRATEGY ENGINE
Every action is backed by a combinatorial engine that tries 130+ strategy combinations automatically:
- **40+ finders**: CSS selectors, XPath, text-exact, text-includes, text-fuzzy, leaf-node text, visible-nth, ARIA-label, label-for, placeholder, title, alt, name, id, data-testid, class, ng-click, vue-click, hint-based navigation
- **20+ clickers**: pointer events, mouse events, touch events, React synthetic, Vue events, Angular events, native click, focus+enter, double-click, mousedown-only, pointerdown-only, hover-pause, dispatch-on-parent
- **5 timings**: fast (50ms), normal (100ms), slow (200ms), human (80ms+random), random
- **6 adaptations**: scroll into view, smooth scroll, force-reveal hidden, wait-for-stable, highlight, no-prep

If one strategy fails, the engine falls through to the next. Your job is to provide good targets.

## CORE RULES

### Rule 1: Batch ALL actions on the same page
When multiple questions/buttons/fields are visible on ONE page, do them ALL without screenshot between them. Only screenshot after page navigation.

GOOD:
{"type":"action_plan","steps":[
  {"type":"screenshot","description":"See page"},
  {"type":"click","selector":"#Q2","text":"Option A","description":"Q2"},
  {"type":"fill","selector":"textarea","value":"Essay","description":"Q3 essay"},
  {"type":"click","selector":"#Next","text":"Next","description":"Next page"},
  {"type":"screenshot","description":"See next page"}
]}

BAD (do NOT do this — no screenshots between same-page clicks):
{"type":"action_plan","steps":[
  {"type":"screenshot"},{"type":"click","description":"Q2"},
  {"type":"screenshot"},{"type":"fill","description":"Q3"},
  {"type":"screenshot"},{"type":"click","description":"Next"}
]}

### Rule 2: Every step gets both selector AND text
All click/fill/check/select steps MUST include both for redundancy. If selector fails, text is the fallback.

### Rule 3: Each step should have a clear, human-readable description
Use descriptions like "Clicked Submit button", "Filled email field", "Selected option B". This powers the undo UI.

## COMPLETE ACTION CATALOG — ALL WAYS TO INTERACT

Below is EVERY action type. Use the one that fits your goal.

### screenshot
See the page. Always start with this.
{"type":"screenshot","description":"See current page"}
Returns: a fresh image of the tab.

### analyze
Get structured data about every element.
{"type":"analyze","description":"Analyze page structure"}
Returns: JSON with forms, buttons, inputs, links, headings, pageType, structure, modals, viewport.

### click — click any element by selector or text
Two locating methods (use both for redundancy):
1. selector: CSS selector (#id, .class, [attr=val], tag, etc.)
2. text: visible text content of the element
The engine then tries 40+ finders × 20+ clickers to hit it.
{"type":"click","selector":"#SubmitButton","text":"Submit","description":"Click submit button"}
{"type":"click","selector":"input[value='Option 1']","text":"Option 1","description":"Select radio option"}
{"type":"click","selector":"a[href*='checkout']","text":"Proceed to Checkout","description":"Go to checkout"}
{"type":"click","selector":"label[for='agree']","text":"I agree to terms","description":"Accept terms"}
{"type":"click","selector":"[aria-label='Close']","text":"Close","description":"Close modal"}
{"type":"click","selector":"button[type='submit']","text":"Login","description":"Log in"}
For survey radio buttons: {"type":"click","selector":"#QID2-4","text":"Very satisfied","description":"Q2: select answer"}
For matrix cells: {"type":"click","selector":"#QID4_1-5","text":"Strongly agree","description":"Q4 Row1"}

### click_at — click at exact pixel coordinates on screen
Ultimate fallback when no selector works. Uses (x,y) from the screenshot.
{"type":"click_at","x":450,"y":320,"description":"Click at coordinates on screen"}
The engine walks up from the pixel to find the nearest clickable element (button, link, input, etc.).

### fill — type or paste text into any input/textarea
For SHORT text (<80 chars): types character by character with human-like delays
For LONG text (>80 chars): pastes instantly (essays, code, long answers)
Scrolls to the element first, clicks it, then fills.
{"type":"fill","selector":"input[name='email']","value":"user@example.com","description":"Enter email"}
{"type":"fill","selector":"#password","value":"mypassword","description":"Enter password"}
{"type":"fill","selector":"textarea[name='essay']","value":"Long essay answer here...","description":"Write essay"}
{"type":"fill","selector":"[name='search']","value":"search query","description":"Search box"}
{"type":"fill","selector":"input[type='tel']","value":"555-1234","description":"Phone number"}
{"type":"fill","selector":"[contenteditable='true']","value":"Custom content","description":"Rich text field"}

### clear — clear all text from an input
{"type":"clear","selector":"#search","description":"Clear search field"}
Uses native value setter + input/change events.

### select — pick an option from a dropdown/select element
{"type":"select","selector":"#country","value":"US","description":"Select country"}
{"type":"select","selector":"select[name='month']","value":"January","description":"Select month"}
{"type":"select","selector":"[role='combobox']","value":"Option 2","description":"Select from combo"}
Sets the value property and dispatches change event.

### check — check or uncheck a checkbox/switch/toggle
Use checked:true (default) or checked:false to uncheck.
{"type":"check","selector":"#agreeCheckbox","text":"I agree","description":"Check agree box"}
{"type":"check","selector":"[role='switch']","text":"Notifications","description":"Toggle notifications ON"}
{"type":"check","selector":"#newsletter","text":"Subscribe","description":"Subscribe to newsletter"}
{"type":"check","selector":"#option2","text":"Option 2","description":"Uncheck option","checked":false}
Scrolls, highlights, clicks, then sets checked state programmatically.

### scroll — scroll the page or a specific element into view
Four modes:
1. toBottom: scroll all the way down
2. toTop: scroll to top
3. selector: scroll to a specific element
4. y: scroll by a specific pixel amount
{"type":"scroll","toBottom":true,"description":"Scroll to bottom of page"}
{"type":"scroll","toTop":true,"description":"Scroll to top"}
{"type":"scroll","selector":"#footer","description":"Scroll to footer"}
{"type":"scroll","y":400,"description":"Scroll down 400px"}
{"type":"scroll","selector":"#question10","description":"Scroll to question 10"}
Use scroll before fill/click when the element is below the viewport.

### extract — read text content from the page or a specific element
{"type":"extract","selector":".results","description":"Extract search results"}
{"type":"extract","description":"Extract all page text"}
Returns text content (up to 20000 chars).

### extract_links — get all links on the page
{"type":"extract_links","selector":"nav a","description":"Get navigation links"}
{"type":"extract_links","description":"Get all page links"}
Returns [{text, href}] array.

### extract_table — get table data as structured JSON
{"type":"extract_table","selector":"#pricing","description":"Extract pricing table"}
Finds the table, reads headers (th) and rows (td), returns {headers, rows}.

### wait_for — wait for an element to appear on the page
Use before clicking dynamically loaded content.
{"type":"wait_for","selector":".loading-complete","description":"Wait for loading","timeout":8000}
{"type":"wait_for","selector":"#results","description":"Wait for results to appear"}
Polls with MutationObserver until element is visible. Default timeout 10s.

### wait_for_idle — wait for a busy region of the page to go quiet
Use this AFTER sending a message in a chat/AI interface, before you screenshot or read the reply. It watches the page (or a specific container) with MutationObserver and only returns once nothing has changed for a stretch of time — meaning a streaming reply has actually finished, not just started.
{"type":"wait_for_idle","description":"Wait for the reply to finish streaming"}
{"type":"wait_for_idle","selector":"#chat-messages","idleMs":1200,"timeout":45000,"description":"Wait for the other AI's reply to settle"}
Optional: idleMs (quiet period required to count as "done", default 900ms — use 1200-1500ms for chat apps that pause briefly mid-sentence), timeout (max total wait, default 30000ms — use 45000-60000ms for a model that may think for a while), minWait (grace period before measuring starts, default 500ms). Returns success even on timeout — it also sets timedOut:true so you know the wait ran out and should treat the content you see as possibly still in progress rather than final.

### hover — move the purple cursor over an element and trigger mouseover
The purple cursor animates to the element's position. Triggers pointerover, mouseover, pointermove, mousemove events.
{"type":"hover","selector":".tooltip-trigger","text":"More info","description":"Hover to see tooltip"}
{"type":"hover","selector":"#menu-item","description":"Hover to open dropdown"}
{"type":"hover","x":300,"y":200,"description":"Hover at coordinates"}
Holds for 600ms so hover effects/tooltips appear.

### press_key — simulate a keyboard key press
Sends keydown → keypress → keyup on the focused element or document.
{"type":"press_key","key":"Enter","description":"Press Enter"}
{"type":"press_key","key":"Tab","description":"Tab to next field"}
{"type":"press_key","key":"Escape","description":"Close modal with Escape"}
{"type":"press_key","key":"ArrowDown","description":"Arrow down in dropdown"}
{"type":"press_key","key":"a","ctrl":true,"description":"Ctrl+A select all"}
{"type":"press_key","key":"c","ctrl":true,"description":"Ctrl+C copy"}
{"type":"press_key","key":"v","ctrl":true,"description":"Ctrl+V paste"}
{"type":"press_key","key":"Delete","description":"Delete selected"}
{"type":"press_key","key":"Home","description":"Go to beginning"}
{"type":"press_key","key":"End","description":"Go to end"}
Optional: ctrl, shift, alt, meta as boolean modifiers.

### dblclick — double-click an element
Use for things that require a double-click: spreadsheet cells, file/icon grids, text selection.
{"type":"dblclick","selector":".cell-3-2","text":"Edit","description":"Double-click cell to edit"}

### right_click — right-click an element to open a context menu
{"type":"right_click","selector":"#file-item","description":"Open context menu on file"}

### drag — drag an element from its current position to a target (sliders, range inputs, reorderable lists, drag handles)
Provide EITHER a target selector/text OR explicit offsetX/offsetY pixels to drag by.
{"type":"drag","selector":"input[type='range']","offsetX":80,"description":"Drag slider right by 80px"}
{"type":"drag","selector":".drag-handle","targetSelector":"#drop-zone","description":"Drag item into drop zone"}

### get_page_info — get URL, title, page text, and all interactive elements
{"type":"get_page_info","description":"Get full page info"}
Returns title, url, text (first 15000 chars), and all interactive elements.

### navigate — go to a different URL (handled at sidepanel level)
{"type":"navigate","url":"https://example.com","description":"Go to example.com"}

### undo — undo the last action
Reverts the last click/fill/check/select. Each action is automatically tracked.
{"type":"undo","description":"Undo last action"}

## RICH TEXT & WEB-COMPONENT SUPPORT
- The fill action works on contenteditable elements (rich text editors, chat boxes, Notion-style docs), not just <input>/<textarea>.
- The click and fill finders pierce open shadow DOM, so custom elements / design-system components (e.g. <my-button>, Shoelace, Lit, Stencil) are reachable the same way as plain HTML.

## SURVEY HANDLING — ALL QUESTION TYPES
- Radio (MCQ): {"type":"click","selector":"#QID2-1","text":"Option","description":"Q2 select"}
- Checkbox (multi): {"type":"check","selector":"#QID3_1","text":"Option","description":"Q3 check"}
- Matrix/Grid: {"type":"click","selector":"#QID4_1-5","text":"Agree","description":"Q4 Row1"}
- Dropdown: {"type":"select","selector":"#QID5","value":"Option","description":"Q5 choose"}
- Essay/Textarea: {"type":"fill","selector":"textarea[name='Q6']","value":"Answer","description":"Q6 essay"}
- Short answer: {"type":"fill","selector":"input[name='Q7']","value":"Answer","description":"Q7 short"}
- Likert scale: {"type":"click","selector":"#QID8-5","text":"5 - Very","description":"Q8 rate"}
- Ranking: {"type":"click","selector":"#QID9_1","text":"Rank 1","description":"Q9 rank"}
- Next/Submit: {"type":"click","selector":"#NextButton","text":"Next","description":"Next page"}
- Open-ended: {"type":"fill","selector":"textarea[name='Q10']","value":"Feedback","description":"Q10 open"}
- Numeric: {"type":"fill","selector":"input[name='Q11']","value":"42","description":"Q11 number"}
- Date/Time: {"type":"fill","selector":"input[name='Q12']","value":"2025-01-15","description":"Q12 date"}
- File upload: SKIP — note "Requires manual file upload"
Answer ALL visible questions per page, then click Next. Batch the whole page.

## ASSIGNMENT HANDLING — ALL QUESTION TYPES
- Essay: fill textarea with complete answer (long text pasted instantly)
- Multiple choice: click radio
- True/False: click radio {"type":"click","text":"True","description":"Q select True"}
- Fill-in-blank: {"type":"fill","selector":"input","value":"answer","description":"Fill blank"}
- Matching: {"type":"select","selector":"select[name='match1']","value":"Answer B","description":"Match 1"}
- Short answer: fill input
- Code: fill textarea with code (pasted instantly since >80 chars)
- Math: fill input with equation like "x = 5"
- Ordering: click each item in correct order, or use select
- Upload: SKIP — note "Requires manual upload"

## TALKING TO ANOTHER AI / CHAT INTERFACE
When the task is to communicate with an AI chatbot (Claude, ChatGPT, Gemini, or any chat UI) — not just send one message, but carry the conversation until the actual goal is met:
1. Type your message into the composer (fill/type action), then click Send/Submit/Ask (or press_key Enter if that's how the UI sends).
2. Immediately after, run {"type":"wait_for_idle", ...} — do NOT screenshot right away. The reply streams in over a few seconds; screenshotting too early captures a half-written answer.
3. THEN screenshot and/or {"type":"extract"} the reply region to read the full response text (screenshots can cut off long replies — extract gets the complete text).
4. Compare what the other AI actually said against the real goal, word for word. Sending a message is not the goal — a reply that genuinely addresses the request is.
5. If the reply is missing, generic, still loading, cut off, or doesn't address what was asked: compose ONE precise, specific follow-up (name exactly what's missing or wrong) and send it — do not repeat the same message, and do not send a vague "please continue" unless the reply was visibly cut off mid-sentence.
6. Repeat steps 1-5, treating each round as real progress toward the goal, until the other AI's reply genuinely satisfies what was asked, or you hit a real blocker (it refuses, asks a question only the person can answer, or you've tried multiple distinct angles with no progress) — in which case stop and report NEEDS_USER with what you learned so far.
7. Never declare a conversation task VERIFIED_COMPLETE just because a message was sent — completion means the other AI's final reply actually accomplishes the goal.

## BULK / "ALL" TASKS — DON'T STOP AT ONE
Requests are very often plural even when phrased casually — "delete the spam", "clear my notifications", "unsubscribe from these", "reject the pending requests", "clean up my inbox", "remove the duplicates". None of these mean "handle one instance and stop." Treat a request as bulk (repeat until nothing matching is left) whenever ANY of these are true:
- It names a CATEGORY rather than one specific item ("spam", "unread", "old messages", "notifications", "duplicates", "pending invites") — a category can contain zero, one, or a hundred items, and you don't know which until you look.
- It uses "all"/"every"/"each"/"any"/"these"/"my [plural noun]" — plural intent, not singular.
- It's a "clean up" / "clear out" / "get rid of" style request — these mean fully clear the category, not make a dent in it.
If genuinely uncertain whether something is a one-off ("delete that email from John") vs. a category (delete "spam"), the presence of a specific singular identifier (a name, subject line, specific item) means ONE; a category/type name with no specific identifier means ALL of them.

WORKFLOW for bulk tasks:
1. Look for a bulk mechanism FIRST — a "Select all" checkbox, a folder-level action (e.g. Gmail's Spam folder has "Empty Spam now"), a filter + bulk-delete button. These clear everything in one action and are always better than one-by-one when available.
2. If no bulk mechanism exists, loop: act on the first matching item, screenshot/re-scan, check if the category is now empty or the list shrank, and repeat — don't stop after the first success.
3. Before declaring done, confirm the category is actually EMPTY (a "No spam messages" / "You're all caught up" state, or the list/count is visibly zero) or that you've explicitly identified everything that qualified and handled all of it. "I deleted one" is not a valid finish for a plural request — that's a partial result and should be reported/continued as INCOMPLETE, not VERIFIED_COMPLETE.
4. If the category is large enough that individual items scroll off-screen, treat this like the SCROLLING & READING rules above — you have to actually see the whole list (or use extract/get_page_info to read it) before you can claim you got everything.

## PAGE TYPE STRATEGIES
- survey: answer all question types, batch per page, Next to advance
- login: fill username/email, fill password, click login/sign-in
- checkout: fill shipping, fill billing, select payment, review, place order
- search-results: read results, click links, extract data
- form-filling: fill all visible fields, submit
- ecommerce: browse products, add to cart, checkout
- settings: toggle switches, select options, save/apply
- registration: fill required(*), accept terms, submit
- dashboard: read data, click menu items, navigate sections
- article: read content, scroll through, click related links
- content-page: scroll and read, click navigation links
- navigation: click menu items to explore
- ai-chat: type message, send, wait_for_idle, read the reply, judge it against the goal, repeat if needed (see TALKING TO ANOTHER AI section above)

## SCROLLING & READING THE WHOLE PAGE
Every screenshot you're shown is tagged with a [scroll: X% down...] note. Read it every time:
- If it says content is still below, and your task involves reading, answering every question, following a conversation, or verifying something is complete — you are NOT done looking. Scroll further and screenshot again before you conclude anything.
- Don't jump straight to the bottom of a long page you need to actually read (articles, multi-question assignments, long chat replies) — scroll incrementally (e.g. {"type":"scroll","y":500...}) so you don't skip content between jumps, unless the page is short enough that toBottom in one move is safe.
- {"type":"scroll","toBottom":true} is fine when you just need to reach something at the bottom (a Submit button, a footer link) and don't need to read what's in between.
- For pure text-reading (an article, a long reply, terms of service) prefer {"type":"extract"} or {"type":"get_page_info"} over scrolling+screenshotting — they return the full text regardless of scroll position, so you can't miss anything and don't burn steps scrolling. Use scroll+screenshot when you also need to SEE and interact with something below the fold (a button, an image, a checkbox).
- Before marking any multi-question or multi-section page "done," check that you've actually reached [scroll: 100% — at the bottom] or used extract to confirm there's nothing left, not just that the top of the page looked fine.

## OTHER RULES
- Start every task with one screenshot (and optionally analyze) to see the page
- After every page navigation, take a screenshot
- Watch for open modals/dialogs — close them before continuing
- For long pages, scroll before filling or clicking out-of-view elements
- After task completion, verify with one final screenshot
- You will be asked to double-check your own work after steps finish — when that happens, judge completion from what's actually visible on the page, not from the fact that steps ran without errors, and answer honestly even if it means saying the task isn't done yet
- The 130+ strategy engine never gives up — it tries everything
- You can now use the "undo" action type to revert any step`;

let apiKey = '';
let model = 'openrouter/auto';
let conversationHistory = [];
let pendingScreenshot = null;
let activeTask = null;
let stopRequested = false;
let abortController = null;
let autoScreenshot = true;
let stepScreenshots = true;
let fastMode = false;
let autoConfirmSensitive = false;
let targetTabId = null;
let targetTabTitle = '';
let targetTabFavicon = '';
let consecutiveErrors = 0;
const verificationRounds = {};   // taskId -> number of double-check rounds run so far
const verificationContext = {};  // taskId -> { plan, steps, completed } so a banner's Retry button can re-run the check
const verificationReasonHistory = {}; // taskId -> last round's TASK_REASON, used to detect "stuck" loops
const verificationRoundCaps = {}; // taskId -> the round cap chosen for this specific task
const DEFAULT_MAX_VERIFICATION_ROUNDS = 6; // generous ceiling for ordinary tasks (a form, a single page)
const EXTENDED_MAX_VERIFICATION_ROUNDS = 20; // higher ceiling for tasks that are inherently multi-round by nature

// Some tasks are legitimately not "done" after one or two double-checks — an
// iterative back-and-forth with another AI, or a multi-page/multi-question
// assignment, can need many more rounds than a single form. Detect those from
// the task's own title/goal text and give them real room to keep working,
// while ordinary single-page tasks stay fast at the default cap.
const EXTENDED_ROUND_GOAL_PATTERNS = /talk(ing)? to (another|the) ai|communicate with|keep (talking|going|iterating)|until (it'?s|it is|everything is) (done|ready|finished|complete)|every question|all questions|multi[- ]?page|iterat(e|ive|ing)|back and forth|no bugs|until (the )?app is ready|build (the|an|a) app|fix (all )?bugs|delete (all|the) |clear (out|all)|clean up|remove (all|the) |empty (the |my )?(spam|trash|inbox)|unsubscribe from|all (of )?(my|the) (spam|emails|messages|notifications)/i;

function getRoundCapFor(plan) {
  const goalText = (plan?.title || '') + ' ' + (plan?.steps || []).map(s => s.description || '').join(' ');
  return EXTENDED_ROUND_GOAL_PATTERNS.test(goalText) ? EXTENDED_MAX_VERIFICATION_ROUNDS : DEFAULT_MAX_VERIFICATION_ROUNDS;
}

// V4: User Intent Prediction & Tracking
const userPatterns = {
  fieldChoices: {},    // field name -> { value: count }
  workflowSteps: [],   // [ { intent, action, timestamp } ]
  commonWorkflows: {}, // workflow pattern -> count
  preferences: {       // learned preferences
    preferredEmail: '',
    preferredModel: '',
    autoConfirm: false,
    fastMode: false
  }
};

function trackUserAction(step, result) {
  const key = `${step.type}:${step.description || step.selector || ''}`;
  const value = step.value || step.text || step.selector || '';
  
  if (!userPatterns.fieldChoices[key]) userPatterns.fieldChoices[key] = {};
  if (value) {
    userPatterns.fieldChoices[key][value] = (userPatterns.fieldChoices[key][value] || 0) + 1;
  }
  
  userPatterns.workflowSteps.push({
    intent: step.description || step.type,
    action: key,
    value: value,
    timestamp: Date.now(),
    success: result?.success
  });
  
  // Keep last 200 steps
  if (userPatterns.workflowSteps.length > 200) userPatterns.workflowSteps.shift();
}

function getLearnedPreference(intent) {
  const choices = userPatterns.fieldChoices[intent];
  if (!choices) return null;
  
  // Return the most frequent choice
  const entries = Object.entries(choices);
  entries.sort((a, b) => b[1] - a[1]);
  return entries[0][0];
}

function suggestNextSteps(currentPageType) {
  // Analyze past workflows for similar page types
  const relevant = userPatterns.workflowSteps.filter(s => 
    s.intent && s.intent.toLowerCase().includes(currentPageType?.toLowerCase() || '')
  );
  
  if (relevant.length < 3) return null;
  
  // Find most common sequences
  const sequences = {};
  for (let i = 0; i < relevant.length - 1; i++) {
    const seq = `${relevant[i].action} → ${relevant[i+1].action}`;
    sequences[seq] = (sequences[seq] || 0) + 1;
  }
  
  const sorted = Object.entries(sequences).sort((a, b) => b[1] - a[1]);
  return sorted.slice(0, 3).map(([seq]) => seq);
}

// V4: Undo state
let lastExecutedStep = null;
let lastExecutedTaskId = null;

const messagesEl = document.getElementById('messages');
const chatInput = document.getElementById('chatInput');
const sendBtn = document.getElementById('sendBtn');
const stopInputBtn = document.getElementById('stopInputBtn');
const welcomeEl = document.getElementById('welcome');
const typingIndicator = document.getElementById('typingIndicator');
const typingText = document.getElementById('typingText');
const screenshotBar = document.getElementById('screenshotBar');
const screenshotPreview = document.getElementById('screenshotPreview');
const noKeyNotice = document.getElementById('noKeyNotice');
const modeBadge = document.getElementById('modeBadge');
const tabPicker = document.getElementById('tabPicker');
const tabPickerList = document.getElementById('tabPickerList');
const tabPickerSearch = document.getElementById('tabPickerSearch');
const tabBadge = document.getElementById('tabBadge');
const tabBadgeFavicon = document.getElementById('tabBadgeFavicon');
const tabBadgeTitle = document.getElementById('tabBadgeTitle');
const tabBadgeClear = document.getElementById('tabBadgeClear');

async function init() {
  const stored = await chrome.storage.local.get(['apiKey','autoScreenshot','stepScreenshots','fastMode','autoConfirmSensitive']);
  apiKey = stored.apiKey || '';
  autoScreenshot = stored.autoScreenshot !== false;
  stepScreenshots = stored.stepScreenshots !== false;
  fastMode = stored.fastMode === true;
  autoConfirmSensitive = stored.autoConfirmSensitive === true;
  if (!apiKey) noKeyNotice.style.display = 'block';
  setupEventListeners();
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.apiKey) { apiKey = changes.apiKey.newValue || ''; noKeyNotice.style.display = apiKey ? 'none' : 'block'; }
  if (changes.autoScreenshot) autoScreenshot = changes.autoScreenshot.newValue !== false;
  if (changes.stepScreenshots) stepScreenshots = changes.stepScreenshots.newValue !== false;
  if (changes.fastMode) fastMode = changes.fastMode.newValue === true;
  if (changes.autoConfirmSensitive) autoConfirmSensitive = changes.autoConfirmSensitive.newValue === true;
});

function setupEventListeners() {
  sendBtn.addEventListener('click', handleSend);
  chatInput.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }});
  chatInput.addEventListener('input', () => {
    chatInput.style.height = 'auto';
    chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
    sendBtn.disabled = chatInput.value.trim() === '';
  });
  document.querySelectorAll('.quick-chip').forEach(c => c.addEventListener('click', () => {
    chatInput.value = c.dataset.prompt;
    chatInput.dispatchEvent(new Event('input'));
    handleSend();
  }));
  document.getElementById('screenshotBtn').addEventListener('click', captureAndAttach);
  document.getElementById('attachScreenBtn').addEventListener('click', captureAndAttach);
  document.getElementById('removeScreenshot').addEventListener('click', () => {
    pendingScreenshot = null; screenshotBar.style.display = 'none';
    document.getElementById('attachScreenBtn').classList.remove('active');
  });
  document.getElementById('clearBtn').addEventListener('click', clearConversation);
  document.getElementById('themeToggleBtn').addEventListener('click', toggleTheme);
  chatInput.addEventListener('input', handleAtMention);
  chatInput.addEventListener('keydown', e => {
    if (tabPicker.style.display === 'none') return;
    const items = tabPickerList.querySelectorAll('.tab-picker-item');
    const sel = tabPickerList.querySelector('.tab-picker-item.selected');
    let idx = [...items].indexOf(sel);
    if (e.key === 'ArrowDown') { e.preventDefault(); selectPickerItem(items, Math.min(idx+1, items.length-1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); selectPickerItem(items, Math.max(idx-1, 0)); }
    else if (e.key === 'Enter' && sel) { e.preventDefault(); sel.click(); }
    else if (e.key === 'Escape') { closeTabPicker(); }
  });
  tabPickerSearch.addEventListener('input', () => renderTabPickerItems(tabPickerSearch.value));
  stopInputBtn.addEventListener('click', () => {
    if (abortController) { abortController.abort(); abortController = null; }
    stopRequested = true; activeTask = null; hideTyping();
  });
  tabBadgeClear.addEventListener('click', () => {
    targetTabId = null; targetTabTitle = ''; targetTabFavicon = '';
    tabBadge.style.display = 'none';
  });
  document.addEventListener('click', e => {
    if (!tabPicker.contains(e.target) && e.target !== chatInput) closeTabPicker();
  });
}

let _allTabs = [];

function handleAtMention(e) {
  const val = chatInput.value;
  const cursor = chatInput.selectionStart;
  const before = val.slice(0, cursor);
  const atIdx = before.lastIndexOf('@');
  if (atIdx !== -1 && !before.slice(atIdx + 1).includes(' ')) openTabPicker(before.slice(atIdx + 1));
  else closeTabPicker();
}

function openTabPicker(query) {
  chrome.runtime.sendMessage({ type: 'LIST_TABS' }, res => {
    if (!res?.tabs) return;
    _allTabs = res.tabs.filter(t => t.url && !t.url.startsWith('chrome://') && !t.url.startsWith('chrome-extension://'));
    tabPickerSearch.value = query;
    renderTabPickerItems(query);
    tabPicker.style.display = 'flex';
    tabPickerSearch.focus();
  });
}

function renderTabPickerItems(query) {
  const q = (query||'').toLowerCase();
  const filtered = _allTabs.filter(t => !q || t.title?.toLowerCase().includes(q) || t.url?.toLowerCase().includes(q)).slice(0, 10);
  tabPickerList.innerHTML = filtered.length ? '' : '<div style="padding:12px;font-size:12px;color:var(--text-3);text-align:center">No tabs found</div>';
  filtered.forEach((tab, i) => {
    const item = document.createElement('div');
    item.className = 'tab-picker-item' + (i === 0 ? ' selected' : '');
    const domain = (() => { try { return new URL(tab.url).hostname.replace('www.', ''); } catch(_) { return tab.url; }})();
    item.innerHTML = `<div class="tab-picker-favicon-wrap">${tab.favIconUrl ? `<img src="${tab.favIconUrl}" width="16" height="16" onerror="this.parentElement.innerHTML='<div class=tab-favicon-placeholder></div>'">` : '<div class="tab-favicon-placeholder"></div>'}</div><div class="tab-picker-item-text"><div class="tab-picker-item-title">${escapeHtml(tab.title||'Untitled')}</div><div class="tab-picker-item-url">${escapeHtml(domain)}</div></div>`;
    item.addEventListener('click', () => pickTab(tab));
    tabPickerList.appendChild(item);
  });
}

function selectPickerItem(items, idx) {
  items.forEach((el, i) => el.classList.toggle('selected', i === idx));
}

function pickTab(tab) {
  targetTabId = tab.id; targetTabTitle = tab.title || tab.url; targetTabFavicon = tab.favIconUrl || '';
  const val = chatInput.value;
  const cursor = chatInput.selectionStart;
  const before = val.slice(0, cursor);
  const atIdx = before.lastIndexOf('@');
  if (atIdx !== -1) {
    chatInput.value = val.slice(0, atIdx) + val.slice(cursor);
    chatInput.selectionStart = chatInput.selectionEnd = atIdx;
  }
  tabBadgeTitle.textContent = targetTabTitle.length > 40 ? targetTabTitle.slice(0,40) + '…' : targetTabTitle;
  tabBadgeFavicon.src = targetTabFavicon; tabBadgeFavicon.style.display = targetTabFavicon ? '' : 'none';
  tabBadge.style.display = 'flex'; closeTabPicker(); chatInput.focus();
}

function closeTabPicker() { tabPicker.style.display = 'none'; }

async function captureCurrentTab() {
  try {
    const res = await new Promise(resolve => chrome.runtime.sendMessage({ type: 'CAPTURE_SCREENSHOT', tabId: targetTabId }, resolve));
    if (res?.screenshot) return res.screenshot;
    return null;
  } catch(_) { return null; }
}

async function getEnhancedPageContext() {
  try {
    const tabInfo = await new Promise(resolve => chrome.runtime.sendMessage({ type: 'GET_TAB_INFO', tabId: targetTabId }, resolve));
    if (!tabInfo?.url || tabInfo.url.startsWith('chrome://')) return null;

    const enhanced = await new Promise(resolve => chrome.runtime.sendMessage({ type: 'GET_ENHANCED_CONTENT', tabId: targetTabId }, resolve));
    if (!enhanced) return null;

    let ctx = `[URL]: ${tabInfo.url}\n[Title]: ${enhanced.title || ''}\n`;

    if (enhanced.pageType) {
      const pt = enhanced.pageType;
      ctx += `[Page Type]: ${pt.primary}${pt.secondary?.length ? ' ('+pt.secondary.join(', ')+')' : ''}\n`;
    }

    if (enhanced.state) {
      const s = enhanced.state;
      ctx += `[Viewport]: ${s.viewport.width}x${s.viewport.height}, scrolled ${s.percentScrolled}%${s.atBottom ? ' (at bottom)' : ''}\n`;
    }

    if (enhanced.structure?.modals?.length > 0) {
      ctx += `[Open Modals/Dialogs]:\n`;
      enhanced.structure.modals.forEach(m => {
        const btns = m.buttons || [];
        const btnText = typeof btns[0] === 'string' ? btns.join(', ') : btns.map(b => b.text||b.id).filter(Boolean).join(', ');
        ctx += `  ${m.tag} "${m.heading||'no heading'}" buttons: ${btnText||'none'}\n`;
      });
    }

    if (enhanced.analysis?.headings?.length > 0) {
      ctx += `[Page Headings]:\n`;
      enhanced.analysis.headings.forEach(h => {
        ctx += `  ${h.level}: "${h.text}"\n`;
      });
    }

    if (enhanced.structure?.nav) {
      ctx += `[Navigation]: ${enhanced.structure.nav.items?.length||0} items\n`;
    }

    if (enhanced.structure?.sections?.length > 0) {
      ctx += `[Sections]: ${enhanced.structure.sections.length}\n`;
      enhanced.structure.sections.slice(0, 5).forEach(s => {
        ctx += `  ${s.tag} "${s.headings?.[0]?.text||'?'}" (${s.elementCounts.buttons} btns, ${s.elementCounts.inputs} inputs)\n`;
      });
    }

    if (enhanced.forms?.length > 0) {
      ctx += `[Forms Detail]:\n`;
      enhanced.forms.forEach(f => {
        ctx += `  Form${f.id?' #'+f.id:''} method=${f.method} ${f.fields.length} fields, ${f.submitButtons.length} submit buttons\n`;
        f.fields.forEach(field => {
          if (field.type === 'fieldset') {
            ctx += `    Fieldset "${field.legend||''}": ${field.fields.length} fields\n`;
            field.fields.forEach(sf => {
              ctx += `      ${sf.type} name="${sf.name}" label="${sf.label||sf.ariaLabel||''}" ${sf.required?'*required':''}\n`;
            });
          } else {
            ctx += `    ${field.type} name="${field.name}" label="${field.label||field.ariaLabel||''}" ${field.required?'*required':''} placeholder="${field.placeholder||''}"\n`;
          }
        });
        f.submitButtons.forEach(b => {
          ctx += `    Submit: "${b.text}"${b.id?' #'+b.id:''}\n`;
        });
      });
    }

    if (enhanced.interactiveElements?.length > 0) {
      const buttons = enhanced.interactiveElements.filter(e =>
        ['BUTTON','A','INPUT'].includes(e.tag) || ['button','link'].includes(e.role)
      ).filter(e => e.text||e.ariaLabel).slice(0, 50);
      const inputs = enhanced.interactiveElements.filter(e =>
        ['INPUT','SELECT','TEXTAREA'].includes(e.tag) || ['combobox','listbox'].includes(e.role)
      ).slice(0, 30);
      const checkables = enhanced.interactiveElements.filter(e =>
        ['checkbox','radio'].includes(e.type) || ['checkbox','radio','switch'].includes(e.role)
      ).slice(0, 30);

      if (buttons.length) {
        ctx += `[Buttons/Links] (visible ${buttons.filter(b=>b.visible).length}/${buttons.length}):\n`;
        buttons.forEach(b => {
          const flags = [];
          if (!b.visible) flags.push('hidden');
          if (b.disabled) flags.push('disabled');
          ctx += `  ${b.tag}${b.id?'#'+b.id:''} "${b.text||b.ariaLabel}" rect:${b.rect}${flags.length?' ['+flags.join(',')+']':''}\n`;
        });
      }
      if (inputs.length) {
        ctx += `[Inputs] (visible ${inputs.filter(i=>i.visible).length}/${inputs.length}):\n`;
        inputs.forEach(i => {
          ctx += `  ${i.tag} name="${i.name}" type="${i.type}" label="${i.label||i.ariaLabel||i.placeholder}" ${i.visible?'':'⚠️hidden'}${i.disabled?' 🚫disabled':''}\n`;
        });
      }
      if (checkables.length) {
        ctx += `[Checkboxes/Radios/Switches] (visible ${checkables.filter(c=>c.visible).length}/${checkables.length}):\n`;
        checkables.forEach(c => {
          ctx += `  ${c.tag}${c.id?'#'+c.id:''} "${c.text||c.ariaLabel||c.label}" type=${c.type} ${c.checked?'✓checked':'○unchecked'} section:"${c.section}"\n`;
        });
      }

      const inViewport = enhanced.interactiveElements.filter(e => e.inViewport).length;
      ctx += `\n[Element Summary]: ${enhanced.interactiveElements.length} total interactive elements (${inViewport} in viewport)`;
    }

    return ctx;
  } catch(_) { return null; }
}

// Cheap scroll-position check (no full page re-analysis) so every screenshot
// caption can tell the model whether it's actually seeing everything or whether
// there's more content below that it needs to scroll down to read.
async function getScrollCaption() {
  try {
    const res = await new Promise(resolve => chrome.runtime.sendMessage({ type: 'GET_VIEWPORT_STATE', tabId: targetTabId }, resolve));
    const s = res?.state;
    if (!s || typeof s.percentScrolled !== 'number') return '';
    if (s.atBottom) return ' [scroll: 100% — at the bottom of the page, nothing more below]';
    return ` [scroll: ${s.percentScrolled}% down the page — MORE CONTENT IS BELOW; if you're reading, answering every question, or verifying completeness, scroll down further before concluding you've seen it all]`;
  } catch(_) { return ''; }
}

// Scroll the target tab to a specific Y position and wait
async function scrollTabTo(y) {
  await new Promise(resolve => chrome.runtime.sendMessage({
    type: 'DOM_ACTION', tabId: targetTabId,
    action: { type: 'scroll', y: y, _absolute: true }
  }, resolve));
  await new Promise(r => setTimeout(r, 3000)); // wait 3 sec for page to settle
}

// Silently scan the full page: scroll top→bottom→top, capture screenshots every viewport height
async function scanFullPage() {
  // Get page dimensions
  const tabInfo = await new Promise(resolve => chrome.runtime.sendMessage({ type: 'GET_TAB_INFO', tabId: targetTabId }, resolve));
  if (!tabInfo?.url || tabInfo.url.startsWith('chrome://')) return [];

  const state = await new Promise(resolve => chrome.runtime.sendMessage({ type: 'GET_ENHANCED_CONTENT', tabId: targetTabId }, resolve));
  const viewportH = state?.state?.viewport?.height || 800;
  const pageH = state?.state?.scrollHeight || viewportH;
  const originalScroll = state?.state?.scrollY || 0;

  const snapshots = [];
  const steps = Math.min(Math.ceil(pageH / viewportH), 8); // cap at 8 positions

  // Scroll to top first
  await new Promise(resolve => chrome.runtime.sendMessage({
    type: 'DOM_ACTION', tabId: targetTabId,
    action: { type: 'scroll', toTop: true }
  }, resolve));
  await new Promise(r => setTimeout(r, 800));

  // Scan down
  for (let i = 0; i < steps; i++) {
    const shot = await captureCurrentTab();
    if (shot) snapshots.push({ position: i + 1, total: steps, dataUrl: shot });
    if (i < steps - 1) {
      await new Promise(resolve => chrome.runtime.sendMessage({
        type: 'DOM_ACTION', tabId: targetTabId,
        action: { type: 'scroll', y: viewportH * 0.85 }
      }, resolve));
      await new Promise(r => setTimeout(r, 1500)); // 1.5s — enough for static pages
    }
  }

  // Scroll back to top
  await new Promise(resolve => chrome.runtime.sendMessage({
    type: 'DOM_ACTION', tabId: targetTabId,
    action: { type: 'scroll', toTop: true }
  }, resolve));
  await new Promise(r => setTimeout(r, 500));

  return snapshots;
}

async function handleSend() {
  const text = chatInput.value.trim();
  if (!text) return;
  if (!apiKey) { noKeyNotice.style.display = 'block'; return; }

  chatInput.value = ''; chatInput.style.height = 'auto'; sendBtn.disabled = true;
  hideWelcome();

  // Show user message immediately (no screenshot attached — it's scanned silently below)
  addUserMessage(text, null);
  pendingScreenshot = null;
  screenshotBar.style.display = 'none';
  document.getElementById('attachScreenBtn').classList.remove('active');

  consecutiveErrors = 0;

  // ── Full page scan (silent — no screenshot shown to user) ────────────────────
  showTyping('Scanning page…');
  let pageSnapshots = [];
  try {
    pageSnapshots = await scanFullPage();
  } catch(_) {}

  const pageContext = await getEnhancedPageContext();

  // Build userContent with ALL scan screenshots for the AI
  let userContent;
  if (pageSnapshots.length > 0) {
    const parts = [];
    for (const snap of pageSnapshots) {
      parts.push({ type: 'image_url', image_url: { url: snap.dataUrl } });
      parts.push({ type: 'text', text: `[Page scan ${snap.position}/${snap.total} — scroll position ${Math.round((snap.position-1)/snap.total*100)}% down the page]` });
    }
    parts.push({ type: 'text', text: `[User request]: ${text}\n\n${pageContext || ''}` });
    userContent = parts;
  } else {
    userContent = pageContext ? `${text}\n\n${pageContext}` : text;
  }

  conversationHistory.push({ role: 'user', content: userContent });

  // ── Phase 1: Think ───────────────────────────────────────────────────────────
  showTyping('Understanding your request…');
  let thinkingText = '';
  try {
    const thinkingMessages = [
      {
        role: 'system',
        content: `You are Viora, a browser automation AI that automates browsers. You never refuse tasks.

You have been given a full page scan — multiple screenshots taken top to bottom. Study EVERY screenshot carefully before writing anything.

Your job is to do a DEEP PAGE ANALYSIS in two passes: first draft, then self-review. Write your findings like this:

TASK SCOPE: [does the request target ONE specific, named item, or a CATEGORY/ALL matching items (plural noun, "all", "every", "these", a type/category name like "spam" or "unread" with no specific identifier)? If it's a category, count how many matching items are actually visible right now, and note whether a bulk-select/bulk-action control exists (e.g. "Select all", a folder-level clear action) versus needing one-by-one handling.]

PAGE GOAL: [what the page is asking for / what kind of page this is]

QUESTIONS/FIELDS FOUND:
- Q1: [exact question label as written on page] → Options: [list every visible option exactly as written] → I will pick: [specific choice and why]
- Q2: [exact question label] → Options: [list all] → I will pick: [specific choice]
(continue for every question/field visible, including ones that look optional — note which are marked required with * or "required")

NAVIGATION: [what button to click to proceed — exact label]

SELF-REVIEW (do this before finalizing — catch your own mistakes here):
- Did I miss any visible field, checkbox, or required (*) item? Re-scan the screenshots once more specifically for this.
- Did I misread any label, or guess at text I couldn't actually see clearly? If so, flag it and pick the safest literal reading instead of guessing.
- Are any of my chosen answers ambiguous, contradictory, or inconsistent with each other (e.g. answering a later question in a way that conflicts with an earlier one)?
- Is there a more specific/sensible option I overlooked in favor of a generic one?
- If TASK SCOPE above is a category/"all" request: does my plan actually clear ALL of them (bulk action, or a loop that repeats until none remain), or does it only handle the first one I see? A plan that stops after one match is wrong for a plural request.
- Is this a multi-page flow? If so, what should I expect to see next, and how will I recognize whether the click actually advanced the page?
- What is the single most likely way this plan fails (wrong selector, hidden field, validation rule, modal/popup blocking the page)? Plan around it.
- Did I hedge anywhere with "if you want X, do A; otherwise do B"? A plan with branches isn't a plan — pick the single most likely correct interpretation of the user's request and commit to it. Branching is only acceptable inside MY PLAN itself if it's something the engine will resolve automatically based on what's actually on screen (e.g. "if a cookie banner is showing, close it first") — never as a way to avoid deciding what the user meant.

MY PLAN: [numbered steps in order, revised if the self-review above caught anything. One committed plan — no "if your goal is X" branches.]

RULES:
- Read and quote labels EXACTLY as they appear — do not paraphrase
- Never pick "Other" or unusual options unless they are the only sensible fit
- For gender: pick the most common/neutral option visible
- For dropdowns: list the actual options you can read from the page
- No JSON, no code — plain text analysis only`
      },
      {
        role: 'user',
        content: Array.isArray(userContent)
          ? userContent  // already has all scan screenshots + text
          : (typeof userContent === 'string' ? userContent : '')
      }
    ];
    thinkingText = await callAI(thinkingMessages, true);
    hideTyping();
    if (thinkingText && thinkingText.trim()) {
      addThinkingBubble(thinkingText.trim());
    }
  } catch (err) {
    hideTyping();
    if (err.name === 'AbortError') return;
    // thinking failed — fall through to act anyway
  }

  // ── Phase 2: Act ─────────────────────────────────────────────────────────────
  showTyping('Planning actions…');

  // Inject thinking as silent context into the action call
  const actionHistory = [...conversationHistory];
  if (thinkingText && thinkingText.trim()) {
    const last = actionHistory[actionHistory.length - 1];
    const planNote = `\n\n[My deep page analysis and plan]:\n${thinkingText.trim()}\n\nNow execute this plan precisely. Rules:\n- Use the EXACT option text from My plan above for every click/select/fill\n- For IDs with special characters (~, ., etc) use text-based matching instead: {"type":"click","text":"Exact label text"}\n- Batch ALL steps on this page together\n- Only screenshot after navigating to a new page\n- NEVER refuse — produce the action_plan now.`;
    if (Array.isArray(last.content)) {
      const textBlock = last.content.find(b => b.type === 'text');
      if (textBlock) {
        actionHistory[actionHistory.length - 1] = {
          ...last,
          content: last.content.map(b => b.type === 'text' ? { ...b, text: b.text + planNote } : b)
        };
      }
    } else {
      actionHistory[actionHistory.length - 1] = { ...last, content: (last.content || '') + planNote };
    }
  }

  try {
    const response = await callAI(actionHistory);
    hideTyping();
    const { plan, visibleText } = extractActionPlan(response);
    if (plan) {
      conversationHistory.push({ role: 'assistant', content: response });
      if (visibleText) addAssistantMessage(visibleText);
      renderTaskCard(plan);
      setBadge('actions');
      const taskId = document.querySelector('.task-card:last-child')?.id;
      if (taskId) setTimeout(() => startTask(taskId, plan), 150);
      return;
    }
    conversationHistory.push({ role: 'assistant', content: response });
    addAssistantMessage(response);
    setBadge('chat');
  } catch (err) {
    hideTyping();
    if (err.name === 'AbortError') return;
    addAssistantMessage(`⚠️ ${err.message}\n\nCheck your API key.`);
  }
}

async function callAI(history, rawMessages = false) {
  abortController = new AbortController();

  let messages;
  if (rawMessages) {
    // Thinking phase: caller provides their own system prompt
    messages = history;
  } else {
    const settingsContext = `[Current V4 Settings]\n- Fast Mode: ${fastMode ? 'ON (minimal delays)' : 'OFF (balanced speed/reliability)'}\n- Auto Confirm Sensitive: ${autoConfirmSensitive ? 'ON' : 'OFF (will ask you)'}\n- Auto Screenshot: ${autoScreenshot ? 'ON' : 'OFF'}\n- Step Screenshots: ${stepScreenshots ? 'ON' : 'OFF'}\n\n`;
    messages = [
      { role: 'system', content: SYSTEM_PROMPT + '\n\n' + settingsContext },
      ...history
    ];
  }

  const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    signal: abortController.signal,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
      'HTTP-Referer': 'https://viora-extension.local',
      'X-Title': 'Viora Browser Assistant'
    },
    body: JSON.stringify({
      model,
      messages,
      max_tokens: 4000,
      temperature: 0.1
    })
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `HTTP ${response.status}`);
  }
  const data = await response.json();
  return data.choices?.[0]?.message?.content || '';
}

function renderTaskCard(plan) {
  const taskId = 'task-' + Date.now();
  const n = plan.steps?.length || 0;
  const card = document.createElement('div');
  card.className = 'task-card';
  card.id = taskId;
  card.innerHTML = `
    <div class="task-card-header">
      <div class="task-icon">${plan.emoji||'⚡'}</div>
      <div class="task-meta">
        <div class="task-title">${escapeHtml(plan.title||'Task')}</div>
        <div class="task-subtitle">${n} step${n!==1?'s':''} · 100+ strategies ready</div>
      </div>
    </div>
    <div class="task-progress"><div class="task-progress-bar" id="${taskId}-progress"></div></div>
    <div class="task-steps" id="${taskId}-steps">${(plan.steps||[]).map((s,i) => `<div class="task-step" id="${taskId}-step-${i}"><div class="step-status pending" id="${taskId}-status-${i}">${stepStatusIcon('pending')}</div><div class="step-info"><div class="step-desc">${escapeHtml(s.description||s.type)}</div><div class="step-detail">${stepDetailText(s)}</div></div></div>`).join('')}</div>
    <div class="task-card-footer" id="${taskId}-footer">
      <button class="btn-run" id="${taskId}-runBtn" onclick="startTask('${taskId}',${JSON.stringify(plan).replace(/'/g,'&#39;')})"><svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg> Run Task</button>
      <button class="btn-discard" onclick="discardTask('${taskId}')">Discard</button>
    </div>`;
  messagesEl.appendChild(card);
  scrollToBottom();
}

function stepDetailText(s) {
  if (s.type === 'click') return `📍 ${s.description || ''} ${s.selector||''} ${s.text?`"${s.text}"`:''}`.trim();
  if (s.type === 'fill') return `✏️ ${s.description || ''} ${s.selector||''} → "${(s.value||'').slice(0,50)}${s.value?.length > 50 ? '…' : ''}"`.trim();
  if (s.type === 'click_at') return `📍 ${s.description || ''} at (${s.x},${s.y})`;
  if (s.type === 'check') return `☑️ ${s.description || ''} ${s.checked !== false ? 'check' : 'uncheck'} ${s.selector||''}`;
  if (s.type === 'select') return `📋 ${s.description || ''} → "${s.value}"`;
  if (s.type === 'scroll') return `📜 ${s.description || ''}`;
  if (s.type === 'navigate') return `🔗 ${s.description || ''} ${s.url||''}`;
  if (s.type === 'wait_for') return `⏳ ${s.description || ''} ${s.selector||''}`;
  if (s.type === 'extract') return `📄 ${s.description || ''}`;
  if (s.type === 'press_key') return `⌨️ ${s.description || ''} ${s.key||''}`;
  if (s.type === 'hover') return `🖱️ ${s.description || ''}`;
  if (s.type === 'analyze') return `🔍 ${s.description || ''}`;
  if (s.type === 'screenshot') return `📸 ${s.description || ''}`;
  return s.description || s.selector || s.url || s.type || '';
}

function stepStatusIcon(s) { return s==='pending'?'○':s==='running'?'↻':s==='done'?'✓':s==='error'?'✕':'—'; }

async function startTask(taskId, plan, _unusedParentTaskId, round = 1) {
  if (activeTask) return;
  activeTask = taskId; stopRequested = false; consecutiveErrors = 0;

  const footer = document.getElementById(`${taskId}-footer`);
  footer.innerHTML = `<button class="btn-stop" onclick="requestStop()"><svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><rect x="4" y="4" width="16" height="16"/></svg> Stop</button>`;

  const steps = plan.steps || [];
  let completed = 0, lastError = null;

  // V4: Show action preview before starting
  const previewCard = document.getElementById(taskId);
  if (previewCard) previewCard.style.opacity = '1';

  for (let i = 0; i < steps.length; i++) {
    if (stopRequested) break;
    const step = steps[i];
    setStepStatus(taskId, i, 'running');
    showTyping(`${step.description||'Step '+(i+1)}…`);

    try {
      const result = await executeStep(step);
      setStepStatus(taskId, i, 'done');
      consecutiveErrors = 0;

      // V4: Track user action for learning
      trackUserAction(step, result);

      // V4: Store last executed step for undo
      lastExecutedStep = { taskId, stepIndex: i, step, result };
      lastExecutedTaskId = taskId;

      // V4: Add undo button to completed steps
      if (step.type !== 'screenshot' && step.type !== 'analyze' && step.type !== 'navigate') {
        addUndoButtonToStep(taskId, i);
      }

      // A "send" to a chat/AI interface is just as much a page-changing moment as
      // clicking Next/Submit — the reply that streams in afterward IS the result
      // we need to check, so it must not be skipped over on the way to the next step.
      const isChatSend = (step.type === 'click' && (step.text||step.description||'').match(/\bsend\b|\breply\b|\bpost\b|\bask\b(?!ed)|send message/i)) ||
        (step.type === 'press_key' && (step.key||'').toLowerCase() === 'enter' && !step.shift && (step.description||'').match(/send|reply|ask|message|chat/i));
      const isPageChange = step.type === 'navigate' || isChatSend || (step.type === 'click' && (step.text||'').match(/next|submit|continue|proceed|save|done|finish|ok/i));
      const isScreenshot = step.type === 'screenshot';

      if (isScreenshot && result?.screenshot) {
        appendScreenshotToStep(taskId, i, result.screenshot);
        const scrollCaption = await getScrollCaption();
        conversationHistory.push({
          role: 'user',
          content: [
            { type: 'image_url', image_url: { url: result.screenshot } },
            { type: 'text', text: `[Page after step ${i+1}: "${step.description||step.type}"${scrollCaption} — See this page once. Understand the structure. Continue the plan efficiently, batching all actions on this page.]` }
          ]
        });
      }

      if (step.type === 'analyze' && result?.data) {
        const d = typeof result.data === 'string' ? result.data.slice(0,2000) : JSON.stringify(result.data).slice(0,2000);
        appendDataToStep(taskId, i, d);
      }

      if (!isScreenshot && !isPageChange && stepScreenshots) {
        const snap = await captureCurrentTab();
        if (snap) appendScreenshotToStep(taskId, i, snap);
      }

      if (isPageChange && stepScreenshots) {
        let timedOutWaiting = false;
        if (isChatSend) {
          // Don't screenshot mid-stream — wait for the other AI's reply to
          // actually finish appearing before we look at it.
          showTyping('Waiting for the reply to finish…');
          try {
            const idleResult = await executeStep({ type: 'wait_for_idle', idleMs: 1200, timeout: 45000, minWait: 700, description: 'Waiting for AI reply to settle' });
            timedOutWaiting = !!idleResult?.timedOut;
          } catch (_) { /* if idle-wait itself fails, fall through and screenshot anyway */ }
        }
        const snap = await captureCurrentTab();
        if (snap) {
          appendScreenshotToStep(taskId, i, snap);
          if (i + 1 < steps.length) {
            const nextIsScreenshot = steps[i+1].type === 'screenshot';
            const nextIsAnalyze = steps[i+1].type === 'analyze';
            if (!nextIsScreenshot && !nextIsAnalyze) {
              const scrollCaption = await getScrollCaption();
              const note = isChatSend
                ? `[Reply after step ${i+1}: "${step.description||step.type}"${timedOutWaiting ? ' — it may STILL be generating (wait timed out), treat this as possibly incomplete' : ' — content settled, this should be the finished reply'}.${scrollCaption} Read it fully and compare it against the actual goal before deciding anything is done.]`
                : `[Navigated to new page after step ${i+1}. Page structure may have changed.${scrollCaption} Continue with remaining steps efficiently.]`;
              conversationHistory.push({
                role: 'user',
                content: [
                  { type: 'image_url', image_url: { url: snap } },
                  { type: 'text', text: note }
                ]
              });
            }
          }
        }
      }

      if (result?.data && !['analyze','screenshot'].includes(step.type)) {
        appendDataToStep(taskId, i, result.data);
      }

      if (result?.strategy) {
        conversationHistory.push({
          role: 'user',
          content: `[Step ${i+1} strategy]: Used "${result.strategy}" found by ${result.foundBy} in ${result.elapsed}ms`
        });
      }

      completed++;
      updateProgress(taskId, (completed/steps.length)*100);
      await delay(Math.max(50, step.type === 'screenshot' ? 200 : 80));

    } catch (err) {
      consecutiveErrors++;
      setStepStatus(taskId, i, 'error');
      appendErrorToStep(taskId, i, err.message);
      lastError = err;
      showTyping(`Error: ${err.message}. Retrying…`);

      const recovery = await attemptRecovery(step);
      if (recovery) {
        setStepStatus(taskId, i, 'done');
        consecutiveErrors = 0;
        completed++;
        updateProgress(taskId, (completed/steps.length)*100);
        continue;
      }

      for (let j = i+1; j < steps.length; j++) setStepStatus(taskId, j, 'skipped');
      break;
    }
  }

  hideTyping(); activeTask = null;
  const stopped = stopRequested; stopRequested = false;
  const banner = document.createElement('div');
  footer.innerHTML = '';
  const card = document.getElementById(taskId);

  if (stopped) {
    banner.className = 'task-failed-banner'; banner.innerHTML = '⏹ Stopped by user';
    if (card) card.appendChild(banner);
  } else if (lastError) {
    // Give this an id matching what setFinalBanner looks for, so the verification
    // pass below replaces it in place instead of stacking a second banner under it.
    banner.className = 'task-pending-banner';
    banner.id = `${taskId}-final-banner`;
    banner.innerHTML = `<div class="banner-row"><span class="banner-icon">⏳</span><div class="banner-text"><div class="banner-headline">Step failed — checking what's recoverable…</div><div class="banner-reason">${escapeHtml(lastError.message)}</div></div></div>`;
    if (card) card.appendChild(banner);
    await summarizeAndContinue(plan, steps, completed, lastError.message, taskId, round);
  } else {
    // Don't declare victory yet — steps running without throwing an error is not
    // the same as the goal actually being achieved. Show a pending state until
    // the AI double-checks the real page contents.
    banner.className = 'task-pending-banner';
    banner.id = `${taskId}-final-banner`;
    banner.innerHTML = `<div class="banner-row"><span class="banner-icon">⏳</span><div class="banner-text"><div class="banner-headline">Steps ran (${completed}/${steps.length}) — double-checking the result…</div></div></div>`;
    if (card) card.appendChild(banner);
    await summarizeAndContinue(plan, steps, completed, null, taskId, round);
  }

  setBadge('chat');
  scrollToBottom();
}

// V4: Undo button for each step
function addUndoButtonToStep(taskId, index) {
  const stepEl = document.getElementById(`${taskId}-step-${index}`);
  if (!stepEl) return;
  
  const undoBtn = document.createElement('button');
  undoBtn.className = 'step-undo-btn';
  undoBtn.innerHTML = '↩ Undo';
  undoBtn.title = 'Undo this action';
  undoBtn.onclick = async (e) => {
    e.stopPropagation();
    undoBtn.disabled = true;
    undoBtn.textContent = '↺ Undoing…';
    try {
      const result = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ type: 'DOM_ACTION', action: { type: 'undo', description: 'Undo last action' }, tabId: targetTabId }, res => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else if (res?.success === false) reject(new Error(res.error||'Undo failed'));
          else resolve(res);
        });
      });
      undoBtn.textContent = '✓ Undone';
      undoBtn.className = 'step-undo-btn undone';
      addAssistantMessage(`↩ Undid: ${result.message || 'last action'}`);
    } catch(err) {
      undoBtn.textContent = '✕ Failed';
      undoBtn.className = 'step-undo-btn error';
      addAssistantMessage(`⚠️ Undo failed: ${err.message}`);
    }
    setTimeout(() => { undoBtn.remove(); }, 2000);
  };
  stepEl.querySelector('.step-info')?.appendChild(undoBtn);
}

// V4: Security confirmation handler
function handleSecurityConfirm(fieldCategory, step) {
  return new Promise((resolve) => {
    const msg = document.createElement('div');
    msg.className = 'security-confirm';
    msg.innerHTML = `
      <div class="security-icon">🔒</div>
      <div class="security-text">
        <strong>Sensitive Field Detected</strong>
        <span>Viora wants to fill a <strong>${fieldCategory}</strong> field: "${step.description || step.selector || ''}"</span>
      </div>
      <div class="security-buttons">
        <button class="btn-allow" id="secAllow">Allow</button>
        <button class="btn-deny" id="secDeny">Skip</button>
      </div>
    `;
    messagesEl.appendChild(msg);
    scrollToBottom();
    
    document.getElementById('secAllow').onclick = () => { msg.remove(); resolve(true); };
    document.getElementById('secDeny').onclick = () => { msg.remove(); resolve(false); };
  });
}

async function attemptRecovery(step) {
  if (consecutiveErrors > 2) return null;
  await delay(800);
  const snap = await captureCurrentTab();
  if (!snap) return null;
  try {
    const result = await executeStep(step);
    return { screenshot: snap, result };
  } catch(e) {
    if (step.text) {
      const coordStep = { type: 'click_at', x: 0, y: 0, description: `Fallback: ${step.text}` };
      try { await executeStep(coordStep); return { screenshot: snap }; } catch(_) {}
    }
    return null;
  }
}

// Loose normalization so "Email field is still empty" and "The Email field is still empty."
// are recognized as the same blocker even with minor wording drift between rounds.
function normalizeReason(s) {
  return (s || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

// Pulls the machine-readable verdict + reason + (optional) category the verification
// prompt asks for, and strips all of it out of whatever text gets shown to the user.
function extractTaskStatus(reply) {
  const sM = reply.match(/\[TASK_STATUS:\s*(VERIFIED_COMPLETE|INCOMPLETE|NEEDS_USER)\s*\]/i);
  const rM = reply.match(/\[TASK_REASON:\s*([^\]]+)\]/i);
  const cM = reply.match(/\[TASK_CATEGORY:\s*(CAPTCHA|AMBIGUOUS_CHOICE|MISSING_INFO|REPEATED_FAILURE|BLOCKED_ELEMENT|OTHER)\s*\]/i);
  const status = sM ? sM[1].toUpperCase() : null;
  const reason = rM ? rM[1].trim() : '';
  const category = cM ? cM[1].toUpperCase() : null;
  const cleaned = reply
    .replace(/\[TASK_STATUS:[^\]]*\]/i, '')
    .replace(/\[TASK_REASON:[^\]]*\]/i, '')
    .replace(/\[TASK_CATEGORY:[^\]]*\]/i, '')
    .trim();
  return { status, reason, category, cleaned };
}

const NEEDS_USER_CATEGORY_INFO = {
  CAPTCHA:          { icon: '🤖', label: 'Blocked by a CAPTCHA' },
  AMBIGUOUS_CHOICE:  { icon: '❓', label: 'Needs a judgment call' },
  MISSING_INFO:      { icon: '📝', label: 'Missing information' },
  REPEATED_FAILURE:  { icon: '🔁', label: 'Kept failing the same way' },
  BLOCKED_ELEMENT:   { icon: '🚧', label: "Couldn't reach an element" },
  OTHER:             { icon: '🧑', label: 'Needs your input' },
};

// Builds (or replaces) the final status banner for a task card with a headline,
// an optional one-line reason, an expandable "details" panel with the AI's full
// verification notes, and a Retry-check button when the outcome wasn't a clean success.
function setFinalBanner(taskId, { className, icon, headline, reason = '', details = '', showRetry = false }) {
  const card = document.getElementById(taskId);
  if (!card) return;
  let banner = document.getElementById(`${taskId}-final-banner`);
  if (!banner) {
    banner = document.createElement('div');
    banner.id = `${taskId}-final-banner`;
    card.appendChild(banner);
  }
  banner.className = className;

  const detailsId = `${taskId}-banner-details`;
  const hasDetails = details && details.trim().length > 0;

  banner.innerHTML = `
    <div class="banner-row">
      <span class="banner-icon">${icon}</span>
      <div class="banner-text">
        <div class="banner-headline">${escapeHtml(headline)}</div>
        ${reason ? `<div class="banner-reason">${escapeHtml(reason)}</div>` : ''}
      </div>
    </div>
    <div class="banner-actions">
      ${showRetry ? `<button class="banner-btn" onclick="retryVerification('${taskId}')">↻ Retry check</button>` : ''}
      ${hasDetails ? `<button class="banner-btn banner-btn-ghost" onclick="
        const d = document.getElementById('${detailsId}');
        const open = d.style.display !== 'none';
        d.style.display = open ? 'none' : 'block';
        this.textContent = open ? 'View details' : 'Hide details';
      ">View details</button>` : ''}
    </div>
    ${hasDetails ? `<div class="banner-details" id="${detailsId}" style="display:none">${formatMarkdown(details)}</div>` : ''}
  `;
}

// Re-runs the verification pass on demand (e.g. the user fixed something themselves,
// or just wants the AI to look again) without re-running the original steps.
function retryVerification(taskId) {
  const ctx = verificationContext[taskId];
  if (!ctx) return;
  const round = verificationRounds[taskId] || 1;
  setFinalBanner(taskId, {
    className: 'task-pending-banner',
    icon: '⏳',
    headline: 'Re-checking the page…',
  });
  summarizeAndContinue(ctx.plan, ctx.steps, ctx.completed, null, taskId, round);
}

async function summarizeAndContinue(plan, steps, completed, error, taskId, round = 1) {
  verificationRounds[taskId] = round;
  verificationContext[taskId] = { plan, steps, completed };
  if (!verificationRoundCaps[taskId]) verificationRoundCaps[taskId] = getRoundCapFor(plan);
  const roundCap = verificationRoundCaps[taskId];
  const summary = error
    ? `Task failed at step ${completed+1}: ${error}`
    : `Task completed: ${completed}/${steps.length} steps done`;

  showTyping(round > 1 ? `Double-checking again (round ${round})…` : 'Re-scanning page to verify…');

  // Do a full page re-scan silently, just like handleSend does
  let verifySnapshots = [];
  try { verifySnapshots = await scanFullPage(); } catch(_) {}
  const pageCtx = await getEnhancedPageContext() || '';

  const verificationRules = `DOUBLE-CHECK PROTOCOL — this is round ${round} of up to ${roundCap}:\n1. Re-read the GOAL above and decide exactly what "done" requires for THIS task (e.g. for a form, every required field filled AND a submit/confirmation actually shown — not just a button clicked; for a conversation with another AI, a reply that actually answers what was asked — not just a message sent; for a multi-page assignment, every question on every page answered and submitted — not just page one; for a category/"all" request like "delete the spam," the category must actually be EMPTY or confirmed fully cleared — not just one item handled).\n2. Scan every screenshot top to bottom for: error banners, "Please answer this question" / "required field" warnings, red or orange validation highlights, fields that still show placeholder text instead of a real value, a Next/Submit button still sitting on the same unsubmitted page, a chat reply that's empty, still loading, or clearly cut off mid-sentence, a list/inbox/category that still visibly contains items matching what was supposed to be cleared.\n3. Trust the screenshot over the execution log — a step "succeeding" without throwing an error does NOT mean the page actually shows the result you wanted. Verify visually.\n4. A message being SENT is never the finish line by itself. If this task involves another AI/chatbot, read its actual reply and judge whether it genuinely addresses the request. If not, that's INCOMPLETE — plan a specific, targeted follow-up message (not a vague "keep going") as the next step, not a generic re-send.\n5. BE PERSISTENT: don't escalate to NEEDS_USER just because one fix attempt didn't fully land — keep trying genuinely different approaches (different selector, different strategy, scroll first, close a blocking modal, a more specific follow-up message, another pass through remaining list items, etc.) across rounds. Only stop trying if it's truly outside what automation can do (captcha, a judgment call only the person can make, missing info only they have, the other AI declining) or you've hit the exact same blocker repeatedly with no new ideas left.\n${round > 1 ? '6. This was already flagged incomplete before — if your fix from last round genuinely did not change anything, do not repeat it verbatim; try a different selector/strategy/message, or escalate to NEEDS_USER with REPEATED_FAILURE if you\'re out of ideas.\n' : ''}${round >= roundCap ? `7. This is the FINAL allowed round. If it still isn't done, do not produce another action_plan — explain clearly what's left unfinished and respond with [TASK_STATUS: NEEDS_USER] so the person can finish it themselves.\n` : ''}\nEnd your reply with these lines, verbatim, in this order — they will be parsed by code and removed before the person sees your message, so be precise:\n[TASK_STATUS: VERIFIED_COMPLETE | INCOMPLETE | NEEDS_USER] — pick exactly one\n[TASK_REASON: one short, specific, human-readable sentence] — e.g. "All 6 questions answered and the thank-you page is showing", "The Email and Phone fields are still empty after two attempts", "Claude's reply only covered half the request, sent a specific follow-up", "Spam folder still shows 4 messages, deleting the next batch", or "A CAPTCHA appeared and can't be solved automatically". Be concrete: name the actual field/page/element/reply content/remaining-item-count involved, don't just say "an issue occurred."\n[TASK_CATEGORY: CAPTCHA | AMBIGUOUS_CHOICE | MISSING_INFO | REPEATED_FAILURE | BLOCKED_ELEMENT | OTHER] — include ONLY if TASK_STATUS is NEEDS_USER, pick the closest fit`;

  // Build verification message with all re-scan screenshots
  let verifyContent;
  if (verifySnapshots.length > 0) {
    const parts = [];
    for (const snap of verifySnapshots) {
      parts.push({ type: 'image_url', image_url: { url: snap.dataUrl } });
      parts.push({ type: 'text', text: `[Verification scan ${snap.position}/${snap.total} — ${Math.round((snap.position-1)/snap.total*100)}% down]` });
    }
    parts.push({ type: 'text', text: `[Status]: ${summary}\n[Goal]: ${plan.title}\n\n${pageCtx}\n\n${verificationRules}` });
    verifyContent = parts;
  } else {
    const snap = await captureCurrentTab();
    verifyContent = snap
      ? [{ type: 'image_url', image_url: { url: snap } }, { type: 'text', text: `[Status]: ${summary}\n[Goal]: ${plan.title}\n\n${pageCtx}\n\n${verificationRules}` }]
      : `[Status]: ${summary}\n[Goal]: ${plan.title}\n\n${pageCtx}\n\n${verificationRules}`;
  }

  conversationHistory.push({ role: 'user', content: verifyContent });

  hideTyping();
  showTyping('Checking results…');
  try {
    const reply = await callAI(conversationHistory);
    hideTyping();
    conversationHistory.push({ role: 'assistant', content: reply });
    const { status, reason, category, cleaned } = extractTaskStatus(reply);
    const { plan: nextPlan, visibleText } = extractActionPlan(cleaned);
    const stepsLine = `${completed}/${steps.length} steps ran`;

    // Stuck-loop guard: if this round's blocker is essentially the same one reported
    // last round, more rounds won't help — escalate now instead of burning the rest
    // of the cap on a fix that demonstrably isn't working.
    const prevReason = verificationReasonHistory[taskId];
    const isStuck = round > 1 && status === 'INCOMPLETE' && reason &&
      prevReason && normalizeReason(reason) === normalizeReason(prevReason);
    verificationReasonHistory[taskId] = reason;

    if (status === 'VERIFIED_COMPLETE' && !nextPlan) {
      setFinalBanner(taskId, {
        className: 'task-complete-banner',
        icon: '✓',
        headline: `Complete — verified (${stepsLine})`,
        reason,
        details: visibleText || cleaned,
      });
      delete verificationContext[taskId];
      delete verificationReasonHistory[taskId];
      delete verificationRoundCaps[taskId];
      if (visibleText) addAssistantMessage(visibleText);
      return;
    }

    if (status === 'NEEDS_USER' || isStuck || (round >= roundCap && nextPlan)) {
      const effectiveCategory = isStuck && !category ? 'REPEATED_FAILURE' : category;
      const info = NEEDS_USER_CATEGORY_INFO[effectiveCategory] || NEEDS_USER_CATEGORY_INFO.OTHER;
      setFinalBanner(taskId, {
        className: 'task-failed-banner',
        icon: info.icon,
        headline: `${info.label} — ${stepsLine}`,
        reason: reason || (round >= roundCap ? `Tried ${round} rounds of fixes and couldn't confirm completion.` : ''),
        details: visibleText || cleaned,
        showRetry: true,
      });
      delete verificationReasonHistory[taskId];
      addAssistantMessage(visibleText || reason || cleaned || 'I wasn\'t able to confirm this finished correctly — could you take a look at the page?');
      return;
    }

    if (nextPlan) {
      // Genuinely incomplete — fix it and re-verify afterward, up to the round cap.
      setFinalBanner(taskId, {
        className: 'task-pending-banner',
        icon: '↻',
        headline: `Found an issue — fixing automatically (round ${round}/${roundCap})`,
        reason,
        details: visibleText || cleaned,
      });
      if (visibleText) addAssistantMessage(visibleText);
      renderTaskCard(nextPlan);
      setBadge('actions');
      const tid = document.querySelector('.task-card:last-child')?.id;
      if (tid) setTimeout(() => startTask(tid, nextPlan, taskId, round + 1), 200);
      return;
    }

    // No new plan and no clear VERIFIED_COMPLETE tag — the model said INCOMPLETE
    // but didn't give concrete fix steps. Rather than stalling on a manual "Retry"
    // click, ask it to look again automatically (up to the round cap) — this is
    // the "keep checking until it actually knows it's ready" behavior; the
    // isStuck guard above already prevents this from looping forever on the same
    // unresolved reason.
    const unclear = status === 'INCOMPLETE';
    if (unclear && round < roundCap) {
      setFinalBanner(taskId, {
        className: 'task-pending-banner',
        icon: '↻',
        headline: `Still checking — no clear verdict yet, looking again (round ${round}/${roundCap})`,
        reason,
        details: cleaned,
      });
      if (visibleText) addAssistantMessage(visibleText);
      setTimeout(() => summarizeAndContinue(plan, steps, completed, null, taskId, round + 1), 400);
      return;
    }
    setFinalBanner(taskId, {
      className: unclear ? 'task-pending-banner' : 'task-complete-banner',
      icon: unclear ? '⚠️' : '✓',
      headline: unclear ? `Unclear whether this finished — ${stepsLine}` : `Complete — ${stepsLine}`,
      reason,
      details: cleaned,
      showRetry: unclear,
    });
    addAssistantMessage(cleaned);
  } catch(err) {
    hideTyping();
    if (err.name !== 'AbortError') console.warn(err);
    setFinalBanner(taskId, {
      className: 'task-failed-banner',
      icon: '⚠️',
      headline: "Couldn't verify completion",
      reason: err.message || 'Unknown error contacting the AI.',
      showRetry: true,
    });
  }
}

function requestStop() { stopRequested = true; }

function discardTask(taskId) {
  const card = document.getElementById(taskId);
  if (card) { card.style.opacity = '0'; card.style.transform = 'scale(0.97)'; card.style.transition = 'all 0.2s'; setTimeout(() => card.remove(), 200); }
  delete verificationContext[taskId];
  delete verificationRounds[taskId];
  delete verificationReasonHistory[taskId];
  delete verificationRoundCaps[taskId];
  setBadge('chat');
}

async function executeStep(step) {
  if (step.type === 'screenshot') return { success: true, screenshot: await captureCurrentTab() };
  if (step.type === 'navigate') {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'NAVIGATE', url: step.url, tabId: targetTabId }, res => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else if (res?.error) reject(new Error(res.error));
        else resolve(res);
      });
    });
  }
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: 'DOM_ACTION', action: step, tabId: targetTabId }, res => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else if (res?.success === false) reject(new Error(res.error||'Action failed'));
      else resolve(res||{success:true});
    });
  });
}

function setStepStatus(taskId, index, status) {
  const el = document.getElementById(`${taskId}-status-${index}`);
  if (el) { el.className = `step-status ${status}`; el.textContent = stepStatusIcon(status); }
}

function updateProgress(taskId, percent) {
  const bar = document.getElementById(`${taskId}-progress`);
  if (bar) bar.style.width = percent + '%';
}

function appendScreenshotToStep(taskId, index, dataUrl) {
  const el = document.getElementById(`${taskId}-steps`);
  const img = document.createElement('img');
  img.src = dataUrl; img.className = 'step-screenshot'; el.appendChild(img);
}

function appendDataToStep(taskId, index, data) {
  const el = document.getElementById(`${taskId}-steps`);
  const d = document.createElement('div');
  d.className = 'data-preview';
  d.textContent = (data||'').slice(0,600) + ((data||'').length > 600 ? '…' : '');
  el.appendChild(d);
}

function appendErrorToStep(taskId, index, message) {
  const stepEl = document.getElementById(`${taskId}-step-${index}`);
  if (!stepEl) return;
  const errEl = document.createElement('div');
  errEl.className = 'step-error'; errEl.textContent = message;
  stepEl.querySelector('.step-info').appendChild(errEl);
}

async function captureAndAttach() {
  const shot = await captureCurrentTab();
  if (shot) { pendingScreenshot = shot; screenshotPreview.src = shot; screenshotBar.style.display = 'flex'; document.getElementById('attachScreenBtn').classList.add('active'); }
}

function addUserMessage(text, screenshot) {
  hideWelcome();
  const div = document.createElement('div'); div.className = 'message user';
  let html = `<div class="msg-bubble">${escapeHtml(text)}</div>`;
  if (screenshot) html += `<img src="${screenshot}" class="msg-screenshot" />`;
  div.innerHTML = html; messagesEl.appendChild(div); scrollToBottom();
}

function addAssistantMessage(text) {
  const { visibleText } = extractActionPlan(text);
  const cleaned = (visibleText||text).trim();
  if (!cleaned) return;
  const div = document.createElement('div'); div.className = 'message assistant';
  const msgId = 'msg-' + Date.now() + '-' + Math.floor(Math.random()*1000);
  div.innerHTML = `
    <div class="msg-row">
      ${assistantAvatarSvg()}
      <div class="msg-col">
        <div class="msg-bubble" id="${msgId}"></div>
        <div class="msg-actions">
          <button class="msg-action-btn copy-msg-btn" title="Copy" data-target="${msgId}">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
          </button>
        </div>
      </div>
    </div>`;
  messagesEl.appendChild(div); scrollToBottom();
  const bubbleEl = div.querySelector('.msg-bubble');
  revealText(bubbleEl, cleaned).then(() => {
    wireCodeCopyButtons(div);
    wireMessageCopyButtons(div);
    div.querySelector('.msg-actions')?.classList.add('shown');
  });
}

async function revealText(el, fullText) {
  const total = fullText.length;
  if (total === 0) return;
  // Aim for a snappy ~600-900ms reveal regardless of length, like a fast typing model.
  const tickMs = 16;
  const ticks = Math.max(6, Math.round(700 / tickMs));
  const chunk = Math.max(1, Math.ceil(total / ticks));
  let i = 0;
  while (i < total) {
    i = Math.min(total, i + chunk);
    el.innerHTML = formatMarkdown(fullText.slice(0, i)) + (i < total ? '<span class="stream-cursor"></span>' : '');
    scrollToBottom();
    await delay(tickMs);
  }
}

function assistantAvatarSvg() {
  return `<div class="msg-avatar"><svg width="13" height="13" viewBox="0 0 22 22" fill="none"><polyline points="5,8 11,15 17,8" stroke="white" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg></div>`;
}

function wireCodeCopyButtons(scopeEl) {
  scopeEl.querySelectorAll('.code-copy-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const block = btn.closest('.code-block');
      const codeEl = block && block.querySelector('pre code');
      if (!codeEl) return;
      copyTextToClipboard(codeEl.textContent);
      btn.classList.add('copied');
      const label = btn.querySelector('.copy-label');
      const original = label ? label.textContent : '';
      if (label) label.textContent = 'Copied';
      showToast('Code copied');
      setTimeout(() => { btn.classList.remove('copied'); if (label) label.textContent = original || 'Copy'; }, 1500);
    });
  });
}

function wireMessageCopyButtons(scopeEl) {
  scopeEl.querySelectorAll('.copy-msg-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = document.getElementById(btn.dataset.target);
      if (!target) return;
      copyTextToClipboard(target.innerText);
      btn.classList.add('copied');
      showToast('Copied to clipboard');
      setTimeout(() => btn.classList.remove('copied'), 1200);
    });
  });
}

function copyTextToClipboard(str) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(str).catch(() => fallbackCopy(str));
  } else {
    fallbackCopy(str);
  }
}

function fallbackCopy(str) {
  const ta = document.createElement('textarea');
  ta.value = str; ta.style.position = 'fixed'; ta.style.opacity = '0';
  document.body.appendChild(ta); ta.select();
  try { document.execCommand('copy'); } catch (_) {}
  document.body.removeChild(ta);
}

let toastTimer = null;
function showToast(msg) {
  let toast = document.querySelector('.viora-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'viora-toast';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 1600);
}

function toggleTheme() {
  const root = document.documentElement;
  const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  root.setAttribute('data-theme', next);
  try { localStorage.setItem('viora-theme', next); } catch (_) {}
}

function addThinkingBubble(text) {
  // Strip any JSON or action_plan blocks that leaked through
  const cleaned = text
    .replace(/```[\s\S]*?```/g, '')
    .replace(/\{[\s\S]*?"type"[\s\S]*?\}/g, '')
    .replace(/\{"type".*?\}/gs, '')
    .trim();
  if (!cleaned) return;
  const id = 'think-' + Date.now();
  const div = document.createElement('div');
  div.className = 'message assistant thinking-msg';
  div.id = id;
  div.innerHTML = `
    <div class="msg-row">
      ${assistantAvatarSvg()}
      <div class="msg-col">
    <div class="thinking-bubble">
      <button class="thinking-toggle" onclick="
        const b = document.getElementById('${id}').querySelector('.thinking-body');
        const t = document.getElementById('${id}').querySelector('.thinking-toggle');
        const open = b.style.display !== 'none';
        b.style.display = open ? 'none' : 'block';
        t.innerHTML = open
          ? '<svg width=\\"10\\" height=\\"10\\" viewBox=\\"0 0 24 24\\" fill=\\"none\\" stroke=\\"currentColor\\" stroke-width=\\"2\\"><polyline points=\\"6 9 12 15 18 9\\"/></svg> Show reasoning'
          : '<svg width=\\"10\\" height=\\"10\\" viewBox=\\"0 0 24 24\\" fill=\\"none\\" stroke=\\"currentColor\\" stroke-width=\\"2\\"><polyline points=\\"18 15 12 9 6 15\\"/></svg> Hide reasoning';
      ">
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="18 15 12 9 6 15"/></svg>
        Hide reasoning
      </button>
      <div class="thinking-body">${formatMarkdown(cleaned)}</div>
    </div>
      </div>
    </div>
  `;
  messagesEl.appendChild(div);
  wireCodeCopyButtons(div);
  scrollToBottom();
}

function formatMarkdown(text) {
  // Pull out fenced code blocks first so they don't get mangled by inline escaping/markdown rules.
  const blocks = [];
  let working = text.replace(/```(\w*)\n?([\s\S]*?)```/g, (match, lang, code) => {
    const idx = blocks.length;
    blocks.push({ lang: (lang || 'text').trim(), code: code.replace(/\n$/, '') });
    return `\u0000CODEBLOCK${idx}\u0000`;
  });

  working = working.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/`([^`]+)`/g,'<code>$1</code>')
    .replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/\*(.+?)\*/g,'<em>$1</em>')
    .replace(/^### (.+)$/gm,'<strong>$1</strong>').replace(/^## (.+)$/gm,'<strong>$1</strong>')
    .replace(/^# (.+)$/gm,'<strong>$1</strong>').replace(/^\- (.+)$/gm,'• $1')
    .replace(/\n\n/g,'</p><p>').replace(/\n/g,'<br>');

  working = working.replace(/\u0000CODEBLOCK(\d+)\u0000/g, (match, idx) => {
    const b = blocks[Number(idx)];
    if (!b) return '';
    const escapedCode = b.code.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    return `</p><div class="code-block">
      <div class="code-block-header">
        <span>${escapeHtml(b.lang)}</span>
        <button class="code-copy-btn" type="button">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
          <span class="copy-label">Copy</span>
        </button>
      </div>
      <pre><code>${escapedCode}</code></pre>
    </div><p>`;
  });

  return working;
}

function extractActionPlan(response) {
  const t = response.trim();
  if (t.startsWith('{"type":"action_plan"') || t.startsWith('{ "type": "action_plan"')) {
    try { const p = JSON.parse(t); if (p?.type === 'action_plan') return { plan: p, visibleText: '' }; } catch(_) {}
  }
  let i = 0;
  while (i < response.length) {
    const brace = response.indexOf('{', i);
    if (brace === -1) break;
    let depth = 0, j = brace;
    while (j < response.length) {
      if (response[j] === '{') depth++;
      else if (response[j] === '}') { depth--; if (depth === 0) break; }
      j++;
    }
    if (depth === 0) {
      try { const p = JSON.parse(response.slice(brace, j+1)); if (p?.type === 'action_plan') return { plan: p, visibleText: (response.slice(0,brace)+response.slice(j+1)).trim() }; } catch(_) {}
    }
    i = brace + 1;
  }
  return { plan: null, visibleText: response };
}

function escapeHtml(str) { return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
function hideWelcome() { if (welcomeEl) welcomeEl.style.display = 'none'; }

function showTyping(msg = 'Thinking…') {
  typingText.textContent = msg; typingIndicator.style.display = 'flex';
  sendBtn.style.display = 'none'; stopInputBtn.style.display = 'flex'; scrollToBottom();
}

function hideTyping() {
  typingIndicator.style.display = 'none'; stopInputBtn.style.display = 'none';
  sendBtn.style.display = ''; sendBtn.disabled = chatInput.value.trim() === '';
}

function scrollToBottom() { messagesEl.scrollTop = messagesEl.scrollHeight; }
function setBadge(mode) { modeBadge.textContent = mode === 'actions' ? 'Actions' : 'Chat'; modeBadge.className = 'mode-badge' + (mode === 'actions' ? ' actions' : ''); }

function clearConversation() {
  conversationHistory = []; consecutiveErrors = 0; messagesEl.innerHTML = '';
  const w = document.createElement('div'); w.id = 'welcome'; w.className = 'welcome';
  w.innerHTML = `<div class="welcome-icon"><svg width="22" height="22" viewBox="0 0 40 40" fill="none"><polyline points="10,15 20,27 30,15" stroke="white" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg></div><h2>What can I help with?</h2><p>Tell me what to do on this page — I can click, type, fill forms, and read what's on screen.</p>`;
  messagesEl.appendChild(w); setBadge('chat');
}

function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

window.startTask = startTask; window.discardTask = discardTask; window.requestStop = requestStop;
init();
