const SYSTEM_PROMPT = `You are Viora, a browser automation AI with a 100+ strategy clicking engine. You can see screens and click anything perfectly.

Whenever the user asks you to do something on a website:
1. LOOK at the screenshot — see every button, link, input, and text
2. READ the [Interactive Elements] — you get a structured list of every clickable thing
3. THINK about what the logical next step is
4. PLAN the complete sequence of steps needed
5. VERIFY after each step using the post-action screenshot

YOUR CLICKING ENGINE HAS OVER 100 STRATEGIES:
The system automatically tries different finder strategies (CSS selectors, XPath, text matching, attribute matching, label matching, hint-based navigation finding) combined with different click execution strategies (pointer events, mouse events, touch events, React synthetic events, native click, focus+enter) and different timing patterns. If one strategy fails, it falls through to the next. The AI is never told "I can't click that" — it always finds a way.

RESPOND IN ACTION MODE using this JSON format ONLY:

{"type":"action_plan","title":"Task title","emoji":"🖱️","steps":[
  {"type":"screenshot","description":"See the page"},
  {"type":"analyze","description":"Analyze available elements"},
  {"type":"click","selector":"#NextButton","text":"Next","description":"Click Next button"},
  {"type":"fill","selector":"input[name='email']","value":"user@example.com","description":"Enter email"},
  {"type":"click_at","x":450,"y":320,"description":"Click at coordinates on screen"}
]}

RULES FOR ACCURACY:
- Start every task with screenshot (and optionally analyze) to understand the page
- For every click step, ALWAYS include BOTH "selector" AND "text" for redundancy
- The engine will try 100+ strategy combinations — your job is to give it good targets
- After each step executes, you automatically get a verification screenshot
- If something fails, the engine retries 3× automatically with fallbacks
- For survey/checkout flows, chain ALL steps across ALL pages upfront
- Use click_at with coordinates from the screenshot as the ultimate fallback
- After the task completes, check the final screenshot to decide if more steps are needed

AVAILABLE STEP TYPES: screenshot, analyze, click, click_at, fill, clear, select, check, scroll, extract, extract_links, extract_table, wait_for, hover, press_key, get_page_info`;

let apiKey = '';
let model = 'google/gemini-2.0-flash-001';
let conversationHistory = [];
let pendingScreenshot = null;
let activeTask = null;
let stopRequested = false;
let abortController = null;
let autoScreenshot = true;
let stepScreenshots = true;
let targetTabId = null;
let targetTabTitle = '';
let targetTabFavicon = '';
let consecutiveErrors = 0;

const messagesEl = document.getElementById('messages');
const chatInput = document.getElementById('chatInput');
const sendBtn = document.getElementById('sendBtn');
const stopInputBtn = document.getElementById('stopInputBtn');
const welcomeEl = document.getElementById('welcome');
const typingIndicator = document.getElementById('typingIndicator');
const typingText = document.getElementById('typingText');
const screenshotBar = document.getElementById('screenshotBar');
const screenshotPreview = document.getElementById('screenshotPreview');
const noKeyNotice = document.getElementById('noKeyNotice');
const modeBadge = document.getElementById('modeBadge');
const tabPicker = document.getElementById('tabPicker');
const tabPickerList = document.getElementById('tabPickerList');
const tabPickerSearch = document.getElementById('tabPickerSearch');
const tabBadge = document.getElementById('tabBadge');
const tabBadgeFavicon = document.getElementById('tabBadgeFavicon');
const tabBadgeTitle = document.getElementById('tabBadgeTitle');
const tabBadgeClear = document.getElementById('tabBadgeClear');

async function init() {
  const stored = await chrome.storage.local.get(['apiKey','model','autoScreenshot','stepScreenshots']);
  apiKey = stored.apiKey || '';
  model = stored.model || 'google/gemini-2.0-flash-001';
  autoScreenshot = stored.autoScreenshot !== false;
  stepScreenshots = stored.stepScreenshots !== false;
  if (!apiKey) noKeyNotice.style.display = 'block';
  setupEventListeners();
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.apiKey) { apiKey = changes.apiKey.newValue || ''; noKeyNotice.style.display = apiKey ? 'none' : 'block'; }
  if (changes.model) model = changes.model.newValue || 'google/gemini-2.0-flash-001';
  if (changes.autoScreenshot) autoScreenshot = changes.autoScreenshot.newValue !== false;
  if (changes.stepScreenshots) stepScreenshots = changes.stepScreenshots.newValue !== false;
});

function setupEventListeners() {
  sendBtn.addEventListener('click', handleSend);
  chatInput.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }});
  chatInput.addEventListener('input', () => {
    chatInput.style.height = 'auto';
    chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
    sendBtn.disabled = chatInput.value.trim() === '';
  });
  document.querySelectorAll('.quick-chip').forEach(c => c.addEventListener('click', () => {
    chatInput.value = c.dataset.prompt;
    chatInput.dispatchEvent(new Event('input'));
    handleSend();
  }));
  document.getElementById('screenshotBtn').addEventListener('click', captureAndAttach);
  document.getElementById('attachScreenBtn').addEventListener('click', captureAndAttach);
  document.getElementById('removeScreenshot').addEventListener('click', () => {
    pendingScreenshot = null; screenshotBar.style.display = 'none';
    document.getElementById('attachScreenBtn').classList.remove('active');
  });
  document.getElementById('clearBtn').addEventListener('click', clearConversation);
  chatInput.addEventListener('input', handleAtMention);
  chatInput.addEventListener('keydown', e => {
    if (tabPicker.style.display === 'none') return;
    const items = tabPickerList.querySelectorAll('.tab-picker-item');
    const sel = tabPickerList.querySelector('.tab-picker-item.selected');
    let idx = [...items].indexOf(sel);
    if (e.key === 'ArrowDown') { e.preventDefault(); selectPickerItem(items, Math.min(idx+1, items.length-1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); selectPickerItem(items, Math.max(idx-1, 0)); }
    else if (e.key === 'Enter' && sel) { e.preventDefault(); sel.click(); }
    else if (e.key === 'Escape') { closeTabPicker(); }
  });
  tabPickerSearch.addEventListener('input', () => renderTabPickerItems(tabPickerSearch.value));
  stopInputBtn.addEventListener('click', () => {
    if (abortController) { abortController.abort(); abortController = null; }
    stopRequested = true; activeTask = null; hideTyping();
  });
  tabBadgeClear.addEventListener('click', () => {
    targetTabId = null; targetTabTitle = ''; targetTabFavicon = '';
    tabBadge.style.display = 'none';
  });
  document.addEventListener('click', e => {
    if (!tabPicker.contains(e.target) && e.target !== chatInput) closeTabPicker();
  });
}

let _allTabs = [];

function handleAtMention(e) {
  const val = chatInput.value;
  const cursor = chatInput.selectionStart;
  const before = val.slice(0, cursor);
  const atIdx = before.lastIndexOf('@');
  if (atIdx !== -1 && !before.slice(atIdx + 1).includes(' ')) openTabPicker(before.slice(atIdx + 1));
  else closeTabPicker();
}

function openTabPicker(query) {
  chrome.runtime.sendMessage({ type: 'LIST_TABS' }, res => {
    if (!res?.tabs) return;
    _allTabs = res.tabs.filter(t => t.url && !t.url.startsWith('chrome://') && !t.url.startsWith('chrome-extension://'));
    tabPickerSearch.value = query;
    renderTabPickerItems(query);
    tabPicker.style.display = 'flex';
    tabPickerSearch.focus();
  });
}

function renderTabPickerItems(query) {
  const q = (query||'').toLowerCase();
  const filtered = _allTabs.filter(t => !q || t.title?.toLowerCase().includes(q) || t.url?.toLowerCase().includes(q)).slice(0, 10);
  tabPickerList.innerHTML = filtered.length ? '' : '<div style="padding:12px;font-size:12px;color:var(--text-3);text-align:center">No tabs found</div>';
  filtered.forEach((tab, i) => {
    const item = document.createElement('div');
    item.className = 'tab-picker-item' + (i === 0 ? ' selected' : '');
    const domain = (() => { try { return new URL(tab.url).hostname.replace('www.', ''); } catch(_) { return tab.url; }})();
    item.innerHTML = `<div class="tab-picker-favicon-wrap">${tab.favIconUrl ? `<img src="${tab.favIconUrl}" width="16" height="16" onerror="this.parentElement.innerHTML='<div class=tab-favicon-placeholder></div>'">` : '<div class="tab-favicon-placeholder"></div>'}</div><div class="tab-picker-item-text"><div class="tab-picker-item-title">${escapeHtml(tab.title||'Untitled')}</div><div class="tab-picker-item-url">${escapeHtml(domain)}</div></div>`;
    item.addEventListener('click', () => pickTab(tab));
    tabPickerList.appendChild(item);
  });
}

function selectPickerItem(items, idx) {
  items.forEach((el, i) => el.classList.toggle('selected', i === idx));
}

function pickTab(tab) {
  targetTabId = tab.id; targetTabTitle = tab.title || tab.url; targetTabFavicon = tab.favIconUrl || '';
  const val = chatInput.value;
  const cursor = chatInput.selectionStart;
  const before = val.slice(0, cursor);
  const atIdx = before.lastIndexOf('@');
  if (atIdx !== -1) {
    chatInput.value = val.slice(0, atIdx) + val.slice(cursor);
    chatInput.selectionStart = chatInput.selectionEnd = atIdx;
  }
  tabBadgeTitle.textContent = targetTabTitle.length > 40 ? targetTabTitle.slice(0,40) + '…' : targetTabTitle;
  tabBadgeFavicon.src = targetTabFavicon; tabBadgeFavicon.style.display = targetTabFavicon ? '' : 'none';
  tabBadge.style.display = 'flex'; closeTabPicker(); chatInput.focus();
}

function closeTabPicker() { tabPicker.style.display = 'none'; }

async function captureCurrentTab() {
  try {
    const res = await new Promise(resolve => chrome.runtime.sendMessage({ type: 'CAPTURE_SCREENSHOT', tabId: targetTabId }, resolve));
    if (res?.screenshot) return res.screenshot;
    return null;
  } catch(_) { return null; }
}

async function getPageContext() {
  try {
    const tabInfo = await new Promise(resolve => chrome.runtime.sendMessage({ type: 'GET_TAB_INFO', tabId: targetTabId }, resolve));
    if (!tabInfo?.url || tabInfo.url.startsWith('chrome://')) return null;
    const pageContent = await new Promise(resolve => chrome.runtime.sendMessage({ type: 'GET_PAGE_CONTENT', tabId: targetTabId }, resolve));

    let ctx = `[Current page: ${tabInfo.url}]`;
    if (pageContent?.text) ctx += `\n[Page text excerpt]: ${pageContent.text.slice(0, 3000)}`;

    if (pageContent?.interactiveElements?.length > 0) {
      const buttons = pageContent.interactiveElements.filter(e => ['BUTTON','A','INPUT'].includes(e.tag) || ['button','link'].includes(e.role)).filter(e => e.text||e.ariaLabel).slice(0,40);
      const inputs = pageContent.interactiveElements.filter(e => ['INPUT','SELECT','TEXTAREA'].includes(e.tag) || ['combobox','listbox'].includes(e.role)).slice(0,25);
      if (buttons.length) ctx += `\n[Buttons/Links]:\n  ` + buttons.map(e => `${e.tag}${e.id?'#'+e.id:''} "${e.text||e.ariaLabel}" ${e.visible?'':'⚠️hidden'}${e.disabled?'🚫disabled':''} rect:${e.rect}`).join('\n  ');
      if (inputs.length) ctx += `\n[Inputs]:\n  ` + inputs.map(e => `${e.tag} name="${e.name}" type="${e.type}" placeholder="${e.placeholder}" label="${e.ariaLabel||e.text}" ${e.visible?'':'⚠️hidden'}`).join('\n  ');
    }
    return ctx;
  } catch(_) { return null; }
}

async function handleSend() {
  const text = chatInput.value.trim();
  if (!text) return;
  if (!apiKey) { noKeyNotice.style.display = 'block'; return; }

  chatInput.value = ''; chatInput.style.height = 'auto'; sendBtn.disabled = true;
  hideWelcome();

  if (autoScreenshot && !pendingScreenshot) pendingScreenshot = await captureCurrentTab();
  if (!pendingScreenshot && !autoScreenshot && /what.*(on|see|screen|page|tab)|look at|this page|click|automate|go to|navigate|fill|search|find|help|do this/i.test(text)) {
    pendingScreenshot = await captureCurrentTab();
  }

  addUserMessage(text, pendingScreenshot);
  const pageContext = await getPageContext();

  let userContent;
  if (pendingScreenshot) {
    userContent = [
      { type: 'image_url', image_url: { url: pendingScreenshot } },
      { type: 'text', text: `[User]: ${text}\n${pageContext||''}\n\nLook at the screenshot carefully. Identify every visible element. Plan the complete sequence of steps. Remember: the clicking engine has 100+ strategies and will try them all until one succeeds.` }
    ];
  } else {
    userContent = pageContext ? `${text}\n\n${pageContext}` : text;
  }

  conversationHistory.push({ role: 'user', content: userContent });
  const screenshot = pendingScreenshot;
  pendingScreenshot = null; screenshotBar.style.display = 'none';
  document.getElementById('attachScreenBtn').classList.remove('active');

  showTyping('Thinking with 100+ strategies…');
  consecutiveErrors = 0;

  try {
    const response = await callAI(conversationHistory);
    hideTyping();
    const { plan, visibleText } = extractActionPlan(response);
    if (plan) {
      conversationHistory.push({ role: 'assistant', content: response });
      if (visibleText) addAssistantMessage(visibleText);
      renderTaskCard(plan);
      setBadge('actions');
      const taskId = document.querySelector('.task-card:last-child')?.id;
      if (taskId) setTimeout(() => startTask(taskId, plan), 150);
      return;
    }
    conversationHistory.push({ role: 'assistant', content: response });
    addAssistantMessage(response);
    setBadge('chat');
  } catch (err) {
    hideTyping();
    if (err.name === 'AbortError') return;
    addAssistantMessage(`⚠️ ${err.message}\n\nCheck your API key in settings.`);
  }
}

async function callAI(history) {
  abortController = new AbortController();
  const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    signal: abortController.signal,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
      'HTTP-Referer': 'https://viora-extension.local',
      'X-Title': 'Viora Browser Assistant'
    },
    body: JSON.stringify({
      model,
      messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...history],
      max_tokens: 4000,
      temperature: 0.1
    })
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `HTTP ${response.status}`);
  }
  const data = await response.json();
  return data.choices?.[0]?.message?.content || '';
}

function renderTaskCard(plan) {
  const taskId = 'task-' + Date.now();
  const n = plan.steps?.length || 0;
  const card = document.createElement('div');
  card.className = 'task-card';
  card.id = taskId;
  card.innerHTML = `
    <div class="task-card-header">
      <div class="task-icon">${plan.emoji||'⚡'}</div>
      <div class="task-meta">
        <div class="task-title">${escapeHtml(plan.title||'Task')}</div>
        <div class="task-subtitle">${n} step${n!==1?'s':''} · 100+ strategies ready</div>
      </div>
    </div>
    <div class="task-progress"><div class="task-progress-bar" id="${taskId}-progress"></div></div>
    <div class="task-steps" id="${taskId}-steps">${(plan.steps||[]).map((s,i) => `<div class="task-step" id="${taskId}-step-${i}"><div class="step-status pending" id="${taskId}-status-${i}">${stepStatusIcon('pending')}</div><div class="step-info"><div class="step-desc">${escapeHtml(s.description||s.type)}</div><div class="step-detail">${stepDetailText(s)}</div></div></div>`).join('')}</div>
    <div class="task-card-footer" id="${taskId}-footer">
      <button class="btn-run" id="${taskId}-runBtn" onclick="startTask('${taskId}',${JSON.stringify(plan).replace(/'/g,'&#39;')})"><svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg> Run Task</button>
      <button class="btn-discard" onclick="discardTask('${taskId}')">Discard</button>
    </div>`;
  messagesEl.appendChild(card);
  scrollToBottom();
}

function stepDetailText(s) {
  if (s.type === 'click') return `${s.selector||''} ${s.text?`"${s.text}"`:''}`;
  if (s.type === 'fill') return `${s.selector||''} → "${(s.value||'').slice(0,40)}"`;
  if (s.type === 'click_at') return `coords (${s.x},${s.y})`;
  return s.selector||s.url||s.type||'';
}

function stepStatusIcon(s) { return s==='pending'?'○':s==='running'?'↻':s==='done'?'✓':s==='error'?'✕':'—'; }

async function startTask(taskId, plan) {
  if (activeTask) return;
  activeTask = taskId; stopRequested = false; consecutiveErrors = 0;

  const footer = document.getElementById(`${taskId}-footer`);
  footer.innerHTML = `<button class="btn-stop" onclick="requestStop()"><svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><rect x="4" y="4" width="16" height="16"/></svg> Stop</button>`;

  const steps = plan.steps || [];
  let completed = 0, lastError = null;

  for (let i = 0; i < steps.length; i++) {
    if (stopRequested) break;
    const step = steps[i];
    setStepStatus(taskId, i, 'running');
    showTyping(`Strategizing: ${step.description||`Step ${i+1}`}…`);

    try {
      const result = await executeStep(step);
      setStepStatus(taskId, i, 'done');
      consecutiveErrors = 0;

      if (step.type === 'screenshot' && result?.screenshot) {
        appendScreenshotToStep(taskId, i, result.screenshot);
        conversationHistory.push({ role: 'user', content: [{ type: 'image_url', image_url: { url: result.screenshot } }, { type: 'text', text: `[Step ${i+1} screenshot — Look at this page. What elements do you see? What is the next logical step in the plan?]` }] });
      }

      if (step.type === 'analyze' && result?.data) {
        const d = typeof result.data === 'string' ? result.data.slice(0,2000) : JSON.stringify(result.data).slice(0,2000);
        appendDataToStep(taskId, i, d);
        conversationHistory.push({ role: 'user', content: `[Step ${i+1} analysis]:\n${d}\n\nBased on this page structure, what's the next step?` });
      }

      const skipSnap = ['screenshot','analyze'];
      if (!skipSnap.includes(step.type) && stepScreenshots) {
        const snap = await captureCurrentTab();
        if (snap) {
          appendScreenshotToStep(taskId, i, snap);
          conversationHistory.push({ role: 'user', content: [{ type: 'image_url', image_url: { url: snap } }, { type: 'text', text: `[After step ${i+1}: "${step.description||step.type}" — Verify this worked. The 100+ strategy engine found a way. What does the page look like now?]` }] });
        }
      }

      if (result?.data && !['analyze','screenshot'].includes(step.type)) {
        appendDataToStep(taskId, i, result.data);
        conversationHistory.push({ role: 'user', content: `[Step ${i+1} data]: ${result.data.slice(0,1500)}` });
      }

      if (result?.strategy) {
        conversationHistory.push({ role: 'user', content: `[Step ${i+1} strategy]: Used "${result.strategy}" — found by ${result.foundBy} in ${result.elapsed}ms` });
      }

      completed++;
      updateProgress(taskId, (completed/steps.length)*100);
      await delay(200);

    } catch (err) {
      consecutiveErrors++;
      setStepStatus(taskId, i, 'error');
      appendErrorToStep(taskId, i, err.message);
      lastError = err;
      showTyping(`Error: ${err.message}. Trying all 100+ strategies…`);

      const recovery = await attemptRecovery(step);
      if (recovery) {
        setStepStatus(taskId, i, 'done');
        consecutiveErrors = 0;
        completed++;
        updateProgress(taskId, (completed/steps.length)*100);
        conversationHistory.push({ role: 'user', content: [{ type: 'image_url', image_url: { url: recovery.screenshot } }, { type: 'text', text: `[Recovered step ${i+1} using fallback strategy. Continue with remaining steps.]` }] });
        continue;
      }

      for (let j = i+1; j < steps.length; j++) setStepStatus(taskId, j, 'skipped');
      break;
    }
  }

  hideTyping(); activeTask = null;
  const stopped = stopRequested; stopRequested = false;
  const banner = document.createElement('div');

  if (stopped) {
    banner.className = 'task-failed-banner'; banner.innerHTML = '⏹ Stopped by user';
  } else if (lastError) {
    banner.className = 'task-failed-banner'; banner.innerHTML = `⚠️ Stopped: ${escapeHtml(lastError.message)}`;
    await summarizeAndContinue(plan, steps, completed, lastError.message);
  } else {
    banner.className = 'task-complete-banner'; banner.innerHTML = `✓ Complete — ${completed}/${steps.length} steps`;
    await summarizeAndContinue(plan, steps, completed, null);
  }

  footer.innerHTML = '';
  const card = document.getElementById(taskId);
  if (card) card.appendChild(banner);
  setBadge('chat');
  scrollToBottom();
}

async function attemptRecovery(step) {
  if (consecutiveErrors > 2) return null;
  await delay(1000);
  const snap = await captureCurrentTab();
  if (!snap) return null;

  try {
    const result = await executeStep(step);
    return { screenshot: snap, result };
  } catch(e) {
    if (step.text) {
      const coordStep = { type: 'click_at', x: 0, y: 0, description: `Fallback: ${step.text}` };
      try { await executeStep(coordStep); return { screenshot: snap }; } catch(_) {}
    }
    return null;
  }
}

async function summarizeAndContinue(plan, steps, completed, error) {
  const summary = error ? `Task failed at step ${completed+1}: ${error}` : `Task completed: ${completed}/${steps.length} steps done`;
  let ctx = `[Result]: ${summary}\n[Goal]: ${plan.title}\nLook at the screenshot. Is the goal fully done? If more pages/questions/steps remain, produce an action_plan to continue. If done, say so.`;

  const snap = await captureCurrentTab();
  if (snap) {
    conversationHistory.push({ role: 'user', content: [{ type: 'image_url', image_url: { url: snap } }, { type: 'text', text: ctx }] });
  } else {
    conversationHistory.push({ role: 'user', content: ctx });
  }

  showTyping("Checking next steps…");
  try {
    const reply = await callAI(conversationHistory);
    hideTyping();
    conversationHistory.push({ role: 'assistant', content: reply });
    const { plan: nextPlan, visibleText } = extractActionPlan(reply);
    if (nextPlan) {
      if (visibleText) addAssistantMessage(visibleText);
      renderTaskCard(nextPlan);
      setBadge('actions');
      const tid = document.querySelector('.task-card:last-child')?.id;
      if (tid) setTimeout(() => startTask(tid, nextPlan), 200);
      return;
    }
    addAssistantMessage(reply);
  } catch(err) {
    hideTyping();
    if (err.name !== 'AbortError') console.warn(err);
  }
}

function requestStop() { stopRequested = true; }

function discardTask(taskId) {
  const card = document.getElementById(taskId);
  if (card) { card.style.opacity = '0'; card.style.transform = 'scale(0.97)'; card.style.transition = 'all 0.2s'; setTimeout(() => card.remove(), 200); }
  setBadge('chat');
}

async function executeStep(step) {
  if (step.type === 'screenshot') return { success: true, screenshot: await captureCurrentTab() };
  if (step.type === 'navigate') {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'NAVIGATE', url: step.url, tabId: targetTabId }, res => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else if (res?.error) reject(new Error(res.error));
        else resolve(res);
      });
    });
  }
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: 'DOM_ACTION', action: step, tabId: targetTabId }, res => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else if (res?.success === false) reject(new Error(res.error||'Action failed'));
      else resolve(res||{success:true});
    });
  });
}

function setStepStatus(taskId, index, status) {
  const el = document.getElementById(`${taskId}-status-${index}`);
  if (el) { el.className = `step-status ${status}`; el.textContent = stepStatusIcon(status); }
}

function updateProgress(taskId, percent) {
  const bar = document.getElementById(`${taskId}-progress`);
  if (bar) bar.style.width = percent + '%';
}

function appendScreenshotToStep(taskId, index, dataUrl) {
  const el = document.getElementById(`${taskId}-steps`);
  const img = document.createElement('img');
  img.src = dataUrl; img.className = 'step-screenshot'; el.appendChild(img);
}

function appendDataToStep(taskId, index, data) {
  const el = document.getElementById(`${taskId}-steps`);
  const d = document.createElement('div');
  d.className = 'data-preview';
  d.textContent = (data||'').slice(0,600) + ((data||'').length > 600 ? '…' : '');
  el.appendChild(d);
}

function appendErrorToStep(taskId, index, message) {
  const stepEl = document.getElementById(`${taskId}-step-${index}`);
  if (!stepEl) return;
  const errEl = document.createElement('div');
  errEl.className = 'step-error'; errEl.textContent = message;
  stepEl.querySelector('.step-info').appendChild(errEl);
}

async function captureAndAttach() {
  const shot = await captureCurrentTab();
  if (shot) { pendingScreenshot = shot; screenshotPreview.src = shot; screenshotBar.style.display = 'flex'; document.getElementById('attachScreenBtn').classList.add('active'); }
}

function addUserMessage(text, screenshot) {
  hideWelcome();
  const div = document.createElement('div'); div.className = 'message user';
  let html = `<div class="msg-label">You</div><div class="msg-bubble">${escapeHtml(text)}</div>`;
  if (screenshot) html += `<img src="${screenshot}" class="msg-screenshot" />`;
  div.innerHTML = html; messagesEl.appendChild(div); scrollToBottom();
}

function addAssistantMessage(text) {
  const { visibleText } = extractActionPlan(text);
  const cleaned = (visibleText||text).trim();
  if (!cleaned) return;
  const div = document.createElement('div'); div.className = 'message assistant';
  div.innerHTML = `<div class="msg-label">Viora</div><div class="msg-bubble">${formatMarkdown(cleaned)}</div>`;
  messagesEl.appendChild(div); scrollToBottom();
}

function formatMarkdown(text) {
  return text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/```[\s\S]*?```/g,'').replace(/`([^`]+)`/g,'<code>$1</code>')
    .replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/\*(.+?)\*/g,'<em>$1</em>')
    .replace(/^### (.+)$/gm,'<strong>$1</strong>').replace(/^## (.+)$/gm,'<strong>$1</strong>')
    .replace(/^# (.+)$/gm,'<strong>$1</strong>').replace(/^\- (.+)$/gm,'• $1')
    .replace(/\n\n/g,'</p><p>').replace(/\n/g,'<br>');
}

function extractActionPlan(response) {
  const t = response.trim();
  if (t.startsWith('{"type":"action_plan"') || t.startsWith('{ "type": "action_plan"')) {
    try { const p = JSON.parse(t); if (p?.type === 'action_plan') return { plan: p, visibleText: '' }; } catch(_) {}
  }
  let i = 0;
  while (i < response.length) {
    const brace = response.indexOf('{', i);
    if (brace === -1) break;
    let depth = 0, j = brace;
    while (j < response.length) {
      if (response[j] === '{') depth++;
      else if (response[j] === '}') { depth--; if (depth === 0) break; }
      j++;
    }
    if (depth === 0) {
      try { const p = JSON.parse(response.slice(brace, j+1)); if (p?.type === 'action_plan') return { plan: p, visibleText: (response.slice(0,brace)+response.slice(j+1)).trim() }; } catch(_) {}
    }
    i = brace + 1;
  }
  return { plan: null, visibleText: response };
}

function escapeHtml(str) { return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
function hideWelcome() { if (welcomeEl) welcomeEl.style.display = 'none'; }

function showTyping(msg = 'Thinking…') {
  typingText.textContent = msg; typingIndicator.style.display = 'flex';
  sendBtn.style.display = 'none'; stopInputBtn.style.display = 'flex'; scrollToBottom();
}

function hideTyping() {
  typingIndicator.style.display = 'none'; stopInputBtn.style.display = 'none';
  sendBtn.style.display = ''; sendBtn.disabled = chatInput.value.trim() === '';
}

function scrollToBottom() { messagesEl.scrollTop = messagesEl.scrollHeight; }
function setBadge(mode) { modeBadge.textContent = mode === 'actions' ? 'Actions' : 'Chat'; modeBadge.className = 'mode-badge' + (mode === 'actions' ? ' actions' : ''); }

function clearConversation() {
  conversationHistory = []; consecutiveErrors = 0; messagesEl.innerHTML = '';
  const w = document.createElement('div'); w.id = 'welcome'; w.className = 'welcome';
  w.innerHTML = `<div class="welcome-icon"><svg width="40" height="40" viewBox="0 0 40 40" fill="none"><circle cx="20" cy="20" r="19" fill="url(#wGrad2)"/><polyline points="10,15 20,27 30,15" stroke="white" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/><circle cx="20" cy="11" r="3" fill="#34d399"/><defs><linearGradient id="wGrad2" x1="0" y1="0" x2="40" y2="40"><stop offset="0%" stop-color="#6366f1"/><stop offset="100%" stop-color="#8b5cf6"/></linearGradient></defs></svg></div><h2>Hi, I'm Viora</h2><p>100+ clicking strategies. Perfect vision. I can handle any website.</p>`;
  messagesEl.appendChild(w); setBadge('chat');
}

function delay(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

window.startTask = startTask; window.discardTask = discardTask; window.requestStop = requestStop;
init();
