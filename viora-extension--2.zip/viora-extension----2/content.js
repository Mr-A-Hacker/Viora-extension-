if (!window.__vioraLoaded) {
  window.__vioraLoaded = true;

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'DOM_ACTION') {
      handleDomAction(message.action)
        .then(sendResponse)
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true;
    }
    if (message.type === 'GET_PAGE_CONTENT') {
      sendResponse({
        success: true,
        title: document.title,
        url: window.location.href,
        text: document.body ? document.body.innerText.slice(0, 30000) : '',
        html: document.body ? document.body.innerHTML.slice(0, 15000) : '',
        interactiveElements: extractAllInteractive()
      });
      return true;
    }
    if (message.type === 'ANALYZE_PAGE') {
      sendResponse({ success: true, analysis: deepPageAnalysis() });
      return true;
    }
    if (message.type === 'PING') {
      sendResponse({ alive: true });
      return true;
    }
  });
}

function extractAllInteractive() {
  const selectors = [
    'button', 'a[href]', 'input', 'select', 'textarea',
    '[role="button"]', '[role="link"]', '[role="option"]',
    '[role="checkbox"]', '[role="radio"]', '[role="tab"]',
    '[role="menuitem"]', '[role="combobox"]', '[role="switch"]',
    '[onclick]', '[tabindex]:not([tabindex="-1"])',
    'summary', 'label', 'option'
  ];
  const els = new Set();
  selectors.forEach(sel => {
    document.querySelectorAll(sel).forEach(el => els.add(el));
  });
  return [...els].slice(0, 200).map(el => ({
    tag: el.tagName,
    type: el.type || '',
    text: (el.textContent || el.value || '').trim().slice(0, 80),
    id: el.id || '',
    class: el.className?.slice(0, 60) || '',
    name: el.getAttribute('name') || '',
    placeholder: el.placeholder || '',
    ariaLabel: el.getAttribute('aria-label') || '',
    role: el.getAttribute('role') || '',
    href: el.href || '',
    rect: rectStr(el),
    visible: el.offsetParent !== null,
    disabled: el.disabled || false
  }));
}

function deepPageAnalysis() {
  const structure = {
    forms: [],
    nav: [],
    content: [],
    buttons: [],
    inputs: [],
    links: []
  };

  document.querySelectorAll('form').forEach(f => {
    const inputs = [...f.querySelectorAll('input, select, textarea')].map(i => ({
      name: i.name || i.id || '',
      type: i.type || '',
      placeholder: i.placeholder || '',
      label: findLabelFor(i)
    }));
    structure.forms.push({
      id: f.id || '',
      action: f.action || '',
      method: f.method || '',
      inputs
    });
  });

  document.querySelectorAll('button, [role="button"], input[type="submit"], input[type="button"]').forEach(b => {
    structure.buttons.push({
      text: (b.textContent || b.value || b.getAttribute('aria-label') || '').trim().slice(0, 60),
      id: b.id || '',
      visible: b.offsetParent !== null,
      disabled: b.disabled || false,
      rect: rectStr(b)
    });
  });

  document.querySelectorAll('input:not([type="submit"]):not([type="button"]), textarea, select').forEach(i => {
    structure.inputs.push({
      name: i.name || i.id || '',
      type: i.type || i.tagName,
      placeholder: i.placeholder || '',
      label: findLabelFor(i),
      value: i.value?.slice(0, 30) || '',
      required: i.required || false
    });
  });

  document.querySelectorAll('a[href]').forEach(a => {
    structure.links.push({
      text: a.textContent.trim().slice(0, 60),
      href: a.href,
      id: a.id || ''
    });
  });

  structure.title = document.title;
  structure.url = window.location.href;
  structure.headings = [...document.querySelectorAll('h1, h2, h3, h4')].map(h => ({
    level: h.tagName,
    text: h.textContent.trim().slice(0, 80)
  }));

  return structure;
}

function findLabelFor(el) {
  if (el.id) {
    const label = document.querySelector(`label[for="${el.id}"]`);
    if (label) return label.textContent.trim().slice(0, 60);
  }
  let p = el.parentElement;
  while (p) {
    const label = p.querySelector('label');
    if (label && label.contains(el)) return label.textContent.trim().slice(0, 60);
    p = p.parentElement;
  }
  const parent = el.closest('label');
  if (parent) return parent.textContent.trim().slice(0, 60);
  return '';
}

function rectStr(el) {
  const r = el.getBoundingClientRect();
  return `${Math.round(r.left)},${Math.round(r.top)} ${Math.round(r.width)}x${Math.round(r.height)}`;
}

function highlightElement(el) {
  const overlay = document.createElement('div');
  const rect = el.getBoundingClientRect();
  overlay.style.cssText = `
    position: fixed; z-index: 2147483647; pointer-events: none;
    left: ${rect.left + window.scrollX}px; top: ${rect.top + window.scrollY}px;
    width: ${rect.width}px; height: ${rect.height}px;
    border: 3px solid #22c55e; border-radius: 4px;
    background: rgba(34,197,94,0.1);
    box-shadow: 0 0 20px rgba(34,197,94,0.3);
    transition: opacity 0.3s;
    animation: vioraPulse 0.8s ease-in-out 2;
  `;
  const style = document.createElement('style');
  style.textContent = `
    @keyframes vioraPulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }
  `;
  document.head.appendChild(style);
  document.body.appendChild(overlay);
  setTimeout(() => {
    overlay.style.opacity = '0';
    setTimeout(() => { overlay.remove(); style.remove(); }, 300);
  }, 1800);
}

function humanDelay(base = 100) {
  return new Promise(resolve => setTimeout(resolve, Math.round(base * (0.5 + Math.random() * 1.0))));
}

function randomBetween(min, max) {
  return min + Math.random() * (max - min);
}

function simulateMouseMovement(fromX, fromY, toX, toY) {
  const steps = 3 + Math.floor(Math.random() * 5);
  const points = [];
  for (let i = 1; i <= steps; i++) {
    const t = i / (steps + 1);
    const midX = (fromX + toX) / 2 + (Math.random() - 0.5) * 40;
    const midY = (fromY + toY) / 2 + (Math.random() - 0.5) * 20;
    const x = Math.round((1 - t) * (1 - t) * fromX + 2 * (1 - t) * t * midX + t * t * toX);
    const y = Math.round((1 - t) * (1 - t) * fromY + 2 * (1 - t) * t * midY + t * t * toY);
    points.push({ x, y });
  }
  points.push({ x: toX, y: toY });
  return points;
}

async function humanType(target, value) {
  target.focus();
  const nativeSetter = getNativeSetter(target);

  nativeSetter.call(target, '');
  target.dispatchEvent(new Event('input', { bubbles: true }));
  target.dispatchEvent(new Event('change', { bubbles: true }));
  await humanDelay(80);

  for (let i = 0; i < value.length; i++) {
    const char = value[i];
    const isUpperCase = char === char.toUpperCase() && char !== char.toLowerCase();
    const delayMs = isUpperCase ? randomBetween(60, 150) : randomBetween(30, 90);

    nativeSetter.call(target, target.value + char);
    target.dispatchEvent(new Event('input', { bubbles: true }));
    target.dispatchEvent(new KeyboardEvent('keydown', { key: char, bubbles: true }));
    target.dispatchEvent(new KeyboardEvent('keypress', { key: char, bubbles: true }));
    target.dispatchEvent(new KeyboardEvent('keyup', { key: char, bubbles: true }));

    await humanDelay(delayMs);

    if (i === Math.floor(value.length * 0.7) && Math.random() < 0.15) {
      await humanDelay(300);
    }
  }

  target.dispatchEvent(new Event('change', { bubbles: true }));
  await humanDelay(50);
  target.dispatchEvent(new Event('blur', { bubbles: true }));
}

function getNativeSetter(el) {
  const proto = el.tagName === 'TEXTAREA'
    ? window.HTMLTextAreaElement.prototype
    : window.HTMLInputElement.prototype;
  return Object.getOwnPropertyDescriptor(proto, 'value')?.set || function(v) { this.value = v; };
}

function getHumanClickPoint(el) {
  const rect = el.getBoundingClientRect();
  const offsetX = (Math.random() - 0.5) * Math.min(rect.width * 0.3, 8);
  const offsetY = (Math.random() - 0.5) * Math.min(rect.height * 0.3, 6);
  return {
    x: Math.round(rect.left + rect.width / 2 + offsetX),
    y: Math.round(rect.top + rect.height / 2 + offsetY)
  };
}

async function humanClick(el) {
  const pt = getHumanClickPoint(el);
  const eventOpts = { bubbles: true, cancelable: true, clientX: pt.x, clientY: pt.y, pointerId: 1, isPrimary: true, pointerType: 'mouse' };

  el.dispatchEvent(new PointerEvent('pointerover', eventOpts));
  await humanDelay(60);
  el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true, clientX: pt.x, clientY: pt.y }));
  await humanDelay(120);

  el.dispatchEvent(new PointerEvent('pointermove', { ...eventOpts, movementX: 0, movementY: 0 }));
  el.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, cancelable: true, clientX: pt.x, clientY: pt.y }));
  await humanDelay(80);

  el.dispatchEvent(new PointerEvent('pointerdown', { ...eventOpts, button: 0, buttons: 1 }));
  el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, clientX: pt.x, clientY: pt.y, button: 0 }));
  el.focus();
  await humanDelay(randomBetween(40, 120));

  el.dispatchEvent(new PointerEvent('pointerup', { ...eventOpts, button: 0, buttons: 0 }));
  el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, clientX: pt.x, clientY: pt.y, button: 0 }));
  await humanDelay(20);

  el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, clientX: pt.x, clientY: pt.y, button: 0 }));
  await humanDelay(30);
}

async function forceRevealElement(el) {
  const chain = [];
  let current = el;
  while (current && current !== document.body && current !== document.documentElement) {
    chain.push(current);
    current = current.parentElement;
  }
  chain.reverse();
  for (const node of chain) {
    const cs = window.getComputedStyle(node);
    if (cs.display === 'none') node.style.setProperty('display', 'block', 'important');
    if (cs.visibility === 'hidden') node.style.setProperty('visibility', 'visible', 'important');
    if (cs.opacity === '0') node.style.setProperty('opacity', '1', 'important');
    if (cs.pointerEvents === 'none') node.style.setProperty('pointer-events', 'auto', 'important');
  }
}

async function waitForElementStable(el, timeout = 4000) {
  const start = Date.now();
  let prevRect = el.getBoundingClientRect();
  while (Date.now() - start < timeout) {
    await delay(150);
    const curRect = el.getBoundingClientRect();
    if (prevRect.x === curRect.x && prevRect.y === curRect.y && prevRect.width === curRect.width && prevRect.height === curRect.height) {
      return true;
    }
    prevRect = curRect;
  }
  return false;
}

async function handleDomAction(action) {
  let lastError = null;
  const maxRetries = 3;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await executeAction(action, attempt);
    } catch (err) {
      lastError = err;
      if (attempt < maxRetries) {
        const backoff = Math.min(800 * attempt + Math.random() * 400, 3000);
        await delay(backoff);
      }
    }
  }

  const fallbackResult = await executeFallback(action);
  if (fallbackResult?.success) return fallbackResult;
  throw lastError || new Error('Action failed after all retries and fallbacks');
}

async function executeFallback(action) {
  if (action.type === 'click' || action.type === 'click_at') {
    if (action.text) {
      const textEls = [...document.querySelectorAll('*')].filter(el => {
        if (el.children.length > 0) return false;
        return (el.textContent || '').trim().toLowerCase() === action.text.toLowerCase().trim();
      });
      for (const el of textEls) {
        let parent = el.parentElement;
        while (parent && parent !== document.body) {
          if (['BUTTON', 'A', 'LABEL', 'INPUT', 'SPAN', 'DIV'].includes(parent.tagName) && parent.offsetParent !== null) {
            await forceRevealElement(parent);
            await humanDelay(200);
            await humanClick(parent);
            triggerFrameworkEvents(parent);
            try { parent.click(); } catch (_) {}
            return { success: true, message: `Fallback clicked parent of text: ${action.text}` };
          }
          parent = parent.parentElement;
        }
      }
    }
  }
  if (action.type === 'click' || action.type === 'click_at') {
    const allButtons = document.querySelectorAll('button, [role="button"], input[type="submit"], input[type="button"], a[href]');
    for (const btn of allButtons) {
      const text = (btn.textContent || btn.value || '').trim().toLowerCase();
      const hint = (action.text || action.description || action.selector || '').toLowerCase();
      if (text.includes(hint) || hint.includes(text)) {
        await forceRevealElement(btn);
        await humanDelay(200);
        await humanClick(btn);
        triggerFrameworkEvents(btn);
        try { btn.click(); } catch (_) {}
        return { success: true, message: `Fallback matched "${text}" for "${action.text || action.description}"` };
      }
    }
  }
  return null;
}

async function executeAction(action, attempt) {
  await humanDelay(80);

  switch (action.type) {

    case 'click': {
      const el = await findElementDeep(action);
      if (!el) throw new Error(`Element not found: ${action.selector || action.text || action.description}`);

      if (el.offsetParent === null || el.disabled) {
        await forceRevealElement(el);
        await humanDelay(300);
      }

      await waitForElementStable(el);
      scrollToElementNatural(el);
      await humanDelay(300);

      let target = el;
      if (target.tagName === 'LABEL') {
        const forId = target.getAttribute('for') || target.htmlFor;
        const input = forId
          ? document.getElementById(forId)
          : target.querySelector('input[type="radio"], input[type="checkbox"], input, select, textarea');
        if (input) target = input;
      }

      highlightElement(target);
      await humanDelay(200);

      await humanClick(target);
      triggerFrameworkEvents(target);
      try { target.click(); } catch (_) {}

      if (target.type === 'radio') {
        target.checked = true;
        await humanDelay(30);
        target.dispatchEvent(new Event('change', { bubbles: true }));
        target.dispatchEvent(new Event('input', { bubbles: true }));
        await humanClick(target);
        try { target.click(); } catch (_) {}
      } else if (target.type === 'checkbox') {
        const next = action.checked !== undefined ? action.checked : !target.checked;
        target.checked = next;
        await humanDelay(30);
        target.dispatchEvent(new Event('change', { bubbles: true }));
        target.dispatchEvent(new Event('input', { bubbles: true }));
      }

      await humanDelay(200);
      return { success: true, message: `Clicked: ${action.description || action.selector || action.text}` };
    }

    case 'click_at': {
      const dpr = window.devicePixelRatio || 1;
      let vx = action.x / dpr;
      let vy = action.y / dpr;

      const pageY = vy + window.scrollY;
      if (pageY > window.scrollY + window.innerHeight || pageY < window.scrollY) {
        window.scrollTo({ top: Math.max(0, pageY - window.innerHeight / 3), behavior: 'smooth' });
        await humanDelay(500);
      }

      let el = document.elementFromPoint(vx, vy);
      if (!el || el === document.body || el === document.documentElement) {
        el = document.elementFromPoint(action.x, action.y);
      }
      if (!el || el === document.body || el === document.documentElement) {
        throw new Error(`No element found at (${action.x}, ${action.y})`);
      }

      let target = el;
      const clickableTags = ['BUTTON', 'A', 'INPUT', 'LABEL', 'SELECT', 'TEXTAREA', 'SUMMARY', 'OPTION'];
      let depth = 0;
      while (target && target !== document.body && depth < 10) {
        const tag = target.tagName;
        const role = target.getAttribute('role') || '';
        if (
          clickableTags.includes(tag) ||
          ['button', 'link', 'option', 'checkbox', 'radio', 'tab', 'menuitem', 'switch'].includes(role) ||
          target.onclick != null || target.getAttribute('onclick') ||
          target.getAttribute('ng-click') || target.getAttribute('v-on:click') ||
          target.getAttribute('@click') || target.classList.contains('btn') ||
          target.classList.contains('button') || target.getAttribute('tabindex') === '0'
        ) break;
        target = target.parentElement;
        depth++;
      }
      el = (target && target !== document.body) ? target : el;

      await waitForElementStable(el);
      scrollToElementNatural(el);
      await humanDelay(200);
      highlightElement(el);
      await humanDelay(150);

      await humanClick(el);
      triggerFrameworkEvents(el);
      try { el.click(); } catch (_) {}

      await humanDelay(250);
      return {
        success: true,
        message: `Clicked at (${action.x}, ${action.y}): ${el.tagName} "${(el.textContent || '').trim().slice(0, 60)}"`
      };
    }

    case 'fill': {
      const el = await findElementDeep(action);
      if (!el) throw new Error(`Input field not found: ${action.selector || action.description}`);
      scrollToElementNatural(el);
      await humanDelay(300);
      highlightElement(el);

      await humanClick(el);
      await humanDelay(200);

      await humanType(el, String(action.value));

      return { success: true, message: `Filled "${action.description || action.selector}"` };
    }

    case 'clear': {
      const el = await findElementDeep(action);
      if (!el) throw new Error(`Element not found: ${action.selector}`);
      el.focus();
      await humanClick(el);
      await humanDelay(100);
      const nativeSetter = getNativeSetter(el);
      nativeSetter.call(el, '');
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return { success: true, message: 'Cleared field' };
    }

    case 'select': {
      const el = await findElementDeep(action);
      if (!el) throw new Error(`Select element not found: ${action.selector}`);
      scrollToElementNatural(el);
      await humanDelay(200);
      el.focus();
      el.value = action.value;
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return { success: true, message: `Selected option: ${action.value}` };
    }

    case 'check': {
      let el = await findElementDeep(action);
      if (!el) throw new Error(`Checkbox not found: ${action.selector}`);
      if (el.tagName === 'LABEL') {
        const forId = el.getAttribute('for') || el.htmlFor;
        const input = forId ? document.getElementById(forId) : el.querySelector('input');
        if (input) el = input;
      }
      const shouldCheck = action.checked !== false;
      scrollToElementNatural(el);
      await humanDelay(200);
      highlightElement(el);
      if (el.checked !== shouldCheck) {
        await humanClick(el);
        await humanDelay(50);
        el.checked = shouldCheck;
        el.dispatchEvent(new Event('change', { bubbles: true }));
        el.dispatchEvent(new Event('input', { bubbles: true }));
      }
      return { success: true, message: `${shouldCheck ? 'Checked' : 'Unchecked'}: ${action.description}` };
    }

    case 'scroll': {
      if (action.selector) {
        const el = await findElementDeep(action);
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } else if (action.toBottom) {
        smoothScrollTo(document.body.scrollHeight);
      } else if (action.toTop) {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        smoothScrollBy(action.y || 400);
      }
      await delay(600);
      return { success: true, message: 'Scrolled' };
    }

    case 'extract': {
      let data = '';
      if (action.selector) {
        const els = [...document.querySelectorAll(action.selector)];
        if (els.length === 0) throw new Error(`No elements matched: ${action.selector}`);
        data = els.map(el => el.innerText || el.textContent || el.value).join('\n---\n');
      } else {
        data = document.body.innerText;
      }
      return { success: true, data: data.slice(0, 20000), message: 'Extracted data from page' };
    }

    case 'extract_links': {
      const links = [...document.querySelectorAll(action.selector || 'a[href]')]
        .map(a => ({ text: a.textContent.trim(), href: a.href }))
        .filter(l => l.href && l.text)
        .slice(0, 200);
      return { success: true, data: JSON.stringify(links, null, 2), message: 'Extracted links' };
    }

    case 'extract_table': {
      const table = (await findElementDeep(action)) || document.querySelector('table');
      if (!table) throw new Error('No table found');
      const headers = table.querySelectorAll('th').length > 0
        ? [...table.querySelectorAll('th')].map(h => h.innerText.trim())
        : [];
      const rows = [...table.querySelectorAll('tr')]
        .filter(tr => tr.querySelectorAll('td').length > 0)
        .map(tr => [...tr.querySelectorAll('td')].map(cell => cell.innerText.trim()));
      const result = { headers, rows };
      return { success: true, data: JSON.stringify(result, null, 2), message: 'Extracted table' };
    }

    case 'wait_for': {
      const found = await waitForElementVisible(action.selector, action.timeout || 10000);
      if (!found) throw new Error(`Timed out waiting for: ${action.selector}`);
      await humanDelay(200);
      return { success: true, message: `Element appeared: ${action.selector}` };
    }

    case 'hover': {
      const el = await findElementDeep(action);
      if (!el) throw new Error(`Element not found: ${action.selector}`);
      scrollToElementNatural(el);
      await humanDelay(200);
      const pt = getHumanClickPoint(el);
      el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true, clientX: pt.x, clientY: pt.y }));
      await humanDelay(100);
      el.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true, cancelable: true, clientX: pt.x, clientY: pt.y }));
      await humanDelay(400);
      return { success: true, message: 'Hovered over element' };
    }

    case 'press_key': {
      const el = action.selector ? await findElementDeep(action) : document.activeElement;
      const target = el || document.body;
      target.focus();
      const keyData = { key: action.key, code: action.code || action.key, keyCode: action.keyCode || 0, which: action.keyCode || 0, bubbles: true, cancelable: true };
      target.dispatchEvent(new KeyboardEvent('keydown', { ...keyData, repeat: false }));
      await humanDelay(40);
      target.dispatchEvent(new KeyboardEvent('keypress', { ...keyData }));
      await humanDelay(30);
      target.dispatchEvent(new KeyboardEvent('keyup', { ...keyData }));
      return { success: true, message: `Pressed key: ${action.key}` };
    }

    case 'analyze': {
      return { success: true, data: JSON.stringify(deepPageAnalysis(), null, 2), message: 'Page analyzed' };
    }

    case 'get_text': {
      const el = await findElementDeep(action);
      if (!el) throw new Error(`Element not found: ${action.selector}`);
      return { success: true, data: el.innerText || el.textContent || el.value, message: 'Got text' };
    }

    case 'get_page_info': {
      return {
        success: true,
        title: document.title,
        url: window.location.href,
        text: document.body.innerText.slice(0, 15000),
        interactiveElements: extractAllInteractive()
      };
    }

    default:
      throw new Error(`Unknown action type: ${action.type}`);
  }
}

function triggerFrameworkEvents(el) {
  const fiberKey = Object.keys(el).find(k => k.startsWith('__reactFiber') || k.startsWith('__reactInternalInstance'));
  if (fiberKey) {
    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
    if (nativeSetter && el.value !== undefined) nativeSetter.call(el, el.value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const vueKey = Object.keys(el).find(k => k.startsWith('__vue__') || k.startsWith('__vue'));
  if (vueKey) {
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const ngKey = Object.keys(el).find(k => k.startsWith('ng-') || k.startsWith('__ng'));
  if (ngKey) {
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
}

async function findElementDeep(action) {
  let el = findElement(action);
  if (el) return el;

  await delay(200);
  el = findElement(action);
  if (el) return el;

  if (action.text) {
    await delay(300);
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    const matches = [];
    while (walker.nextNode()) {
      const text = walker.currentNode.textContent.trim().toLowerCase();
      const query = action.text.toLowerCase().trim();
      if (text === query) matches.push(walker.currentNode.parentElement);
    }
    if (matches.length > 0) return matches[0];
    const walker2 = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    const matches2 = [];
    while (walker2.nextNode()) {
      const text = walker2.currentNode.textContent.trim().toLowerCase();
      const query = action.text.toLowerCase().trim();
      if (text.includes(query) || query.includes(text)) matches2.push(walker2.currentNode.parentElement);
    }
    if (matches2.length > 0) return matches2[0];
  }

  return null;
}

function findElement(action) {
  if (action.selector) {
    try {
      const el = document.querySelector(action.selector);
      if (el) return el;
    } catch (_) {}

    try {
      const stripped = action.selector.replace(/^[a-zA-Z]+(\[)/, '$1');
      if (stripped !== action.selector) {
        const el = document.querySelector(stripped);
        if (el) return el;
      }
    } catch (_) {}

    try {
      const byId = action.selector.replace(/^[a-zA-Z]*#/, '#');
      if (byId !== action.selector) {
        const el = document.querySelector(byId);
        if (el) return el;
      }
    } catch (_) {}

    for (const pattern of [
      /\[id=['"]?([^'"=\]]+)['"]?\]/,
      /#([\w-]+)/
    ]) {
      try {
        const m = action.selector.match(pattern);
        if (m) {
          const el = document.getElementById(m[1]);
          if (el) return el;
        }
      } catch (_) {}
    }

    try {
      const r = document.evaluate(action.selector, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
      if (r.singleNodeValue) return r.singleNodeValue;
    } catch (_) {}

    try {
      const lastBit = action.selector.split(/[\[\.#:\s]/).filter(Boolean).pop();
      if (lastBit) {
        const byClass = document.querySelector(`[class*="${lastBit}"]`);
        if (byClass) return byClass;
        const byId2 = document.getElementById(lastBit);
        if (byId2) return byId2;
        const byName = document.querySelector(`[name="${lastBit}"], [name*="${lastBit}"]`);
        if (byName) return byName;
      }
    } catch (_) {}
  }

  if (action.text) {
    const query = action.text.toLowerCase().trim();
    const candidates = document.querySelectorAll(
      'button, a, [role="button"], [role="link"], [role="option"], [role="tab"], [role="menuitem"], ' +
      'input[type="submit"], input[type="button"], input[type="reset"], ' +
      'label, span[onclick], div[onclick], [tabindex], select, summary, ' +
      '[ng-click], [v-on\\:click], [@click]'
    );

    for (const el of candidates) {
      const text = (el.textContent || el.value || el.placeholder || el.getAttribute('aria-label') || el.getAttribute('title') || '').toLowerCase().trim();
      if (text === query) return el;
    }
    for (const el of candidates) {
      const text = (el.textContent || el.value || el.placeholder || el.getAttribute('aria-label') || el.getAttribute('title') || '').toLowerCase().trim();
      if (text.includes(query)) return el;
    }
    for (const el of candidates) {
      const text = (el.textContent || el.value || el.placeholder || el.getAttribute('aria-label') || el.getAttribute('title') || '').toLowerCase().trim();
      if (query.includes(text)) return el;
    }
  }

  for (const attr of ['placeholder', 'ariaLabel', 'name', 'id', 'title', 'class', 'data-testid', 'data-test', 'data-qa', 'data-cy']) {
    const val = action[attr];
    if (val) {
      const attrName = attr === 'ariaLabel' ? 'aria-label' : attr === 'data-testid' ? 'data-testid' : attr === 'data-test' ? 'data-test' : attr === 'data-qa' ? 'data-qa' : attr === 'data-cy' ? 'data-cy' : attr;
      try {
        const el = document.querySelector(`[${attrName}="${val}"], [${attrName}*="${val}" i]`);
        if (el) return el;
      } catch (_) {}
    }
  }

  const hint = ((action.description || '') + ' ' + (action.selector || '') + ' ' + (action.text || '')).toLowerCase();

  if (/next|submit|continue|proceed|forward|done|finish|ok\b|save|confirm|agree|accept|send|go\b|log\s*in|sign\s*in|sign\s*up|register/.test(hint)) {
    const idPatterns = [
      'NextButton', 'next-button', 'nextButton', 'submitButton',
      'submit-button', 'continueButton', 'btnNext', 'btn-next',
      'nextBtn', 'submitBtn', 'nextPage', 'SaveButton', 'save-button',
      'confirmButton', 'confirm-button', 'agreeButton', 'agree-button',
      'acceptButton', 'accept-button', 'doneButton', 'done-button',
      'finishButton', 'finish-button', 'proceedButton', 'proceed-button',
      'loginButton', 'login-button', 'signInButton', 'signinButton',
      'registerButton', 'register-button', 'btnSubmit', 'btn-submit',
      'btn-primary', 'btn-primary', 'primaryBtn', 'primary-button'
    ];
    for (const id of idPatterns) {
      const el = document.getElementById(id);
      if (el) return el;
    }

    const navKeywords = /^(next|continue|proceed|submit|done|finish|ok|save|confirm|agree|accept|send|go|login|sign\s*in|sign\s*up|register)$/i;
    const clickables = document.querySelectorAll('button, input[type="submit"], input[type="button"], [role="button"], a');
    for (const el of clickables) {
      const label = (el.textContent || el.value || el.getAttribute('aria-label') || el.getAttribute('title') || '').trim();
      if (navKeywords.test(label)) return el;
    }
    for (const el of clickables) {
      const label = (el.textContent || el.value || '').toLowerCase();
      for (const kw of ['next', 'submit', 'continue', 'proceed', 'save', 'confirm', 'agree', 'accept', 'done', 'finish', 'send', 'login', 'sign in', 'sign up', 'register']) {
        if (label.includes(kw)) return el;
      }
    }
  }

  if (action.selector) {
    const searchStr = action.selector.toLowerCase();
    const allClickables = document.querySelectorAll('button, a, [role="button"], input[type="submit"], input[type="button"], summary, select, label');
    for (const el of allClickables) {
      const label = (el.textContent || el.value || el.getAttribute('aria-label') || el.getAttribute('title') || '').toLowerCase();
      if (label.includes(searchStr) || searchStr.includes(label)) return el;
    }
  }

  return null;
}

function smoothScrollTo(targetY) {
  const startY = window.scrollY;
  const distance = targetY - startY;
  const duration = Math.min(Math.abs(distance) * 0.5, 600);
  const start = performance.now();
  function step(now) {
    const elapsed = now - start;
    const t = Math.min(elapsed / duration, 1);
    const ease = 1 - Math.pow(1 - t, 3);
    window.scrollTo(0, startY + distance * ease);
    if (t < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

function smoothScrollBy(deltaY) {
  smoothScrollTo(window.scrollY + deltaY);
}

function scrollToElementNatural(el) {
  try {
    const rect = el.getBoundingClientRect();
    const isVisible = (
      rect.top > 50 && rect.bottom < window.innerHeight - 50 &&
      rect.left > 0 && rect.right < window.innerWidth
    );
    if (!isVisible) {
      const targetY = window.scrollY + rect.top - window.innerHeight / 3 + rect.height / 2;
      smoothScrollTo(Math.max(0, targetY));
    }
  } catch (_) {
    try { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (_) {}
  }
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function waitForElementVisible(selector, timeout = 10000) {
  return new Promise(resolve => {
    const check = () => {
      try {
        const el = document.querySelector(selector);
        return el && el.offsetParent !== null;
      } catch (_) { return false; }
    };
    if (check()) { resolve(true); return; }
    const observer = new MutationObserver(() => {
      if (check()) { observer.disconnect(); resolve(true); }
    });
    observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class'] });
    setTimeout(() => { observer.disconnect(); resolve(false); }, timeout);
  });
}
